#!/bin/bash
# Build script for Vercel deployment

# Build the frontend
npm run build

# Make the script executable
chmod +x vercel-build.sh
