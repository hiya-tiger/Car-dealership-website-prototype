import { 
  users, 
  type User, 
  type InsertUser, 
  vehicles, 
  type Vehicle, 
  type InsertVehicle, 
  inquiries, 
  type Inquiry, 
  type InsertInquiry, 
  testimonials, 
  type Testimonial, 
  type InsertTestimonial,
  tradeIns,
  type TradeIn,
  type InsertTradeIn
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Vehicle methods
  async getVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles);
  }
  
  async getVehicleById(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle;
  }
  
  async getFeaturedVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.isFeatured, true));
  }
  
  async getSpecialOfferVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.isSpecialOffer, true));
  }
  
  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values({
      ...insertVehicle,
      features: insertVehicle.features || null,
      images: insertVehicle.images || [],
      mpgCity: insertVehicle.mpgCity || null,
      mpgHighway: insertVehicle.mpgHighway || null,
      engineDescription: insertVehicle.engineDescription || null,
      horsepower: insertVehicle.horsepower || null,
      torque: insertVehicle.torque || null,
      monthlyPayment: insertVehicle.monthlyPayment || null,
      // AR and 3D model fields
      modelUrl: insertVehicle.modelUrl || null,
      interiorModelUrl: insertVehicle.interiorModelUrl || null,
      arModelUrl: insertVehicle.arModelUrl || null,
      arModelScale: insertVehicle.arModelScale || 1.0,
      // CarFax fields
      carfaxLink: insertVehicle.carfaxLink || null,
      carfaxReportDate: insertVehicle.carfaxReportDate || null,
      carfaxOwners: insertVehicle.carfaxOwners || null,
      carfaxAccidents: insertVehicle.carfaxAccidents || null,
      carfaxServiceRecords: insertVehicle.carfaxServiceRecords || null
    }).returning();
    
    return vehicle;
  }
  
  async updateVehicle(id: number, updatedFields: Partial<Vehicle>): Promise<Vehicle | undefined> {
    const [updatedVehicle] = await db.update(vehicles)
      .set(updatedFields)
      .where(eq(vehicles.id, id))
      .returning();
    
    return updatedVehicle;
  }
  
  async deleteVehicle(id: number): Promise<boolean> {
    const result = await db.delete(vehicles).where(eq(vehicles.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }
  
  // Inquiry methods
  async getInquiries(): Promise<Inquiry[]> {
    return await db.select().from(inquiries).orderBy(desc(inquiries.createdAt));
  }
  
  async getInquiryById(id: number): Promise<Inquiry | undefined> {
    const [inquiry] = await db.select().from(inquiries).where(eq(inquiries.id, id));
    return inquiry;
  }
  
  async getInquiriesByVehicleId(vehicleId: number): Promise<Inquiry[]> {
    return await db.select().from(inquiries).where(eq(inquiries.vehicleId, vehicleId));
  }
  
  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const [inquiry] = await db.insert(inquiries).values({
      ...insertInquiry,
      vehicleId: insertInquiry.vehicleId || null
    }).returning();
    
    return inquiry;
  }
  
  // Testimonial methods
  async getTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials);
  }
  
  async getTestimonialById(id: number): Promise<Testimonial | undefined> {
    const [testimonial] = await db.select().from(testimonials).where(eq(testimonials.id, id));
    return testimonial;
  }
  
  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const [testimonial] = await db.insert(testimonials).values({
      ...insertTestimonial,
      imageUrl: insertTestimonial.imageUrl || null
    }).returning();
    
    return testimonial;
  }
  
  // Trade-In methods
  async getTradeIns(): Promise<TradeIn[]> {
    return await db.select().from(tradeIns).orderBy(desc(tradeIns.createdAt));
  }
  
  async getTradeInById(id: number): Promise<TradeIn | undefined> {
    const [tradeIn] = await db.select().from(tradeIns).where(eq(tradeIns.id, id));
    return tradeIn;
  }
  
  async createTradeIn(insertTradeIn: InsertTradeIn): Promise<TradeIn> {
    const [tradeIn] = await db.insert(tradeIns).values({
      ...insertTradeIn,
      status: "pending",
      comments: insertTradeIn.comments || null
    }).returning();
    
    return tradeIn;
  }
  
  async updateTradeInStatus(id: number, status: string): Promise<TradeIn | undefined> {
    const [updatedTradeIn] = await db.update(tradeIns)
      .set({ status })
      .where(eq(tradeIns.id, id))
      .returning();
    
    return updatedTradeIn;
  }
  
  // Database initialization with sample data
  async initializeDatabase(): Promise<void> {
    // Check if we already have vehicles
    const existingVehicles = await db.select().from(vehicles);
    if (existingVehicles.length > 0) {
      console.log("Database already initialized with sample data");
      return;
    }
    
    console.log("Initializing database with sample data...");
    
    // Initialize sample testimonials
    const sampleTestimonials: InsertTestimonial[] = [
      {
        name: "Sarah Johnson",
        rating: 5,
        review: "I had an amazing experience buying my Toyota Camry from 89 Autosales. The staff was knowledgeable and helped me find the perfect car within my budget. The financing process was smooth and transparent.",
        vehicle: "Toyota Camry",
        imageUrl: "https://randomuser.me/api/portraits/women/65.jpg"
      },
      {
        name: "Michael Rodriguez",
        rating: 4,
        review: "The team at 89 Autosales went above and beyond to help me find my dream car. They were patient through the whole process and made sure I got the best financing rate possible. Would definitely recommend!",
        vehicle: "Honda Accord",
        imageUrl: "https://randomuser.me/api/portraits/men/32.jpg"
      },
      {
        name: "Emily Chen",
        rating: 5,
        review: "As a first-time car buyer, I was nervous about the process. The team at 89 Autosales made it simple and stress-free. They answered all my questions and found me a great car with payments I can afford.",
        vehicle: "Mazda CX-5",
        imageUrl: "https://randomuser.me/api/portraits/women/45.jpg"
      }
    ];
    
    for (const testimonial of sampleTestimonials) {
      await this.createTestimonial(testimonial);
    }
    
    // Initialize sample vehicles
    const sampleVehicles: InsertVehicle[] = [
      {
        make: "Toyota",
        model: "Camry",
        year: 2019,
        price: 21995,
        mileage: 42530,
        exteriorColor: "Blue",
        interiorColor: "Black",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "3.5L V6",
        description: "This 2019 Toyota Camry XSE V6 is in excellent condition with just 42,530 miles. Features include a V6 engine, leather seats, panoramic sunroof, and Toyota Safety Sense package.",
        features: ["Leather Seats", "Panoramic Sunroof", "Navigation", "Bluetooth", "Backup Camera", "Heated Seats"],
        images: ["https://images.unsplash.com/photo-1583121274602-3e2820c69888?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "4T1BZ1HK5KU123456",
        mpgCity: 28,
        mpgHighway: 39,
        engineDescription: "3.5L V6",
        horsepower: 301,
        torque: 267,
        isFeatured: true,
        isSpecialOffer: false,
        monthlyPayment: 329,
        modelUrl: "https://models.readyplayer.me/64d3a7dbc0392f01fc64e3e2.glb",
        interiorModelUrl: "https://models.readyplayer.me/64d3a7dbc0392f01fc64e3e2.glb",
        arModelUrl: "https://models.readyplayer.me/64d3a7dbc0392f01fc64e3e2.glb",
        arModelScale: 0.8,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=4T1BZ1HK5KU123456",
        carfaxReportDate: new Date("2023-10-10"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 10
      },
      {
        make: "Honda",
        model: "Accord",
        year: 2020,
        price: 24495,
        mileage: 31245,
        exteriorColor: "Black",
        interiorColor: "Gray",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "2.0L Turbo",
        description: "This 2020 Honda Accord Sport 2.0T is a sporty yet practical sedan with a powerful turbocharged engine. Low mileage and excellent condition make this a great value.",
        features: ["Apple CarPlay", "Android Auto", "Heated Seats", "Blind Spot Monitor", "Lane Keep Assist", "Adaptive Cruise Control"],
        images: ["https://images.unsplash.com/photo-1617469767053-d3b16ee9a13e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "1HGCV2F33LA123456",
        mpgCity: 22,
        mpgHighway: 32,
        engineDescription: "2.0L Turbocharged I4",
        horsepower: 252,
        torque: 273,
        isFeatured: true,
        isSpecialOffer: false,
        monthlyPayment: 369,
        modelUrl: "https://models.readyplayer.me/64e6306992b52bdcc25f3b8b.glb",
        interiorModelUrl: "https://models.readyplayer.me/64e6306992b52bdcc25f3b8b.glb",
        arModelUrl: "https://models.readyplayer.me/64e6306992b52bdcc25f3b8b.glb",
        arModelScale: 0.75,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=1HGCV2F33LA123456",
        carfaxReportDate: new Date("2023-12-15"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 12
      },
      {
        make: "BMW",
        model: "5 Series",
        year: 2018,
        price: 32995,
        mileage: 38120,
        exteriorColor: "Silver",
        interiorColor: "Black",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "3.0L Turbocharged I6",
        description: "Luxurious 2018 BMW 540i xDrive with premium features including heated leather seats, premium sound system, and advanced driver assistance package.",
        features: ["All-Wheel Drive", "Leather Seats", "Premium Sound System", "Navigation", "Parking Sensors", "Heated Steering Wheel"],
        images: ["https://images.unsplash.com/photo-1609061802877-57db91614da6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "WBAJB9C57JB123456",
        mpgCity: 21,
        mpgHighway: 29,
        engineDescription: "3.0L Turbocharged I6",
        horsepower: 335,
        torque: 332,
        isFeatured: false,
        isSpecialOffer: true,
        monthlyPayment: 489,
        modelUrl: "https://models.readyplayer.me/648f456740ea28a827a59f5a.glb",
        interiorModelUrl: "https://models.readyplayer.me/648f456740ea28a827a59f5a.glb",
        arModelUrl: "https://models.readyplayer.me/648f456740ea28a827a59f5a.glb",
        arModelScale: 0.9,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=WBAJB9C57JB123456",
        carfaxReportDate: new Date("2023-11-20"),
        carfaxOwners: 2,
        carfaxAccidents: 1,
        carfaxServiceRecords: 18
      },
      {
        make: "Ford",
        model: "Mustang",
        year: 2021,
        price: 38995,
        mileage: 18750,
        exteriorColor: "Red",
        interiorColor: "Black",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Coupe",
        engineSize: "5.0L V8",
        description: "Powerful 2021 Ford Mustang GT Premium with the iconic 5.0L V8 engine. Features include leather seats, premium audio, and the GT performance package.",
        features: ["5.0L V8 Engine", "Leather Seats", "Backup Camera", "Apple CarPlay", "Android Auto", "Premium Audio"],
        images: ["https://images.unsplash.com/photo-1551830820-330a71b99659?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "1FA6P8CF3M5123456",
        mpgCity: 15,
        mpgHighway: 24,
        engineDescription: "5.0L V8",
        horsepower: 460,
        torque: 420,
        isFeatured: true,
        isSpecialOffer: false,
        monthlyPayment: 549,
        modelUrl: "https://models.readyplayer.me/65a45025ad9b52be4c36bf37.glb",
        interiorModelUrl: "https://models.readyplayer.me/65a45025ad9b52be4c36bf37.glb",
        arModelUrl: "https://models.readyplayer.me/65a45025ad9b52be4c36bf37.glb",
        arModelScale: 0.85,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=1FA6P8CF3M5123456",
        carfaxReportDate: new Date("2024-01-05"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 6
      },
      {
        make: "Chevrolet",
        model: "Silverado",
        year: 2020,
        price: 41995,
        mileage: 28500,
        exteriorColor: "White",
        interiorColor: "Gray",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Truck",
        engineSize: "5.3L V8",
        description: "Powerful and capable 2020 Chevrolet Silverado LT with the Z71 Off-Road Package. Perfect for work or play with impressive towing capacity and comfort.",
        features: ["4x4", "Z71 Off-Road Package", "Towing Package", "Bed Liner", "Touchscreen Infotainment", "Backup Camera"],
        images: ["https://images.unsplash.com/photo-1581752825773-7c607d6d2421?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "3GCUYDED7LG123456",
        mpgCity: 16,
        mpgHighway: 21,
        engineDescription: "5.3L V8",
        horsepower: 355,
        torque: 383,
        isFeatured: false,
        isSpecialOffer: false,
        monthlyPayment: 599,
        modelUrl: "https://models.readyplayer.me/648f456740ea28a827a59fdb.glb",
        interiorModelUrl: "https://models.readyplayer.me/648f456740ea28a827a59fdb.glb",
        arModelUrl: "https://models.readyplayer.me/648f456740ea28a827a59fdb.glb",
        arModelScale: 0.75,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=3GCUYDED7LG123456",
        carfaxReportDate: new Date("2023-12-18"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 14
      },
      {
        make: "Tesla",
        model: "Model 3",
        year: 2022,
        price: 44995,
        mileage: 12500,
        exteriorColor: "Blue",
        interiorColor: "White",
        fuelType: "Electric",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "Dual Motor Electric",
        description: "Nearly-new 2022 Tesla Model 3 Long Range with dual motor all-wheel drive. Features include Autopilot, premium interior, and an exceptional electric range.",
        features: ["Electric", "Autopilot", "Glass Roof", "Premium Interior", "All-Wheel Drive", "Fast Charging"],
        images: ["https://images.unsplash.com/photo-1560958089-b8a1929cea89?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "5YJ3E1EA8NF123456",
        mpgCity: 0,
        mpgHighway: 0,
        engineDescription: "Dual Motor Electric",
        horsepower: 346,
        torque: 389,
        isFeatured: true,
        isSpecialOffer: true,
        monthlyPayment: 649,
        modelUrl: "https://models.readyplayer.me/65b1e4c27815db5d89ee1979.glb",
        interiorModelUrl: "https://models.readyplayer.me/65b1e4c27815db5d89ee1979.glb",
        arModelUrl: "https://models.readyplayer.me/65b1e4c27815db5d89ee1979.glb",
        arModelScale: 0.7,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=5YJ3E1EA8NF123456",
        carfaxReportDate: new Date("2024-01-15"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 8
      }
    ];
    
    for (const vehicle of sampleVehicles) {
      await this.createVehicle(vehicle);
    }
    
    console.log("Database initialization complete");
  }
}