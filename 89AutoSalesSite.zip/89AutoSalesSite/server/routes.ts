import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertInquirySchema, insertVehicleSchema, insertTestimonialSchema, insertTradeInSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for vehicles
  app.get("/api/vehicles", async (req: Request, res: Response) => {
    try {
      // Handle query parameters for filtering
      const { make, model, maxPrice, minYear, bodyStyle } = req.query;
      
      let vehicles = await storage.getVehicles();
      
      // Apply filters if they exist
      if (make && typeof make === 'string') {
        vehicles = vehicles.filter(v => v.make.toLowerCase() === make.toLowerCase());
      }
      
      if (model && typeof model === 'string') {
        vehicles = vehicles.filter(v => v.model.toLowerCase() === model.toLowerCase());
      }
      
      if (maxPrice && !isNaN(Number(maxPrice))) {
        vehicles = vehicles.filter(v => v.price <= Number(maxPrice));
      }
      
      if (minYear && !isNaN(Number(minYear))) {
        vehicles = vehicles.filter(v => v.year >= Number(minYear));
      }
      
      if (bodyStyle && typeof bodyStyle === 'string') {
        vehicles = vehicles.filter(v => v.bodyStyle.toLowerCase() === bodyStyle.toLowerCase());
      }
      
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Error fetching vehicles" });
    }
  });

  app.get("/api/vehicles/featured", async (req: Request, res: Response) => {
    try {
      const featuredVehicles = await storage.getFeaturedVehicles();
      res.json(featuredVehicles);
    } catch (error) {
      res.status(500).json({ message: "Error fetching featured vehicles" });
    }
  });

  app.get("/api/vehicles/special-offers", async (req: Request, res: Response) => {
    try {
      const specialOffers = await storage.getSpecialOfferVehicles();
      res.json(specialOffers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching special offers" });
    }
  });

  app.get("/api/vehicles/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle ID" });
      }
      
      const vehicle = await storage.getVehicleById(id);
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.json(vehicle);
    } catch (error) {
      res.status(500).json({ message: "Error fetching vehicle details" });
    }
  });

  app.post("/api/vehicles", async (req: Request, res: Response) => {
    try {
      const vehicleData = insertVehicleSchema.parse(req.body);
      const vehicle = await storage.createVehicle(vehicleData);
      res.status(201).json(vehicle);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vehicle data", errors: error.issues });
      }
      res.status(500).json({ message: "Error creating vehicle" });
    }
  });

  app.put("/api/vehicles/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle ID" });
      }
      
      const vehicle = await storage.getVehicleById(id);
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      const updateData = req.body;
      const updatedVehicle = await storage.updateVehicle(id, updateData);
      res.json(updatedVehicle);
    } catch (error) {
      res.status(500).json({ message: "Error updating vehicle" });
    }
  });

  app.delete("/api/vehicles/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle ID" });
      }
      
      const success = await storage.deleteVehicle(id);
      if (!success) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting vehicle" });
    }
  });
  
  // API route to update vehicle status (available, pending, sold)
  app.put("/api/vehicles/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle ID" });
      }
      
      const { status } = req.body;
      if (!status || typeof status !== 'string' || !['available', 'pending', 'sold'].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be one of: available, pending, sold" });
      }
      
      const vehicle = await storage.getVehicleById(id);
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      const updatedVehicle = await storage.updateVehicle(id, { status });
      res.json(updatedVehicle);
    } catch (error) {
      res.status(500).json({ message: "Error updating vehicle status" });
    }
  });

  // API routes for inquiries
  app.post("/api/inquiries", async (req: Request, res: Response) => {
    try {
      const inquiryData = insertInquirySchema.parse(req.body);
      
      // If a vehicleId is provided, verify that the vehicle exists
      if (inquiryData.vehicleId) {
        const vehicle = await storage.getVehicleById(inquiryData.vehicleId);
        if (!vehicle) {
          return res.status(404).json({ message: "Vehicle not found" });
        }
      }
      
      const inquiry = await storage.createInquiry(inquiryData);
      res.status(201).json(inquiry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid inquiry data", errors: error.issues });
      }
      res.status(500).json({ message: "Error submitting inquiry" });
    }
  });

  app.get("/api/inquiries", async (req: Request, res: Response) => {
    try {
      const inquiries = await storage.getInquiries();
      res.json(inquiries);
    } catch (error) {
      res.status(500).json({ message: "Error fetching inquiries" });
    }
  });

  app.get("/api/inquiries/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid inquiry ID" });
      }
      
      const inquiry = await storage.getInquiryById(id);
      if (!inquiry) {
        return res.status(404).json({ message: "Inquiry not found" });
      }
      
      res.json(inquiry);
    } catch (error) {
      res.status(500).json({ message: "Error fetching inquiry details" });
    }
  });

  // API routes for testimonials
  app.get("/api/testimonials", async (req: Request, res: Response) => {
    try {
      const testimonials = await storage.getTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ message: "Error fetching testimonials" });
    }
  });

  app.get("/api/testimonials/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid testimonial ID" });
      }
      
      const testimonial = await storage.getTestimonialById(id);
      if (!testimonial) {
        return res.status(404).json({ message: "Testimonial not found" });
      }
      
      res.json(testimonial);
    } catch (error) {
      res.status(500).json({ message: "Error fetching testimonial details" });
    }
  });

  app.post("/api/testimonials", async (req: Request, res: Response) => {
    try {
      const testimonialData = insertTestimonialSchema.parse(req.body);
      const testimonial = await storage.createTestimonial(testimonialData);
      res.status(201).json(testimonial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid testimonial data", errors: error.issues });
      }
      res.status(500).json({ message: "Error submitting testimonial" });
    }
  });
  
  // API routes for trade-in requests
  app.post("/api/trade-in", async (req: Request, res: Response) => {
    try {
      const tradeInData = insertTradeInSchema.parse(req.body);
      const tradeIn = await storage.createTradeIn(tradeInData);
      res.status(201).json(tradeIn);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid trade-in data", errors: error.issues });
      }
      res.status(500).json({ message: "Error submitting trade-in request" });
    }
  });
  
  app.get("/api/trade-in", async (req: Request, res: Response) => {
    try {
      const tradeIns = await storage.getTradeIns();
      res.json(tradeIns);
    } catch (error) {
      res.status(500).json({ message: "Error fetching trade-in requests" });
    }
  });
  
  app.get("/api/trade-in/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid trade-in ID" });
      }
      
      const tradeIn = await storage.getTradeInById(id);
      if (!tradeIn) {
        return res.status(404).json({ message: "Trade-in request not found" });
      }
      
      res.json(tradeIn);
    } catch (error) {
      res.status(500).json({ message: "Error fetching trade-in details" });
    }
  });
  
  app.put("/api/trade-in/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid trade-in ID" });
      }
      
      const { status } = req.body;
      if (!status || typeof status !== 'string') {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const tradeIn = await storage.getTradeInById(id);
      if (!tradeIn) {
        return res.status(404).json({ message: "Trade-in request not found" });
      }
      
      const updatedTradeIn = await storage.updateTradeInStatus(id, status);
      res.json(updatedTradeIn);
    } catch (error) {
      res.status(500).json({ message: "Error updating trade-in status" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
