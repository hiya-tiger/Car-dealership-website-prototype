import { 
  users, 
  type User, 
  type InsertUser, 
  vehicles, 
  type Vehicle, 
  type InsertVehicle, 
  inquiries, 
  type Inquiry, 
  type InsertInquiry, 
  testimonials, 
  type Testimonial, 
  type InsertTestimonial,
  tradeIns,
  type TradeIn,
  type InsertTradeIn
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Vehicle methods
  getVehicles(): Promise<Vehicle[]>;
  getVehicleById(id: number): Promise<Vehicle | undefined>;
  getFeaturedVehicles(): Promise<Vehicle[]>;
  getSpecialOfferVehicles(): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<Vehicle>): Promise<Vehicle | undefined>;
  deleteVehicle(id: number): Promise<boolean>;
  
  // Inquiry methods
  getInquiries(): Promise<Inquiry[]>;
  getInquiryById(id: number): Promise<Inquiry | undefined>;
  getInquiriesByVehicleId(vehicleId: number): Promise<Inquiry[]>;
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
  
  // Testimonial methods
  getTestimonials(): Promise<Testimonial[]>;
  getTestimonialById(id: number): Promise<Testimonial | undefined>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  
  // Trade-In methods
  getTradeIns(): Promise<TradeIn[]>;
  getTradeInById(id: number): Promise<TradeIn | undefined>;
  createTradeIn(tradeIn: InsertTradeIn): Promise<TradeIn>;
  updateTradeInStatus(id: number, status: string): Promise<TradeIn | undefined>;

  // Database management
  initializeDatabase?(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private vehicles: Map<number, Vehicle>;
  private inquiries: Map<number, Inquiry>;
  private testimonials: Map<number, Testimonial>;
  private tradeIns: Map<number, TradeIn>;
  
  private userId: number;
  private vehicleId: number;
  private inquiryId: number;
  private testimonialId: number;
  private tradeInId: number;

  constructor() {
    this.users = new Map();
    this.vehicles = new Map();
    this.inquiries = new Map();
    this.testimonials = new Map();
    this.tradeIns = new Map();
    
    this.userId = 1;
    this.vehicleId = 1;
    this.inquiryId = 1;
    this.testimonialId = 1;
    this.tradeInId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Vehicle methods
  async getVehicles(): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values());
  }
  
  async getVehicleById(id: number): Promise<Vehicle | undefined> {
    return this.vehicles.get(id);
  }
  
  async getFeaturedVehicles(): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values()).filter(
      (vehicle) => vehicle.isFeatured
    );
  }
  
  async getSpecialOfferVehicles(): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values()).filter(
      (vehicle) => vehicle.isSpecialOffer
    );
  }
  
  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const id = this.vehicleId++;
    const createdAt = new Date();
    
    // Ensure arrays and optional fields are not undefined
    const vehicle: Vehicle = { 
      ...insertVehicle, 
      id, 
      createdAt,
      // Ensure that status always has a value with a fallback to "available"
      status: insertVehicle.status ?? "available",
      features: insertVehicle.features || null,
      images: insertVehicle.images || [],
      mpgCity: insertVehicle.mpgCity || null,
      mpgHighway: insertVehicle.mpgHighway || null,
      engineDescription: insertVehicle.engineDescription || null,
      horsepower: insertVehicle.horsepower || null,
      torque: insertVehicle.torque || null,
      monthlyPayment: insertVehicle.monthlyPayment || null,
      modelUrl: insertVehicle.modelUrl || null,
      interiorModelUrl: insertVehicle.interiorModelUrl || null,
      arModelUrl: insertVehicle.arModelUrl || null,
      arModelScale: insertVehicle.arModelScale || 1.0,
      isFeatured: insertVehicle.isFeatured === undefined ? null : insertVehicle.isFeatured,
      isSpecialOffer: insertVehicle.isSpecialOffer === undefined ? null : insertVehicle.isSpecialOffer,
      // CarFax fields
      carfaxLink: insertVehicle.carfaxLink || null,
      carfaxReportDate: insertVehicle.carfaxReportDate || null,
      carfaxOwners: insertVehicle.carfaxOwners || null,
      carfaxAccidents: insertVehicle.carfaxAccidents || null,
      carfaxServiceRecords: insertVehicle.carfaxServiceRecords || null
    };
    
    this.vehicles.set(id, vehicle);
    return vehicle;
  }
  
  async updateVehicle(id: number, updatedFields: Partial<Vehicle>): Promise<Vehicle | undefined> {
    const vehicle = this.vehicles.get(id);
    if (!vehicle) return undefined;
    
    const updatedVehicle = { ...vehicle, ...updatedFields };
    this.vehicles.set(id, updatedVehicle);
    return updatedVehicle;
  }
  
  async deleteVehicle(id: number): Promise<boolean> {
    return this.vehicles.delete(id);
  }
  
  // Inquiry methods
  async getInquiries(): Promise<Inquiry[]> {
    return Array.from(this.inquiries.values());
  }
  
  async getInquiryById(id: number): Promise<Inquiry | undefined> {
    return this.inquiries.get(id);
  }
  
  async getInquiriesByVehicleId(vehicleId: number): Promise<Inquiry[]> {
    return Array.from(this.inquiries.values()).filter(
      (inquiry) => inquiry.vehicleId === vehicleId
    );
  }
  
  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const id = this.inquiryId++;
    const createdAt = new Date();
    
    // Ensure vehicleId is not undefined
    const inquiry: Inquiry = { 
      ...insertInquiry, 
      id, 
      createdAt,
      vehicleId: insertInquiry.vehicleId || null
    };
    
    this.inquiries.set(id, inquiry);
    return inquiry;
  }
  
  // Testimonial methods
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }
  
  async getTestimonialById(id: number): Promise<Testimonial | undefined> {
    return this.testimonials.get(id);
  }
  
  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.testimonialId++;
    const createdAt = new Date();
    
    // Ensure imageUrl is not undefined
    const testimonial: Testimonial = { 
      ...insertTestimonial, 
      id, 
      createdAt,
      imageUrl: insertTestimonial.imageUrl || null
    };
    
    this.testimonials.set(id, testimonial);
    return testimonial;
  }
  
  // Trade-In methods
  async getTradeIns(): Promise<TradeIn[]> {
    return Array.from(this.tradeIns.values());
  }
  
  async getTradeInById(id: number): Promise<TradeIn | undefined> {
    return this.tradeIns.get(id);
  }
  
  async createTradeIn(insertTradeIn: InsertTradeIn): Promise<TradeIn> {
    const id = this.tradeInId++;
    const createdAt = new Date();
    
    // Create the trade-in request with default "pending" status
    const tradeIn: TradeIn = { 
      ...insertTradeIn, 
      id, 
      createdAt,
      status: "pending",
      comments: insertTradeIn.comments || null
    };
    
    this.tradeIns.set(id, tradeIn);
    return tradeIn;
  }
  
  async updateTradeInStatus(id: number, status: string): Promise<TradeIn | undefined> {
    const tradeIn = this.tradeIns.get(id);
    if (!tradeIn) return undefined;
    
    const updatedTradeIn = { ...tradeIn, status };
    this.tradeIns.set(id, updatedTradeIn);
    return updatedTradeIn;
  }
  
  private initializeData() {
    // Initialize sample testimonials
    const sampleTestimonials: InsertTestimonial[] = [
      {
        name: "Sarah Johnson",
        rating: 5,
        review: "I had an amazing experience buying my Toyota Camry from 89 Autosales. The staff was knowledgeable and helped me find the perfect car within my budget. The financing process was smooth and transparent.",
        vehicle: "Toyota Camry",
        imageUrl: "https://randomuser.me/api/portraits/women/65.jpg"
      },
      {
        name: "Michael Rodriguez",
        rating: 4,
        review: "The team at 89 Autosales went above and beyond to help me find my dream car. They were patient through the whole process and made sure I got the best financing rate possible. Would definitely recommend!",
        vehicle: "Honda Accord",
        imageUrl: "https://randomuser.me/api/portraits/men/32.jpg"
      },
      {
        name: "Emily Chen",
        rating: 5,
        review: "As a first-time car buyer, I was nervous about the process. The team at 89 Autosales made it simple and stress-free. They answered all my questions and found me a great car with payments I can afford.",
        vehicle: "Mazda CX-5",
        imageUrl: "https://randomuser.me/api/portraits/women/45.jpg"
      }
    ];
    
    sampleTestimonials.forEach(testimonial => {
      this.createTestimonial(testimonial);
    });
    
    // Initialize sample vehicles
    const sampleVehicles: InsertVehicle[] = [
      {
        make: "Toyota",
        model: "Camry",
        year: 2019,
        price: 21995,
        mileage: 42530,
        exteriorColor: "Blue",
        interiorColor: "Black",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "3.5L V6",
        description: "This 2019 Toyota Camry XSE V6 is in excellent condition with just 42,530 miles. Features include a V6 engine, leather seats, panoramic sunroof, and Toyota Safety Sense package.",
        features: ["Leather Seats", "Panoramic Sunroof", "Navigation", "Bluetooth", "Backup Camera", "Heated Seats"],
        images: ["https://images.unsplash.com/photo-1583121274602-3e2820c69888?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "4T1BZ1HK5KU123456",
        mpgCity: 28,
        mpgHighway: 39,
        engineDescription: "3.5L V6",
        horsepower: 301,
        torque: 267,
        isFeatured: true,
        isSpecialOffer: false,
        monthlyPayment: 329,
        modelUrl: "https://storage.googleapis.com/vehicle-models/camry.glb",
        interiorModelUrl: "https://storage.googleapis.com/vehicle-models/camry-interior.glb",
        arModelUrl: "https://storage.googleapis.com/vehicle-models/camry-ar.glb",
        arModelScale: 0.8,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=4T1BZ1HK5KU123456",
        carfaxReportDate: new Date("2023-10-10"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 10
      },
      {
        make: "Honda",
        model: "Accord",
        year: 2020,
        price: 24495,
        mileage: 31245,
        exteriorColor: "Black",
        interiorColor: "Gray",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "2.0L Turbo",
        description: "This 2020 Honda Accord Sport 2.0T is a sporty yet practical sedan with a powerful turbocharged engine. Low mileage and excellent condition make this a great value.",
        features: ["Apple CarPlay", "Android Auto", "Heated Seats", "Blind Spot Monitor", "Lane Keep Assist", "Adaptive Cruise Control"],
        images: ["https://images.unsplash.com/photo-1617469767053-d3b16ee9a13e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "1HGCV2F33LA123456",
        mpgCity: 22,
        mpgHighway: 32,
        engineDescription: "2.0L Turbocharged I4",
        horsepower: 252,
        torque: 273,
        isFeatured: true,
        isSpecialOffer: false,
        monthlyPayment: 369,
        modelUrl: "https://storage.googleapis.com/vehicle-models/accord.glb",
        interiorModelUrl: "https://storage.googleapis.com/vehicle-models/accord-interior.glb",
        arModelUrl: "https://storage.googleapis.com/vehicle-models/accord-ar.glb",
        arModelScale: 0.75,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=1HGCV2F33LA123456",
        carfaxReportDate: new Date("2023-12-15"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 12
      },
      {
        make: "BMW",
        model: "5 Series",
        year: 2018,
        price: 32995,
        mileage: 38120,
        exteriorColor: "Silver",
        interiorColor: "Black",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "3.0L Turbocharged I6",
        description: "Luxurious 2018 BMW 540i xDrive with premium features including heated leather seats, premium sound system, and advanced driver assistance package.",
        features: ["All-Wheel Drive", "Leather Seats", "Premium Sound System", "Navigation", "Parking Sensors", "Heated Steering Wheel"],
        images: ["https://images.unsplash.com/photo-1609061802877-57db91614da6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "WBAJB9C57JB123456",
        mpgCity: 21,
        mpgHighway: 29,
        engineDescription: "3.0L Turbocharged I6",
        horsepower: 335,
        torque: 332,
        isFeatured: false,
        isSpecialOffer: true,
        monthlyPayment: 489,
        modelUrl: "https://storage.googleapis.com/vehicle-models/bmw5.glb",
        interiorModelUrl: "https://storage.googleapis.com/vehicle-models/bmw5-interior.glb",
        arModelUrl: "https://storage.googleapis.com/vehicle-models/bmw5-ar.glb",
        arModelScale: 0.9,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=WBAJB9C57JB123456",
        carfaxReportDate: new Date("2023-11-20"),
        carfaxOwners: 2,
        carfaxAccidents: 1,
        carfaxServiceRecords: 18
      },
      {
        make: "Ford",
        model: "Mustang",
        year: 2021,
        price: 38995,
        mileage: 18750,
        exteriorColor: "Red",
        interiorColor: "Black",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Coupe",
        engineSize: "5.0L V8",
        description: "Powerful 2021 Ford Mustang GT Premium with the iconic 5.0L V8 engine. Features include leather seats, premium audio, and the GT performance package.",
        features: ["5.0L V8 Engine", "Leather Seats", "Backup Camera", "Apple CarPlay", "Android Auto", "Premium Audio"],
        images: ["https://images.unsplash.com/photo-1551830820-330a71b99659?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "1FA6P8CF3M5123456",
        mpgCity: 15,
        mpgHighway: 24,
        engineDescription: "5.0L V8",
        horsepower: 460,
        torque: 420,
        isFeatured: true,
        isSpecialOffer: false,
        monthlyPayment: 549,
        modelUrl: "https://storage.googleapis.com/vehicle-models/mustang.glb",
        interiorModelUrl: "https://storage.googleapis.com/vehicle-models/mustang-interior.glb",
        arModelUrl: "https://storage.googleapis.com/vehicle-models/mustang-ar.glb",
        arModelScale: 0.85,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=1FA6P8CF3M5123456",
        carfaxReportDate: new Date("2024-01-05"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 6
      },
      {
        make: "Chevrolet",
        model: "Silverado",
        year: 2020,
        price: 41995,
        mileage: 28500,
        exteriorColor: "White",
        interiorColor: "Gray",
        fuelType: "Gasoline",
        transmission: "Automatic",
        bodyStyle: "Truck",
        engineSize: "5.3L V8",
        description: "Powerful and capable 2020 Chevrolet Silverado LT with the Z71 Off-Road Package. Perfect for work or play with impressive towing capacity and comfort.",
        features: ["4x4", "Z71 Off-Road Package", "Towing Package", "Bed Liner", "Touchscreen Infotainment", "Backup Camera"],
        images: ["https://images.unsplash.com/photo-1581752825773-7c607d6d2421?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "3GCUYDED7LG123456",
        mpgCity: 16,
        mpgHighway: 21,
        engineDescription: "5.3L V8",
        horsepower: 355,
        torque: 383,
        isFeatured: false,
        isSpecialOffer: false,
        monthlyPayment: 599,
        modelUrl: "https://storage.googleapis.com/vehicle-models/silverado.glb",
        interiorModelUrl: "https://storage.googleapis.com/vehicle-models/silverado-interior.glb",
        arModelUrl: "https://storage.googleapis.com/vehicle-models/silverado-ar.glb",
        arModelScale: 1.0,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=3GCUYDED7LG123456",
        carfaxReportDate: new Date("2023-09-20"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 9
      },
      {
        make: "Tesla",
        model: "Model 3",
        year: 2022,
        price: 44995,
        mileage: 12500,
        exteriorColor: "Blue",
        interiorColor: "White",
        fuelType: "Electric",
        transmission: "Automatic",
        bodyStyle: "Sedan",
        engineSize: "Dual Motor Electric",
        description: "Nearly-new 2022 Tesla Model 3 Long Range with dual motor all-wheel drive. Features include Autopilot, premium interior, and an exceptional electric range.",
        features: ["Electric", "Autopilot", "Glass Roof", "Premium Interior", "All-Wheel Drive", "Fast Charging"],
        images: ["https://images.unsplash.com/photo-1560958089-b8a1929cea89?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"],
        vin: "5YJ3E1EA8NF123456",
        mpgCity: 0,
        mpgHighway: 0,
        engineDescription: "Dual Motor Electric",
        horsepower: 346,
        torque: 389,
        isFeatured: true,
        isSpecialOffer: true,
        monthlyPayment: 649,
        modelUrl: "https://storage.googleapis.com/vehicle-models/tesla3.glb",
        interiorModelUrl: "https://storage.googleapis.com/vehicle-models/tesla3-interior.glb",
        arModelUrl: "https://storage.googleapis.com/vehicle-models/tesla3-ar.glb",
        arModelScale: 0.8,
        carfaxLink: "https://www.carfax.com/VehicleHistory/p/Report.cfx?vin=5YJ3E1EA8NF123456",
        carfaxReportDate: new Date("2024-02-10"),
        carfaxOwners: 1,
        carfaxAccidents: 0,
        carfaxServiceRecords: 4
      }
    ];
    
    sampleVehicles.forEach(vehicle => {
      this.createVehicle(vehicle);
    });
  }
}

// For now we're using MemStorage, but this can be swapped to DatabaseStorage when needed
export const storage = new MemStorage();
