#!/usr/bin/env node
/**
 * PostgreSQL Command Line Tools Wrapper
 * 
 * This utility provides a simplified interface for common PostgreSQL CLI commands:
 * 1. psql - Run SQL commands directly
 * 2. pg_dump - Export databases or tables
 * 3. pg_restore - Restore a database from a dump file
 * 4. createdb - Create a new database
 * 5. dropdb - Drop a database
 * 
 * Usage:
 *   - Interactive SQL: node pg-cli-tools.js psql [sql_command]
 *   - Dump database: node pg-cli-tools.js dump [output_file] [options]
 *   - Restore database: node pg-cli-tools.js restore [input_file] [options]
 *   - Create database: node pg-cli-tools.js createdb [db_name]
 *   - Drop database: node pg-cli-tools.js dropdb [db_name]
 */

const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// Helper function to check environment variables
function checkEnvironment() {
  const requiredVars = ['DATABASE_URL', 'PGHOST', 'PGUSER', 'PGPASSWORD', 'PGDATABASE', 'PGPORT'];
  let missingVars = [];
  
  for (const envVar of requiredVars) {
    if (!process.env[envVar]) {
      missingVars.push(envVar);
    }
  }
  
  if (missingVars.length > 0) {
    console.error(`Error: Missing environment variables: ${missingVars.join(', ')}`);
    console.error('Make sure you are running this script in the Replit environment where the database is configured.');
    process.exit(1);
  }
  
  return true;
}

// Run PSQL command
async function runPsql(sqlCommand = null) {
  checkEnvironment();
  
  const psqlEnv = {
    ...process.env,
    PGPASSWORD: process.env.PGPASSWORD
  };
  
  if (sqlCommand) {
    // Run specific SQL command
    console.log(`Executing SQL command: ${sqlCommand}`);
    
    try {
      const result = execSync(
        `psql -h ${process.env.PGHOST} -U ${process.env.PGUSER} -d ${process.env.PGDATABASE} -p ${process.env.PGPORT} -c "${sqlCommand.replace(/"/g, '\\"')}"`,
        { env: psqlEnv, encoding: 'utf8' }
      );
      
      console.log('Result:');
      console.log(result);
    } catch (error) {
      console.error('Error executing SQL command:', error.message);
      process.exit(1);
    }
  } else {
    // Start interactive PSQL session
    console.log('Starting interactive PostgreSQL session...');
    console.log('Type "\\q" to exit.');
    
    const psql = spawn(
      'psql',
      [
        '-h', process.env.PGHOST,
        '-U', process.env.PGUSER,
        '-d', process.env.PGDATABASE,
        '-p', process.env.PGPORT
      ],
      { env: psqlEnv, stdio: 'inherit' }
    );
    
    psql.on('close', (code) => {
      console.log(`PostgreSQL session ended with code ${code}`);
    });
  }
}

// Dump database or table
async function dumpDatabase(outputFile, options = {}) {
  checkEnvironment();
  
  if (!outputFile) {
    outputFile = `${process.env.PGDATABASE}_dump_${Date.now()}.sql`;
  }
  
  console.log(`Dumping database to ${outputFile}...`);
  
  const dumpEnv = {
    ...process.env,
    PGPASSWORD: process.env.PGPASSWORD
  };
  
  let args = [
    '-h', process.env.PGHOST,
    '-U', process.env.PGUSER,
    '-p', process.env.PGPORT,
    '-f', outputFile
  ];
  
  // Add options
  if (options.format) {
    args.push('-F', options.format); // Format (c for custom, p for plain, etc.)
  }
  
  if (options.schema) {
    args.push('-n', options.schema); // Schema
  }
  
  if (options.table) {
    args.push('-t', options.table); // Specific table
  }
  
  if (options.clean) {
    args.push('--clean'); // Add drop commands
  }
  
  if (options.data_only) {
    args.push('--data-only'); // Only data, no schema
  }
  
  if (options.schema_only) {
    args.push('--schema-only'); // Only schema, no data
  }
  
  // Add database name
  args.push(process.env.PGDATABASE);
  
  try {
    execSync(`pg_dump ${args.join(' ')}`, { env: dumpEnv, stdio: 'inherit' });
    
    // Get file size
    const stats = fs.statSync(outputFile);
    console.log(`Dump completed: ${outputFile} (${(stats.size / 1024 / 1024).toFixed(2)} MB)`);
  } catch (error) {
    console.error('Error dumping database:', error.message);
    process.exit(1);
  }
}

// Restore database from dump
async function restoreDatabase(inputFile, options = {}) {
  checkEnvironment();
  
  if (!inputFile || !fs.existsSync(inputFile)) {
    console.error(`Error: Input file ${inputFile} does not exist.`);
    process.exit(1);
  }
  
  // Confirm restore
  const confirmed = await confirmAction('This will overwrite database objects. Continue?');
  if (!confirmed) {
    console.log('Restore operation canceled.');
    return;
  }
  
  console.log(`Restoring database from ${inputFile}...`);
  
  const restoreEnv = {
    ...process.env,
    PGPASSWORD: process.env.PGPASSWORD
  };
  
  // Determine if using pg_restore or psql based on file format
  const fileExt = path.extname(inputFile).toLowerCase();
  let command = '';
  
  if (fileExt === '.sql') {
    // Plain SQL file, use psql
    command = `psql -h ${process.env.PGHOST} -U ${process.env.PGUSER} -d ${process.env.PGDATABASE} -p ${process.env.PGPORT} -f ${inputFile}`;
  } else {
    // Custom format, use pg_restore
    let args = [
      '-h', process.env.PGHOST,
      '-U', process.env.PGUSER,
      '-d', process.env.PGDATABASE,
      '-p', process.env.PGPORT
    ];
    
    // Add options
    if (options.clean) {
      args.push('--clean');
    }
    
    if (options.single_transaction) {
      args.push('--single-transaction');
    }
    
    if (options.no_owner) {
      args.push('--no-owner');
    }
    
    // Add input file
    args.push(inputFile);
    
    command = `pg_restore ${args.join(' ')}`;
  }
  
  try {
    execSync(command, { env: restoreEnv, stdio: 'inherit' });
    console.log('Database restore completed successfully.');
  } catch (error) {
    console.error('Error restoring database:', error.message);
    process.exit(1);
  }
}

// Create a new database
async function createDatabase(dbName) {
  checkEnvironment();
  
  if (!dbName) {
    console.error('Error: Database name is required.');
    process.exit(1);
  }
  
  console.log(`Creating database "${dbName}"...`);
  
  const createEnv = {
    ...process.env,
    PGPASSWORD: process.env.PGPASSWORD
  };
  
  try {
    execSync(
      `createdb -h ${process.env.PGHOST} -U ${process.env.PGUSER} -p ${process.env.PGPORT} ${dbName}`,
      { env: createEnv, stdio: 'inherit' }
    );
    console.log(`Database "${dbName}" created successfully.`);
  } catch (error) {
    console.error('Error creating database:', error.message);
    process.exit(1);
  }
}

// Drop a database
async function dropDatabase(dbName) {
  checkEnvironment();
  
  if (!dbName) {
    console.error('Error: Database name is required.');
    process.exit(1);
  }
  
  if (dbName === process.env.PGDATABASE) {
    console.error('Error: Cannot drop the current database. Connect to a different database first.');
    process.exit(1);
  }
  
  // Confirm drop
  const confirmed = await confirmAction(`This will permanently delete database "${dbName}". Continue?`);
  if (!confirmed) {
    console.log('Drop operation canceled.');
    return;
  }
  
  console.log(`Dropping database "${dbName}"...`);
  
  const dropEnv = {
    ...process.env,
    PGPASSWORD: process.env.PGPASSWORD
  };
  
  try {
    execSync(
      `dropdb -h ${process.env.PGHOST} -U ${process.env.PGUSER} -p ${process.env.PGPORT} ${dbName}`,
      { env: dropEnv, stdio: 'inherit' }
    );
    console.log(`Database "${dbName}" dropped successfully.`);
  } catch (error) {
    console.error('Error dropping database:', error.message);
    process.exit(1);
  }
}

// Helper function to confirm an action
function confirmAction(message) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise((resolve) => {
    rl.question(`${message} (y/N): `, (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y');
    });
  });
}

// Parse options from command line arguments
function parseOptions(args) {
  const options = {};
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      const optName = arg.substring(2).replace(/-/g, '_');
      
      if (i + 1 < args.length && !args[i + 1].startsWith('--')) {
        options[optName] = args[i + 1];
        i++; // Skip the next argument as it's the value
      } else {
        options[optName] = true;
      }
    }
  }
  
  return options;
}

// Main function
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  if (!command) {
    console.error('Error: Missing command. Available commands: psql, dump, restore, createdb, dropdb');
    process.exit(1);
  }
  
  switch (command.toLowerCase()) {
    case 'psql':
      await runPsql(args[1]); // Optional SQL command
      break;
      
    case 'dump':
      const dumpOptions = parseOptions(args.slice(2));
      await dumpDatabase(args[1], dumpOptions);
      break;
      
    case 'restore':
      const restoreOptions = parseOptions(args.slice(2));
      await restoreDatabase(args[1], restoreOptions);
      break;
      
    case 'createdb':
      await createDatabase(args[1]);
      break;
      
    case 'dropdb':
      await dropDatabase(args[1]);
      break;
      
    default:
      console.error(`Error: Unknown command "${command}". Available commands: psql, dump, restore, createdb, dropdb`);
      process.exit(1);
  }
}

// Run the main function
main().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});