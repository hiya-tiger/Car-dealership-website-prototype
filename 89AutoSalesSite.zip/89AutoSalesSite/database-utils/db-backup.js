/**
 * Database Backup/Import Utility for 89 Auto Sales
 * 
 * This script provides command line utilities to:
 * 1. Export the current database to a SQL backup file
 * 2. Import a SQL backup file to restore the database
 * 3. Create a ZIP archive of the database backup
 * 
 * Usage:
 *   - Export: node db-backup.js export [output_file.sql]
 *   - Import: node db-backup.js import [input_file.sql]
 *   - Zip: node db-backup.js zip [input_file.sql] [output_file.zip]
 *
 * If no filename is provided, it uses the default: dealership_backup.sql
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const archiver = require('archiver');

// Default filename
const DEFAULT_BACKUP_FILE = 'dealership_backup.sql';
const DEFAULT_ZIP_FILE = 'dealership_backup.zip';

// Get the database connection details from environment variables
function checkEnvironment() {
  const requiredVars = ['DATABASE_URL', 'PGHOST', 'PGUSER', 'PGPASSWORD', 'PGDATABASE', 'PGPORT'];
  
  for (const envVar of requiredVars) {
    if (!process.env[envVar]) {
      console.error(`Error: Required environment variable ${envVar} is not set.`);
      console.error('Make sure you are running this script in the Replit environment where the database is configured.');
      process.exit(1);
    }
  }
  
  console.log('Environment variables verified.');
}

// Export database to SQL file
async function exportDatabase(outputFile = DEFAULT_BACKUP_FILE) {
  console.log(`Exporting database to ${outputFile}...`);
  
  try {
    // Create backups directory if it doesn't exist
    const backupDir = path.dirname(outputFile);
    if (!fs.existsSync(backupDir) && backupDir !== '.') {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    // Use pg_dump to export the database
    const command = `pg_dump -h ${process.env.PGHOST} -U ${process.env.PGUSER} -d ${process.env.PGDATABASE} -p ${process.env.PGPORT} -f ${outputFile}`;
    
    execSync(command, { 
      env: { ...process.env, PGPASSWORD: process.env.PGPASSWORD },
      stdio: 'inherit' 
    });
    
    console.log(`Database export completed successfully: ${outputFile}`);
    
    // Get file size
    const stats = fs.statSync(outputFile);
    console.log(`Backup file size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
    
    return outputFile;
  } catch (error) {
    console.error('Error exporting database:', error.message);
    process.exit(1);
  }
}

// Import SQL file into database
async function importDatabase(inputFile = DEFAULT_BACKUP_FILE) {
  // Check if file exists
  if (!fs.existsSync(inputFile)) {
    console.error(`Error: Import file ${inputFile} does not exist.`);
    process.exit(1);
  }
  
  // Confirm import
  const shouldProceed = await confirmImport();
  if (!shouldProceed) {
    console.log('Import canceled.');
    process.exit(0);
  }
  
  console.log(`Importing database from ${inputFile}...`);
  
  try {
    // Use psql to import the database
    const command = `psql -h ${process.env.PGHOST} -U ${process.env.PGUSER} -d ${process.env.PGDATABASE} -p ${process.env.PGPORT} -f ${inputFile}`;
    
    execSync(command, { 
      env: { ...process.env, PGPASSWORD: process.env.PGPASSWORD },
      stdio: 'inherit' 
    });
    
    console.log('Database import completed successfully.');
  } catch (error) {
    console.error('Error importing database:', error.message);
    process.exit(1);
  }
}

// Confirm database import
function confirmImport() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise((resolve) => {
    rl.question('WARNING: This will overwrite the current database. Continue? (y/N): ', (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y');
    });
  });
}

// Create a ZIP archive of the database backup
async function createZipArchive(inputFile = DEFAULT_BACKUP_FILE, outputZip = DEFAULT_ZIP_FILE) {
  // Check if input file exists
  if (!fs.existsSync(inputFile)) {
    console.error(`Error: Input file ${inputFile} does not exist.`);
    process.exit(1);
  }
  
  console.log(`Creating ZIP archive: ${outputZip}`);
  
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputZip);
    const archive = archiver('zip', {
      zlib: { level: 9 } // Maximum compression
    });
    
    output.on('close', () => {
      console.log(`ZIP archive created successfully: ${outputZip}`);
      console.log(`Archive size: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`);
      resolve(outputZip);
    });
    
    archive.on('error', (err) => {
      console.error('Error creating ZIP archive:', err);
      reject(err);
    });
    
    archive.pipe(output);
    
    // Add the SQL file to the archive
    archive.file(inputFile, { name: path.basename(inputFile) });
    
    // Add a timestamp file with metadata
    const timestamp = new Date().toISOString();
    const metadata = `Backup created: ${timestamp}\nDatabase: ${process.env.PGDATABASE}\n`;
    archive.append(metadata, { name: 'backup-info.txt' });
    
    archive.finalize();
  });
}

// Main function
async function main() {
  // Check if Node.js version is compatible
  const nodeVersion = process.version.slice(1).split('.')[0];
  if (parseInt(nodeVersion) < 12) {
    console.error('Error: This script requires Node.js version 12 or higher.');
    process.exit(1);
  }
  
  // Check environment variables
  checkEnvironment();
  
  // Parse command line arguments
  const [operation, filePath, secondPath] = process.argv.slice(2);
  
  if (!operation) {
    console.error('Error: Missing operation. Use "export", "import", or "zip".');
    process.exit(1);
  }
  
  switch (operation.toLowerCase()) {
    case 'export':
      await exportDatabase(filePath);
      break;
    case 'import':
      await importDatabase(filePath);
      break;
    case 'zip':
      // First export if no file is provided
      if (!filePath) {
        const exportedFile = await exportDatabase();
        await createZipArchive(exportedFile, secondPath);
      } else {
        await createZipArchive(filePath, secondPath);
      }
      break;
    default:
      console.error('Error: Invalid operation. Use "export", "import", or "zip".');
      process.exit(1);
  }
}

// Run the main function
main().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});