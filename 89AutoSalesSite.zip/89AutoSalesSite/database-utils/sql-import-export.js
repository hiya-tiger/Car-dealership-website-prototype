/**
 * SQL Import/Export Utility for 89 Auto Sales
 * 
 * This utility allows you to:
 * 1. Generate SQL export scripts for tables
 * 2. Create SQL import scripts for data insertion
 * 3. Export query results to CSV files
 * 
 * Usage:
 *   - Export table data: node sql-import-export.js export-table [table_name] [output_file.sql]
 *   - Export query results: node sql-import-export.js export-query [query] [output_file.csv]
 *   - Generate import script: node sql-import-export.js create-import [input_json_file] [table_name] [output_file.sql]
 */

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const { createObjectCsvWriter } = require('csv-writer');

// Initialize database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Check if the database connection works
async function checkConnection() {
  try {
    const client = await pool.connect();
    console.log('Database connection successful');
    client.release();
    return true;
  } catch (error) {
    console.error('Database connection error:', error.message);
    return false;
  }
}

// Export table data as SQL INSERT statements
async function exportTableData(tableName, outputFile) {
  if (!outputFile) {
    outputFile = `${tableName}_export.sql`;
  }
  
  console.log(`Exporting table '${tableName}' to ${outputFile}...`);
  
  try {
    // First, get the column names
    const columnsResult = await pool.query(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = $1
      ORDER BY ordinal_position
    `, [tableName]);
    
    if (columnsResult.rows.length === 0) {
      console.error(`Error: Table '${tableName}' does not exist or has no columns.`);
      process.exit(1);
    }
    
    const columns = columnsResult.rows.map(row => row.column_name);
    const dataTypes = {};
    columnsResult.rows.forEach(row => {
      dataTypes[row.column_name] = row.data_type;
    });
    
    // Get all data from the table
    const dataResult = await pool.query(`SELECT * FROM ${tableName}`);
    
    if (dataResult.rows.length === 0) {
      console.log(`Table '${tableName}' is empty. Generating structure only.`);
    }
    
    // Create the SQL file
    let sqlContent = `-- SQL Export for table '${tableName}'\n`;
    sqlContent += `-- Generated on ${new Date().toISOString()}\n\n`;
    
    // Add optional cleanup
    sqlContent += `-- Uncomment to clear table before import\n`;
    sqlContent += `-- DELETE FROM ${tableName};\n\n`;
    
    // Generate INSERT statements
    dataResult.rows.forEach(row => {
      const values = columns.map(col => {
        const value = row[col];
        if (value === null) {
          return 'NULL';
        } else if (
          dataTypes[col].includes('char') || 
          dataTypes[col].includes('text') || 
          dataTypes[col].includes('date') || 
          dataTypes[col].includes('time')
        ) {
          // Escape single quotes for string types
          return `'${(value + '').replace(/'/g, "''")}'`;
        } else if (dataTypes[col] === 'boolean') {
          return value ? 'TRUE' : 'FALSE';
        } else if (dataTypes[col] === 'json' || dataTypes[col] === 'jsonb') {
          return `'${JSON.stringify(value).replace(/'/g, "''")}'`;
        } else if (dataTypes[col].includes('array')) {
          // Special handling for string arrays like URL arrays and features
          if (Array.isArray(value)) {
            // Format array elements properly based on whether they're strings or not
            const formattedValues = value.map(item => {
              if (typeof item === 'string') {
                return `'${item.replace(/'/g, "''")}'`;
              }
              return item;
            });
            return `ARRAY[${formattedValues.join(', ')}]`;
          } else if (value === null) {
            return 'NULL';
          } else {
            return `ARRAY[${value}]`;
          }
        } else {
          return value;
        }
      });
      
      sqlContent += `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${values.join(', ')});\n`;
    });
    
    // Write to file
    fs.writeFileSync(outputFile, sqlContent);
    
    console.log(`Table exported successfully to ${outputFile}`);
    console.log(`Exported ${dataResult.rows.length} records.`);
    
    return outputFile;
  } catch (error) {
    console.error('Error exporting table:', error.message);
    process.exit(1);
  }
}

// Export query results to CSV
async function exportQueryToCsv(query, outputFile) {
  if (!outputFile) {
    outputFile = `query_result_${Date.now()}.csv`;
  }
  
  console.log(`Executing query and exporting results to ${outputFile}...`);
  
  try {
    // Execute the query
    const result = await pool.query(query);
    
    if (result.rows.length === 0) {
      console.log('Query returned no results.');
      return;
    }
    
    // Get column headers from the first row
    const headers = Object.keys(result.rows[0]).map(header => ({
      id: header,
      title: header
    }));
    
    // Create CSV writer
    const csvWriter = createObjectCsvWriter({
      path: outputFile,
      header: headers
    });
    
    // Write data to CSV
    await csvWriter.writeRecords(result.rows);
    
    console.log(`Query results exported successfully to ${outputFile}`);
    console.log(`Exported ${result.rows.length} records.`);
    
    return outputFile;
  } catch (error) {
    console.error('Error exporting query results:', error.message);
    process.exit(1);
  }
}

// Create SQL import script from JSON file
function createImportScript(inputJsonFile, tableName, outputFile) {
  if (!outputFile) {
    outputFile = `${tableName}_import.sql`;
  }
  
  console.log(`Creating import script for table '${tableName}' from ${inputJsonFile}...`);
  
  try {
    // Read and parse JSON file
    const jsonData = JSON.parse(fs.readFileSync(inputJsonFile, 'utf8'));
    
    if (!Array.isArray(jsonData)) {
      console.error('Error: Input JSON must be an array of objects.');
      process.exit(1);
    }
    
    if (jsonData.length === 0) {
      console.error('Error: Input JSON array is empty.');
      process.exit(1);
    }
    
    // Get columns from the first object
    const columns = Object.keys(jsonData[0]);
    
    // Create the SQL file
    let sqlContent = `-- SQL Import script for table '${tableName}'\n`;
    sqlContent += `-- Generated on ${new Date().toISOString()}\n`;
    sqlContent += `-- From JSON file: ${inputJsonFile}\n\n`;
    
    // Add optional cleanup
    sqlContent += `-- Uncomment to clear table before import\n`;
    sqlContent += `-- DELETE FROM ${tableName};\n\n`;
    
    // Generate INSERT statements
    jsonData.forEach(item => {
      const values = columns.map(col => {
        const value = item[col];
        if (value === null || value === undefined) {
          return 'NULL';
        } else if (typeof value === 'string') {
          // Escape single quotes for strings
          return `'${value.replace(/'/g, "''")}'`;
        } else if (typeof value === 'boolean') {
          return value ? 'TRUE' : 'FALSE';
        } else if (Array.isArray(value)) {
          // Handle array values like 3D/AR model URLs
          const formattedValues = value.map(item => {
            if (typeof item === 'string') {
              return `'${item.replace(/'/g, "''")}'`;
            } else if (item === null) {
              return 'NULL';
            } else if (typeof item === 'object') {
              return `'${JSON.stringify(item).replace(/'/g, "''")}'`;
            }
            return item;
          });
          return `ARRAY[${formattedValues.join(', ')}]`;
        } else if (typeof value === 'object') {
          return `'${JSON.stringify(value).replace(/'/g, "''")}'`;
        } else {
          return value;
        }
      });
      
      sqlContent += `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${values.join(', ')});\n`;
    });
    
    // Write to file
    fs.writeFileSync(outputFile, sqlContent);
    
    console.log(`Import script created successfully: ${outputFile}`);
    console.log(`Generated ${jsonData.length} INSERT statements.`);
    
    return outputFile;
  } catch (error) {
    console.error('Error creating import script:', error.message);
    process.exit(1);
  }
}

// Main function
async function main() {
  // Parse command line arguments
  const [operation, param1, param2, param3] = process.argv.slice(2);
  
  if (!operation) {
    console.error('Error: Missing operation. Use "export-table", "export-query", or "create-import".');
    process.exit(1);
  }
  
  // Check database connection
  const connected = await checkConnection();
  if (!connected && operation !== 'create-import') {
    console.error('Error: Could not connect to the database. Check your DATABASE_URL environment variable.');
    process.exit(1);
  }
  
  switch (operation.toLowerCase()) {
    case 'export-table':
      if (!param1) {
        console.error('Error: Missing table name.');
        process.exit(1);
      }
      await exportTableData(param1, param2);
      break;
    case 'export-query':
      if (!param1) {
        console.error('Error: Missing SQL query.');
        process.exit(1);
      }
      await exportQueryToCsv(param1, param2);
      break;
    case 'create-import':
      if (!param1 || !param2) {
        console.error('Error: Missing required parameters. Usage: create-import [input_json_file] [table_name] [output_file.sql]');
        process.exit(1);
      }
      createImportScript(param1, param2, param3);
      break;
    default:
      console.error('Error: Invalid operation. Use "export-table", "export-query", or "create-import".');
      process.exit(1);
  }
  
  // Close the database connection pool
  await pool.end();
}

// Run the main function
main().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});