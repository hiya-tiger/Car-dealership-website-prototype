# 89 Auto Sales Database Utilities

This directory contains a comprehensive set of database management utilities for the 89 Auto Sales dealership website. These tools enable efficient database operations, including backup, restoration, data import/export, and schema management.

## Available Utilities

### 1. Database Backup/Import Utility (`db-backup.js`)

This utility provides a simple interface for creating and restoring database backups.

**Usage:**
```
# Export database to a file
node db-backup.js export [output_file.sql]

# Import database from a file
node db-backup.js import [input_file.sql]

# Create a ZIP archive of database backup
node db-backup.js zip [input_file.sql] [output_file.zip]
```

### 2. SQL Import/Export Utility (`sql-import-export.js`)

Generate SQL scripts for exporting table data and importing from various sources.

**Usage:**
```
# Export table data as SQL INSERT statements
node sql-import-export.js export-table [table_name] [output_file.sql]

# Export query results to CSV
node sql-import-export.js export-query "SELECT * FROM vehicles WHERE status='Available'" [output_file.csv]

# Generate SQL import script from JSON data
node sql-import-export.js create-import [input_json_file] [table_name] [output_file.sql]
```

### 3. PostgreSQL CLI Tools Wrapper (`pg-cli-tools.js`)

A simplified interface for common PostgreSQL command-line operations.

**Usage:**
```
# Start interactive psql session
node pg-cli-tools.js psql

# Run a specific SQL command
node pg-cli-tools.js psql "SELECT * FROM users"

# Dump database to a file
node pg-cli-tools.js dump [output_file] --format=p --clean

# Restore database from a file
node pg-cli-tools.js restore [input_file] --clean --single-transaction

# Create a new database
node pg-cli-tools.js createdb [db_name]

# Drop a database
node pg-cli-tools.js dropdb [db_name]
```

### 4. Drizzle Schema Manager (`drizzle-manager.js`)

Manage database schema using Drizzle ORM.

**Usage:**
```
# Push schema changes directly to the database
node drizzle-manager.js push

# Generate migration files
node drizzle-manager.js generate [migration_name]

# Apply migrations
node drizzle-manager.js migrate

# Check for schema changes
node drizzle-manager.js check
```

### 5. Data Import/Export Utility (`data-import-export.js`)

Import and export data in various formats (CSV, JSON, XLSX), including support for 3D and AR model URLs.

**Usage:**
```
# Import data from a file
node data-import-export.js import [format] [table] [file]
# Example: node data-import-export.js import csv vehicles vehicles.csv

# Export data to a file
node data-import-export.js export [format] [table] [file]
# Example: node data-import-export.js export json vehicles vehicles.json

# Create a snapshot of multiple tables
node data-import-export.js snapshot [table1] [table2] ...
# Example: node data-import-export.js snapshot vehicles inquiries testimonials

# Restore data from a snapshot
node data-import-export.js restore [snapshot_file]
```

**3D and AR Model Handling:**
The utility includes special handling for 3D and AR model fields in the vehicles table:
- `modelUrl`: URL to 3D models for exterior vehicle viewing
- `interiorModelUrl`: URL to 3D models for interior vehicle viewing
- `arModelUrl`: URL to AR models for augmented reality placement
- `arModelScale`: Scale factor for AR models (automatically preserved during import/export)

These fields are validated as proper URLs during import and properly formatted when exporting to ensure data integrity for the 3D/AR features in the dealership website.

## Installation

These utilities use Node.js and require several dependencies. The necessary packages are already installed in the project.

## Environment Variables

All utilities rely on the following environment variables for database connection:
- `DATABASE_URL`: The database connection string
- `PGHOST`: PostgreSQL server hostname
- `PGUSER`: PostgreSQL username
- `PGPASSWORD`: PostgreSQL password
- `PGDATABASE`: PostgreSQL database name
- `PGPORT`: PostgreSQL server port

These variables are automatically configured in the Replit environment.

## Best Practices

1. **Always create a backup** before making significant changes to the database.
2. Use the **schema manager** for schema changes rather than writing direct SQL ALTER statements.
3. For data migration, prefer the **data import/export utility** with proper validation.
4. When sharing database snapshots, use the **ZIP archive** feature to compress the files.
5. Test imports on a development database before applying to production.

## Common Workflows

### Complete Database Backup and Restore

```bash
# Create a backup
node db-backup.js export dealership_backup.sql

# Create a compressed backup archive
node db-backup.js zip dealership_backup.sql dealership_backup.zip

# Restore from backup
node db-backup.js import dealership_backup.sql
```

### Data Migration Between Environments

```bash
# Export specific tables
node data-import-export.js export json vehicles vehicles.json
node data-import-export.js export json inquiries inquiries.json

# Import into another environment
node data-import-export.js import json vehicles vehicles.json
node data-import-export.js import json inquiries inquiries.json
```

### Schema Update Process

```bash
# Check for schema changes
node drizzle-manager.js check

# Generate migration
node drizzle-manager.js generate add_vehicle_features

# Apply migration
node drizzle-manager.js migrate

# Or directly push changes (development only)
node drizzle-manager.js push
```

### Working with 3D and AR Model Data

```bash
# Export vehicles with 3D/AR models to JSON
node data-import-export.js export json vehicles vehicles_with_models.json

# Import vehicles with 3D/AR models from JSON
node data-import-export.js import json vehicles vehicles_with_models.json

# Create SQL import script preserving model URLs
node sql-import-export.js create-import vehicles_with_models.json vehicles import_vehicles.sql
```
