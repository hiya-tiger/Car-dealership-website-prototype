/**
 * Data Import/Export Utility for 89 Auto Sales
 * 
 * This utility allows importing and exporting data in various formats:
 * 1. CSV import/export for table data
 * 2. JSON import/export for table data
 * 3. XLSX import/export for table data
 * 4. Bulk data import with validation
 * 5. Table data snapshot and restore
 * 6. Mark vehicles as sold, pending, or available
 * 
 * Usage:
 *   - Import: node data-import-export.js import [format] [table] [file]
 *   - Export: node data-import-export.js export [format] [table] [file]
 *   - Snapshot: node data-import-export.js snapshot [tables...]
 *   - Restore: node data-import-export.js restore [snapshot_file]
 *   - Mark status: node data-import-export.js mark-status [vehicle_id] [status]
 *     (status can be: available, pending, sold)
 */

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const csv = require('csv-parser');
const { parse } = require('json2csv');
const XLSX = require('xlsx');
const readline = require('readline');
const { z } = require('zod');

// Initialize database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Detect and load schema definitions from shared/schema.ts
const schemaValidator = {};

// Check if the database connection works
async function checkConnection() {
  try {
    const client = await pool.connect();
    console.log('Database connection successful');
    client.release();
    return true;
  } catch (error) {
    console.error('Database connection error:', error.message);
    return false;
  }
}

// Generate a schema validator for a table
async function getTableSchema(tableName) {
  try {
    // If we already have a schema validator for this table, return it
    if (schemaValidator[tableName]) {
      return schemaValidator[tableName];
    }
    
    // Query the database for table structure
    const columnsQuery = `
      SELECT 
        column_name, 
        data_type, 
        is_nullable, 
        column_default
      FROM 
        information_schema.columns 
      WHERE 
        table_name = $1
      ORDER BY 
        ordinal_position;
    `;
    
    const { rows } = await pool.query(columnsQuery, [tableName]);
    
    if (rows.length === 0) {
      throw new Error(`Table '${tableName}' not found`);
    }
    
    // Build a Zod schema based on the table structure
    const schemaObj = {};
    
    rows.forEach(column => {
      let fieldSchema;
      
      switch (column.data_type) {
        case 'integer':
        case 'bigint':
        case 'smallint':
          fieldSchema = z.number().int();
          break;
        case 'numeric':
        case 'decimal':
        case 'real':
        case 'double precision':
          fieldSchema = z.number();
          break;
        case 'boolean':
          fieldSchema = z.boolean();
          break;
        case 'json':
        case 'jsonb':
          fieldSchema = z.any();
          break;
        case 'date':
        case 'timestamp':
        case 'timestamptz':
          fieldSchema = z.string().refine(val => !isNaN(Date.parse(val)), {
            message: `Invalid date format for ${column.column_name}`
          });
          break;
        case 'ARRAY':
          // Special handling for specific array columns in the vehicles table
          if (column.column_name === 'images' || 
              column.column_name === 'modelUrl' || 
              column.column_name === 'interiorModelUrl' || 
              column.column_name === 'arModelUrl') {
            // These are URL arrays, so validate them as such
            fieldSchema = z.array(z.string().url({
              message: `Invalid URL in ${column.column_name} array`
            })).nullable().optional();
          } else if (column.column_name === 'features') {
            // Features are just text strings
            fieldSchema = z.array(z.string()).nullable().optional();
          } else {
            // Default array handling
            fieldSchema = z.array(z.any()).nullable().optional();
          }
          break;
        default:
          // Special handling for specific columns in the vehicles table
          if (column.column_name === 'modelUrl' || 
              column.column_name === 'interiorModelUrl' || 
              column.column_name === 'arModelUrl' ||
              column.column_name === 'carfaxLink') {
            fieldSchema = z.string().url({
              message: `Invalid URL in ${column.column_name}`
            }).nullable().optional();
          } else {
            fieldSchema = z.string();
          }
      }
      
      // Handle nullable fields
      if (column.is_nullable === 'YES') {
        fieldSchema = fieldSchema.nullable();
      }
      
      schemaObj[column.column_name] = fieldSchema;
    });
    
    // Create the schema validator
    const validator = z.object(schemaObj);
    
    // Cache the validator
    schemaValidator[tableName] = validator;
    
    return validator;
  } catch (error) {
    console.error(`Error getting schema for table '${tableName}':`, error.message);
    throw error;
  }
}

// Import data from a file
async function importData(format, tableName, filePath) {
  if (!fs.existsSync(filePath)) {
    console.error(`Error: File not found: ${filePath}`);
    process.exit(1);
  }
  
  console.log(`Importing ${format} data from ${filePath} into table ${tableName}...`);
  
  // Get the table schema for validation
  const validator = await getTableSchema(tableName);
  
  // Parse the data based on the format
  let data = [];
  
  switch (format.toLowerCase()) {
    case 'csv':
      data = await importFromCsv(filePath);
      break;
    case 'json':
      data = await importFromJson(filePath);
      break;
    case 'xlsx':
    case 'excel':
      data = await importFromExcel(filePath);
      break;
    default:
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
  }
  
  if (!data || data.length === 0) {
    console.error('Error: No data found in file');
    process.exit(1);
  }
  
  console.log(`Found ${data.length} records to import`);
  
  // Validate and clean data
  const validRecords = [];
  const invalidRecords = [];
  
  for (const record of data) {
    try {
      // Validate the record against the schema
      const validatedRecord = validator.parse(record);
      validRecords.push(validatedRecord);
    } catch (error) {
      invalidRecords.push({ record, errors: error.errors });
    }
  }
  
  console.log(`Validation complete: ${validRecords.length} valid records, ${invalidRecords.length} invalid records`);
  
  if (invalidRecords.length > 0) {
    console.log('First few validation errors:');
    invalidRecords.slice(0, 3).forEach(({ record, errors }) => {
      console.log(`- Record: ${JSON.stringify(record)}`);
      console.log(`  Errors: ${JSON.stringify(errors)}`);
    });
    
    const proceed = await confirmAction('Continue with import of valid records only?');
    if (!proceed) {
      console.log('Import canceled');
      process.exit(0);
    }
  }
  
  if (validRecords.length === 0) {
    console.error('Error: No valid records to import');
    process.exit(1);
  }
  
  // Import the valid records
  try {
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');
      
      let successCount = 0;
      
      for (const record of validRecords) {
        const columns = Object.keys(record);
        const values = Object.values(record);
        const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');
        
        const query = `
          INSERT INTO ${tableName} (${columns.join(', ')})
          VALUES (${placeholders})
        `;
        
        await client.query(query, values);
        successCount++;
      }
      
      await client.query('COMMIT');
      console.log(`Successfully imported ${successCount} records into table ${tableName}`);
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error importing data:', error.message);
    process.exit(1);
  }
}

// Import data from CSV
async function importFromCsv(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];
    
    fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (data) => results.push(data))
      .on('end', () => {
        resolve(results);
      })
      .on('error', (error) => {
        reject(error);
      });
  });
}

// Import data from JSON
async function importFromJson(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    
    if (Array.isArray(data)) {
      return data;
    } else if (data && typeof data === 'object') {
      // Check if it's an object with a data property that's an array
      if (data.data && Array.isArray(data.data)) {
        return data.data;
      } else {
        // Return as a single-element array
        return [data];
      }
    } else {
      throw new Error('Invalid JSON format. Expected an array or object.');
    }
  } catch (error) {
    console.error('Error parsing JSON:', error.message);
    throw error;
  }
}

// Import data from Excel
async function importFromExcel(filePath) {
  try {
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    return XLSX.utils.sheet_to_json(worksheet);
  } catch (error) {
    console.error('Error reading Excel file:', error.message);
    throw error;
  }
}

// Export data to a file
async function exportData(format, tableName, filePath) {
  console.log(`Exporting ${tableName} to ${format} file: ${filePath}`);
  
  // Get all data from the table
  try {
    const { rows } = await pool.query(`SELECT * FROM ${tableName}`);
    
    if (rows.length === 0) {
      console.log(`Warning: Table ${tableName} is empty`);
    }
    
    // Export based on format
    switch (format.toLowerCase()) {
      case 'csv':
        await exportToCsv(rows, filePath);
        break;
      case 'json':
        await exportToJson(rows, filePath);
        break;
      case 'xlsx':
      case 'excel':
        await exportToExcel(rows, filePath);
        break;
      default:
        console.error(`Error: Unsupported format: ${format}`);
        process.exit(1);
    }
    
    console.log(`Successfully exported ${rows.length} records to ${filePath}`);
  } catch (error) {
    console.error('Error exporting data:', error.message);
    process.exit(1);
  }
}

// Export data to CSV
async function exportToCsv(data, filePath) {
  try {
    if (data.length === 0) {
      // Create empty file with headers
      fs.writeFileSync(filePath, '');
      return;
    }
    
    const csv = parse(data);
    fs.writeFileSync(filePath, csv);
  } catch (error) {
    console.error('Error exporting to CSV:', error.message);
    throw error;
  }
}

// Export data to JSON
async function exportToJson(data, filePath) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error exporting to JSON:', error.message);
    throw error;
  }
}

// Export data to Excel
async function exportToExcel(data, filePath) {
  try {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');
    XLSX.writeFile(workbook, filePath);
  } catch (error) {
    console.error('Error exporting to Excel:', error.message);
    throw error;
  }
}

// Create a snapshot of multiple tables
async function createSnapshot(tables) {
  if (!tables || tables.length === 0) {
    console.error('Error: No tables specified for snapshot');
    process.exit(1);
  }
  
  console.log(`Creating snapshot of tables: ${tables.join(', ')}`);
  
  const snapshotDir = path.join(__dirname, 'snapshots');
  if (!fs.existsSync(snapshotDir)) {
    fs.mkdirSync(snapshotDir, { recursive: true });
  }
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const snapshotFile = path.join(snapshotDir, `snapshot_${timestamp}.json`);
  
  try {
    const snapshot = {
      tables: {},
      created_at: new Date().toISOString(),
      database: process.env.PGDATABASE
    };
    
    for (const table of tables) {
      console.log(`Fetching data from table: ${table}`);
      const { rows } = await pool.query(`SELECT * FROM ${table}`);
      snapshot.tables[table] = rows;
      console.log(`  -> ${rows.length} records fetched`);
    }
    
    fs.writeFileSync(snapshotFile, JSON.stringify(snapshot, null, 2));
    console.log(`Snapshot created successfully: ${snapshotFile}`);
    
    return snapshotFile;
  } catch (error) {
    console.error('Error creating snapshot:', error.message);
    process.exit(1);
  }
}

// Restore data from a snapshot
async function restoreSnapshot(snapshotFile) {
  if (!fs.existsSync(snapshotFile)) {
    console.error(`Error: Snapshot file not found: ${snapshotFile}`);
    process.exit(1);
  }
  
  console.log(`Restoring from snapshot: ${snapshotFile}`);
  
  try {
    const snapshot = JSON.parse(fs.readFileSync(snapshotFile, 'utf8'));
    
    if (!snapshot.tables || Object.keys(snapshot.tables).length === 0) {
      console.error('Error: Invalid snapshot format or empty snapshot');
      process.exit(1);
    }
    
    const tables = Object.keys(snapshot.tables);
    console.log(`Snapshot contains data for tables: ${tables.join(', ')}`);
    
    const proceed = await confirmAction('This will overwrite data in the tables. Continue?');
    if (!proceed) {
      console.log('Restore canceled');
      process.exit(0);
    }
    
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');
      
      for (const table of tables) {
        console.log(`Restoring table: ${table}`);
        
        // Clear existing data
        await client.query(`DELETE FROM ${table}`);
        
        const data = snapshot.tables[table];
        console.log(`  -> Restoring ${data.length} records`);
        
        for (const record of data) {
          const columns = Object.keys(record);
          const values = Object.values(record);
          const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');
          
          const query = `
            INSERT INTO ${table} (${columns.join(', ')})
            VALUES (${placeholders})
          `;
          
          await client.query(query, values);
        }
      }
      
      await client.query('COMMIT');
      console.log('Snapshot restored successfully');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error restoring snapshot:', error.message);
    process.exit(1);
  }
}

// Update vehicle status (available, pending, sold)
async function updateVehicleStatus(vehicleId, status) {
  if (!vehicleId || isNaN(vehicleId)) {
    console.error('Error: Invalid vehicle ID');
    process.exit(1);
  }

  if (!status || typeof status !== 'string' || !['available', 'pending', 'sold'].includes(status.toLowerCase())) {
    console.error("Error: Invalid status. Must be one of: 'available', 'pending', 'sold'");
    process.exit(1);
  }

  // Normalize the status
  const normalizedStatus = status.toLowerCase();

  try {
    // First, verify the vehicle exists
    const { rows } = await pool.query('SELECT id, make, model, year FROM vehicles WHERE id = $1', [vehicleId]);
    
    if (rows.length === 0) {
      console.error(`Error: Vehicle with ID ${vehicleId} not found`);
      process.exit(1);
    }

    const vehicle = rows[0];
    
    // Confirm the action
    const vehicleInfo = `${vehicle.year} ${vehicle.make} ${vehicle.model} (ID: ${vehicle.id})`;
    const proceed = await confirmAction(`Mark vehicle "${vehicleInfo}" as ${normalizedStatus}?`);
    
    if (!proceed) {
      console.log('Operation canceled');
      process.exit(0);
    }

    // Update the vehicle status
    const result = await pool.query(
      'UPDATE vehicles SET status = $1 WHERE id = $2 RETURNING id, make, model, year, status',
      [normalizedStatus, vehicleId]
    );

    if (result.rows.length > 0) {
      const updatedVehicle = result.rows[0];
      console.log(`Successfully updated status of vehicle "${vehicleInfo}" to ${normalizedStatus}`);
      console.log('Updated vehicle details:', updatedVehicle);
    } else {
      console.error(`Error: Failed to update vehicle status`);
      process.exit(1);
    }
  } catch (error) {
    console.error('Error updating vehicle status:', error.message);
    process.exit(1);
  }
}

// Helper function to confirm an action
function confirmAction(message) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise((resolve) => {
    rl.question(`${message} (y/N): `, (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y');
    });
  });
}

// Main function
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  if (!command) {
    console.error('Error: Missing command. Available commands: import, export, snapshot, restore, mark-status');
    process.exit(1);
  }
  
  // Check database connection
  const connected = await checkConnection();
  if (!connected) {
    console.error('Error: Could not connect to the database. Check your DATABASE_URL environment variable.');
    process.exit(1);
  }
  
  switch (command.toLowerCase()) {
    case 'import':
      if (args.length < 4) {
        console.error('Error: Missing arguments. Usage: import [format] [table] [file]');
        process.exit(1);
      }
      await importData(args[1], args[2], args[3]);
      break;
      
    case 'export':
      if (args.length < 4) {
        console.error('Error: Missing arguments. Usage: export [format] [table] [file]');
        process.exit(1);
      }
      await exportData(args[1], args[2], args[3]);
      break;
      
    case 'snapshot':
      if (args.length < 2) {
        console.error('Error: Missing arguments. Usage: snapshot [tables...]');
        process.exit(1);
      }
      await createSnapshot(args.slice(1));
      break;
      
    case 'restore':
      if (args.length < 2) {
        console.error('Error: Missing arguments. Usage: restore [snapshot_file]');
        process.exit(1);
      }
      await restoreSnapshot(args[1]);
      break;
      
    case 'mark-status':
      if (args.length < 3) {
        console.error('Error: Missing arguments. Usage: mark-status [vehicle_id] [status]');
        console.error('Available status values: available, pending, sold');
        process.exit(1);
      }
      await updateVehicleStatus(parseInt(args[1]), args[2]);
      break;
      
    default:
      console.error(`Error: Unknown command "${command}". Available commands: import, export, snapshot, restore, mark-status`);
      process.exit(1);
  }
  
  // Close the database connection pool
  await pool.end();
}

// Run the main function
main().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});