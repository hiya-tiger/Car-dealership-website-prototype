/**
 * Drizzle Schema Manager for 89 Auto Sales
 * 
 * This utility provides a CLI interface for managing the database schema using Drizzle ORM:
 * 1. Push schema changes to the database
 * 2. Generate migration files
 * 3. Apply migrations
 * 4. View schema differences
 * 
 * Usage:
 *   - Push schema: node drizzle-manager.js push
 *   - Generate migration: node drizzle-manager.js generate [name]
 *   - Apply migrations: node drizzle-manager.js migrate
 *   - Check for changes: node drizzle-manager.js check
 */

const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// Constants
const MIGRATIONS_DIR = path.join(__dirname, '..', 'drizzle');

// Helper to ensure migrations directory exists
function ensureMigrationsDir() {
  if (!fs.existsSync(MIGRATIONS_DIR)) {
    fs.mkdirSync(MIGRATIONS_DIR, { recursive: true });
    console.log(`Created migrations directory: ${MIGRATIONS_DIR}`);
  }
}

// Execute a drizzle-kit command with proper environment variables
function executeDrizzleCommand(command, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    // Make sure NODE_ENV is set to development
    const env = {
      ...process.env,
      NODE_ENV: 'development'
    };
    
    // Build the full command
    const fullCommand = `npx drizzle-kit ${command}${args.length > 0 ? ' ' + args.join(' ') : ''}`;
    
    console.log(`Executing: ${fullCommand}`);
    
    const child = spawn('npx', ['drizzle-kit', command, ...args], {
      env,
      stdio: 'inherit',
      shell: true,
      ...options
    });
    
    child.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Command exited with code ${code}`));
      }
    });
    
    child.on('error', (error) => {
      reject(error);
    });
  });
}

// Push schema changes directly to the database
async function pushSchema() {
  console.log('Pushing schema changes to the database...');
  
  try {
    // First confirm with the user
    const confirmed = await confirmAction('This will apply schema changes directly to the database. Continue?');
    if (!confirmed) {
      console.log('Push operation canceled.');
      return;
    }
    
    // Execute npm run db:push
    execSync('npm run db:push', { stdio: 'inherit' });
    
    console.log('Schema changes pushed successfully!');
  } catch (error) {
    console.error('Error pushing schema changes:', error.message);
    process.exit(1);
  }
}

// Generate migration files
async function generateMigration(name) {
  if (!name) {
    console.error('Error: Migration name is required.');
    process.exit(1);
  }
  
  ensureMigrationsDir();
  
  console.log(`Generating migration: ${name}...`);
  
  try {
    await executeDrizzleCommand('generate', [
      '--schema=./shared/schema.ts',
      `--out=./drizzle`,
      `--name=${name}`
    ]);
    
    console.log('Migration files generated successfully!');
  } catch (error) {
    console.error('Error generating migration:', error.message);
    process.exit(1);
  }
}

// Apply migrations
async function applyMigrations() {
  ensureMigrationsDir();
  
  console.log('Applying migrations...');
  
  try {
    // Check if we have any migration files
    const migrationFiles = fs.readdirSync(MIGRATIONS_DIR).filter(f => f.endsWith('.sql'));
    
    if (migrationFiles.length === 0) {
      console.log('No migration files found. Generate migrations first.');
      return;
    }
    
    // Confirm with user
    const confirmed = await confirmAction(`This will apply ${migrationFiles.length} migration(s) to the database. Continue?`);
    if (!confirmed) {
      console.log('Migration operation canceled.');
      return;
    }
    
    // Create a simple migrate script
    const tempScriptPath = path.join(__dirname, 'temp-migrate.js');
    
    const scriptContent = `
      const { Pool } = require('pg');
      const fs = require('fs');
      const path = require('path');
      
      async function applyMigrations() {
        const pool = new Pool({
          connectionString: process.env.DATABASE_URL
        });
        
        try {
          // Create migrations table if it doesn't exist
          await pool.query(\`
            CREATE TABLE IF NOT EXISTS migrations (
              id SERIAL PRIMARY KEY,
              name VARCHAR(255) NOT NULL,
              applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
          \`);
          
          // Get already applied migrations
          const { rows } = await pool.query('SELECT name FROM migrations');
          const appliedMigrations = rows.map(r => r.name);
          
          // Read migration files
          const migrationsDir = '${MIGRATIONS_DIR.replace(/\\/g, '\\\\')}';
          const migrationFiles = fs.readdirSync(migrationsDir)
            .filter(f => f.endsWith('.sql'))
            .sort();
          
          for (const file of migrationFiles) {
            if (appliedMigrations.includes(file)) {
              console.log(\`Migration \${file} already applied, skipping.\`);
              continue;
            }
            
            console.log(\`Applying migration: \${file}\`);
            const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
            
            // Start a transaction
            const client = await pool.connect();
            try {
              await client.query('BEGIN');
              await client.query(sql);
              await client.query(
                'INSERT INTO migrations (name) VALUES ($1)',
                [file]
              );
              await client.query('COMMIT');
              console.log(\`Migration \${file} applied successfully.\`);
            } catch (error) {
              await client.query('ROLLBACK');
              throw error;
            } finally {
              client.release();
            }
          }
          
          console.log('All migrations applied!');
        } finally {
          await pool.end();
        }
      }
      
      applyMigrations().catch(err => {
        console.error('Migration error:', err);
        process.exit(1);
      });
    `;
    
    fs.writeFileSync(tempScriptPath, scriptContent);
    
    // Execute the migration script
    execSync(`node ${tempScriptPath}`, { stdio: 'inherit' });
    
    // Clean up
    fs.unlinkSync(tempScriptPath);
    
    console.log('Migrations applied successfully!');
  } catch (error) {
    console.error('Error applying migrations:', error.message);
    process.exit(1);
  }
}

// Check for schema changes
async function checkSchemaChanges() {
  console.log('Checking for schema changes...');
  
  try {
    await executeDrizzleCommand('introspect', [
      '--driver=pg', 
      '--out=./drizzle/current-schema.json',
      '--connectionString="' + process.env.DATABASE_URL + '"'
    ]);
    
    console.log('Schema introspection complete.');
    console.log('Comparing with defined schema...');
    
    // Compare with drizzle schema
    await executeDrizzleCommand('diff', [
      '--schema=./shared/schema.ts',
      '--introspect=./drizzle/current-schema.json',
    ]);
    
    console.log('Schema check complete!');
  } catch (error) {
    console.error('Error checking schema changes:', error.message);
    process.exit(1);
  }
}

// Helper function to confirm an action
function confirmAction(message) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise((resolve) => {
    rl.question(`${message} (y/N): `, (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y');
    });
  });
}

// Main function
async function main() {
  const [command, ...args] = process.argv.slice(2);
  
  if (!command) {
    console.error('Error: Missing command. Available commands: push, generate, migrate, check');
    process.exit(1);
  }
  
  switch (command.toLowerCase()) {
    case 'push':
      await pushSchema();
      break;
      
    case 'generate':
      await generateMigration(args[0]);
      break;
      
    case 'migrate':
      await applyMigrations();
      break;
      
    case 'check':
      await checkSchemaChanges();
      break;
      
    default:
      console.error(`Error: Unknown command "${command}". Available commands: push, generate, migrate, check`);
      process.exit(1);
  }
}

// Run the main function
main().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});