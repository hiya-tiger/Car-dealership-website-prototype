#!/bin/bash
# 89 Auto Sales Database Utilities Runner
# This script provides a convenient way to access all database utilities

# Define color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print logo
echo -e "${BLUE}"
echo "  _____  ___    _          _          _____       _           "
echo " |  _  \|  _ \ | |        | |        /  ___|     | |          "
echo " | | | || |_) || |_  ___  | |  ___   \ \___  __ _| | ___  ___ "
echo " | | | ||  _ < | __|/ _ \ | | / _ \   \___ \/ _\` | |/ _ \/ __|"
echo " | |_| || |_) || |_| (_) || || (_) |  ____) | (_| | |  __/\__ \\"
echo " |_____/|____/  \__|\___/ |_| \___/  |_____/ \__,_|_|\___||___/"
echo -e "${NC}"
echo "========== Database Management Utilities =========="

# Check if a command was provided
if [ -z "$1" ]; then
  echo -e "${YELLOW}No command specified. Available commands:${NC}"
  echo -e "${GREEN}backup${NC} - Database backup and restore"
  echo -e "${GREEN}sql${NC} - SQL import/export utilities"
  echo -e "${GREEN}pg${NC} - PostgreSQL CLI tools"
  echo -e "${GREEN}schema${NC} - Drizzle schema management"
  echo -e "${GREEN}data${NC} - Data import/export utilities"
  echo ""
  echo "Usage: ./db-tools.sh [command] [arguments...]"
  exit 0
fi

# Parse the command
case "$1" in
  backup|db-backup)
    echo -e "${BLUE}Running Database Backup Utility...${NC}"
    shift
    node db-backup.js "$@"
    ;;
    
  sql|sql-import-export)
    echo -e "${BLUE}Running SQL Import/Export Utility...${NC}"
    shift
    node sql-import-export.js "$@"
    ;;
    
  pg|pg-cli)
    echo -e "${BLUE}Running PostgreSQL CLI Tools...${NC}"
    shift
    node pg-cli-tools.js "$@"
    ;;
    
  schema|drizzle)
    echo -e "${BLUE}Running Drizzle Schema Manager...${NC}"
    shift
    node drizzle-manager.js "$@"
    ;;
    
  data|import-export)
    echo -e "${BLUE}Running Data Import/Export Utility...${NC}"
    shift
    node data-import-export.js "$@"
    ;;
    
  help)
    echo -e "${YELLOW}Available commands:${NC}"
    echo -e "${GREEN}backup${NC} - Database backup and restore"
    echo -e "  ./db-tools.sh backup export [output_file.sql]"
    echo -e "  ./db-tools.sh backup import [input_file.sql]"
    echo -e "  ./db-tools.sh backup zip [input_file.sql] [output_file.zip]"
    echo ""
    echo -e "${GREEN}sql${NC} - SQL import/export utilities"
    echo -e "  ./db-tools.sh sql export-table [table_name] [output_file.sql]"
    echo -e "  ./db-tools.sh sql export-query \"SELECT * FROM users\" [output_file.csv]"
    echo -e "  ./db-tools.sh sql create-import [input_json_file] [table_name] [output_file.sql]"
    echo ""
    echo -e "${GREEN}pg${NC} - PostgreSQL CLI tools"
    echo -e "  ./db-tools.sh pg psql [sql_command]"
    echo -e "  ./db-tools.sh pg dump [output_file] --format=p --clean"
    echo -e "  ./db-tools.sh pg restore [input_file] --clean"
    echo ""
    echo -e "${GREEN}schema${NC} - Drizzle schema management"
    echo -e "  ./db-tools.sh schema push"
    echo -e "  ./db-tools.sh schema generate [migration_name]"
    echo -e "  ./db-tools.sh schema migrate"
    echo -e "  ./db-tools.sh schema check"
    echo ""
    echo -e "${GREEN}data${NC} - Data import/export utilities"
    echo -e "  ./db-tools.sh data import [format] [table] [file]"
    echo -e "  ./db-tools.sh data export [format] [table] [file]"
    echo -e "  ./db-tools.sh data snapshot [table1] [table2] ..."
    echo -e "  ./db-tools.sh data restore [snapshot_file]"
    ;;
    
  *)
    echo -e "${RED}Unknown command: $1${NC}"
    echo "Run './db-tools.sh help' for usage information"
    exit 1
    ;;
esac