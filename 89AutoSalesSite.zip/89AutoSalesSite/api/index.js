import express from 'express';
import cors from 'cors';
import { storage } from '../server/storage';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// API Routes
app.get('/api/vehicles', async (req, res) => {
  try {
    const vehicles = await storage.getVehicles();
    res.json(vehicles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/vehicles/featured', async (req, res) => {
  try {
    const vehicles = await storage.getFeaturedVehicles();
    res.json(vehicles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/vehicles/special-offers', async (req, res) => {
  try {
    const vehicles = await storage.getSpecialOfferVehicles();
    res.json(vehicles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/vehicles/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const vehicle = await storage.getVehicleById(id);
    
    if (!vehicle) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }
    
    res.json(vehicle);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/vehicles', async (req, res) => {
  try {
    const vehicle = await storage.createVehicle(req.body);
    res.status(201).json(vehicle);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/vehicles/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const updatedVehicle = await storage.updateVehicle(id, req.body);
    
    if (!updatedVehicle) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }
    
    res.json(updatedVehicle);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/vehicles/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const success = await storage.deleteVehicle(id);
    
    if (!success) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }
    
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/inquiries', async (req, res) => {
  try {
    const inquiry = await storage.createInquiry(req.body);
    res.status(201).json(inquiry);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/inquiries', async (req, res) => {
  try {
    const inquiries = await storage.getInquiries();
    res.json(inquiries);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/inquiries/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const inquiry = await storage.getInquiryById(id);
    
    if (!inquiry) {
      return res.status(404).json({ error: 'Inquiry not found' });
    }
    
    res.json(inquiry);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/testimonials', async (req, res) => {
  try {
    const testimonials = await storage.getTestimonials();
    res.json(testimonials);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Export the Express API
export default app;