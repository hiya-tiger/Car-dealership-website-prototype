import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertContactSchema, 
  insertCreditApplicationSchema, 
  insertTradeInSchema, 
  insertAppointmentSchema, 
  insertInquirySchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes - prefix with /api
  
  // GET /api/vehicles - Get all vehicles
  app.get("/api/vehicles", async (req: Request, res: Response) => {
    try {
      const vehicles = await storage.getVehicles();
      res.json({ vehicles });
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve vehicles" });
    }
  });

  // GET /api/vehicles/:id - Get a specific vehicle
  app.get("/api/vehicles/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid vehicle ID" });
      }
      
      const vehicle = await storage.getVehicle(id);
      if (!vehicle) {
        return res.status(404).json({ error: "Vehicle not found" });
      }
      
      res.json({ vehicle });
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve vehicle" });
    }
  });

  // POST /api/contact - Submit contact form
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const submission = insertContactSchema.parse(req.body);
      const result = await storage.addContactSubmission(submission);
      res.status(201).json({ success: true, submission: result });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      res.status(500).json({ error: "Failed to submit contact form" });
    }
  });

  // POST /api/credit-application - Submit credit application
  app.post("/api/credit-application", async (req: Request, res: Response) => {
    try {
      const application = insertCreditApplicationSchema.parse(req.body);
      const result = await storage.addCreditApplication(application);
      res.status(201).json({ success: true, application: result });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      res.status(500).json({ error: "Failed to submit credit application" });
    }
  });

  // POST /api/trade-in - Submit trade-in appraisal
  app.post("/api/trade-in", async (req: Request, res: Response) => {
    try {
      const appraisal = insertTradeInSchema.parse(req.body);
      const result = await storage.addTradeInAppraisal(appraisal);
      res.status(201).json({ success: true, appraisal: result });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      res.status(500).json({ error: "Failed to submit trade-in appraisal" });
    }
  });

  // POST /api/appointments - Book an appointment
  app.post("/api/appointments", async (req: Request, res: Response) => {
    try {
      const appointment = insertAppointmentSchema.parse(req.body);
      const result = await storage.addAppointment(appointment);
      res.status(201).json({ success: true, appointment: result });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      res.status(500).json({ error: "Failed to book appointment" });
    }
  });

  // GET /api/appointments - Get all appointments
  app.get("/api/appointments", async (req: Request, res: Response) => {
    try {
      let appointments;
      if (req.query.type) {
        appointments = await storage.getAppointmentsByType(req.query.type as string);
      } else {
        appointments = await storage.getAppointments();
      }
      res.json({ appointments });
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve appointments" });
    }
  });

  // POST /api/inquiries - Submit a quick inquiry
  app.post("/api/inquiries", async (req: Request, res: Response) => {
    try {
      const inquiry = insertInquirySchema.parse(req.body);
      const result = await storage.addInquiry(inquiry);
      res.status(201).json({ success: true, inquiry: result });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      res.status(500).json({ error: "Failed to submit inquiry" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
