import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { storage, DatabaseStorage } from "./storage";
import { sql } from "drizzle-orm";
import { db, pool } from "./db";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import compression from "compression";

const app = express();

// Enhanced security and performance middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      imgSrc: ["'self'", "data:", "https://images.unsplash.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      connectSrc: ["'self'"],
    },
  },
  crossOriginEmbedderPolicy: false, // For iframe compatibility
  crossOriginResourcePolicy: { policy: "cross-origin" }, // For loading external resources
  xssFilter: true,
  hidePoweredBy: true,
})); // Enhanced security headers

app.use(compression()); // Compress responses

// Configure CORS with specific options
app.use(cors({
  origin: process.env.NODE_ENV === 'production' ? process.env.ALLOWED_ORIGINS?.split(',') || true : true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  maxAge: 86400 // 24 hours
}));

// Body parsers with reasonable limits
app.use(express.json({ limit: '10mb' })); // Reduced limit for better security
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

// Rate limiting to prevent abuse - different limits for different endpoints
const standardLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  message: "Too many requests from this IP, please try again later"
});

// More strict limiting for authentication and form submission endpoints
const strictLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // limit each IP to 10 requests per hour
  standardHeaders: true,
  legacyHeaders: false,
  message: "Too many attempts from this IP, please try again later"
});

// Apply rate limiters to different API endpoints
app.use("/api/vehicles", standardLimiter); // Standard rate limit for vehicle browsing
app.use("/api/contact", strictLimiter); // Stricter limit for form submissions
app.use("/api/credit-application", strictLimiter);
app.use("/api/trade-in", strictLimiter);
app.use("/api/appointments", strictLimiter);
app.use("/api/inquiries", strictLimiter);

// Default limiter for any other API routes
app.use("/api/", standardLimiter);

// Request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  // Capture JSON response
  const originalJson = res.json;
  res.json = function(body) {
    capturedJsonResponse = body;
    return originalJson.call(this, body);
  };

  // Once response is finished, log the request details
  res.on('finish', () => {
    const duration = Date.now() - start;
    const statusCode = res.statusCode;
    const method = req.method;
    
    log(`${method} ${path} ${statusCode} ${duration}ms`, 'request');
    
    // Log response body for debugging if needed (but not in production)
    if (app.get('env') !== 'production' && capturedJsonResponse) {
      if (path.startsWith('/api/')) {
        // Don't log sensitive data
        const safeResponse = { ...capturedJsonResponse };
        // Remove sensitive fields if present
        delete safeResponse.password;
        delete safeResponse.driversLicense;
        log(`Response: ${JSON.stringify(safeResponse).substring(0, 200)}${JSON.stringify(safeResponse).length > 200 ? '...' : ''}`, 'response');
      }
    }
  });

  next();
});

// Initialize database schema and load sample data
async function initDatabase() {
  try {
    // Create tables if they don't exist
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT UNIQUE,
        role TEXT DEFAULT 'customer',
        created_at TIMESTAMP DEFAULT NOW(),
        last_login TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS vehicles (
        id SERIAL PRIMARY KEY,
        make TEXT NOT NULL,
        model TEXT NOT NULL,
        year INTEGER NOT NULL,
        price INTEGER NOT NULL,
        mileage INTEGER,
        exterior_color TEXT,
        interior_color TEXT,
        vin TEXT,
        transmission TEXT,
        fuel_economy TEXT,
        description TEXT,
        condition TEXT,
        body_style TEXT,
        features TEXT[],
        images TEXT[],
        model_url TEXT,
        is_special_offer BOOLEAN DEFAULT FALSE,
        is_new_arrival BOOLEAN DEFAULT FALSE,
        is_sold BOOLEAN DEFAULT FALSE,
        warranty_info TEXT,
        engine TEXT,
        drivetrain TEXT,
        fuel_type TEXT,
        mpg_city INTEGER,
        mpg_highway INTEGER,
        stock_number TEXT,
        video_url TEXT,
        virtual_tour_url TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS contact_submissions (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        message TEXT NOT NULL,
        subject TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        status TEXT DEFAULT 'new',
        assigned_to INTEGER REFERENCES users(id),
        resolved_at TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS credit_applications (
        id SERIAL PRIMARY KEY,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        zip TEXT NOT NULL,
        employment_status TEXT NOT NULL,
        employer_name TEXT,
        monthly_income INTEGER,
        drivers_license TEXT,
        dob TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        status TEXT DEFAULT 'pending',
        credit_score INTEGER,
        approved_amount INTEGER,
        interest_rate DECIMAL(5,2),
        term_months INTEGER
      );
      
      CREATE TABLE IF NOT EXISTS trade_in_appraisals (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        make TEXT NOT NULL,
        model TEXT NOT NULL,
        year INTEGER NOT NULL,
        mileage INTEGER NOT NULL,
        condition TEXT NOT NULL,
        exterior_color TEXT,
        has_loan BOOLEAN,
        loan_amount INTEGER,
        additional_info TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        appraised_value INTEGER,
        appraised_at TIMESTAMP,
        appraised_by INTEGER REFERENCES users(id),
        status TEXT DEFAULT 'pending'
      );
      
      CREATE TABLE IF NOT EXISTS appointments (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        type TEXT NOT NULL,
        vehicle_id INTEGER,
        service_type TEXT,
        notes TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT NOW(),
        confirmed_at TIMESTAMP,
        completed_at TIMESTAMP,
        assigned_to INTEGER REFERENCES users(id),
        reminder_sent BOOLEAN DEFAULT FALSE
      );
      
      CREATE TABLE IF NOT EXISTS inquiries (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        interest_type TEXT NOT NULL,
        message TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        vehicle_id INTEGER,
        status TEXT DEFAULT 'new',
        assigned_to INTEGER REFERENCES users(id),
        resolved_at TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        customer_name TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
        review_text TEXT,
        purchase_date TIMESTAMP,
        vehicle_id INTEGER REFERENCES vehicles(id),
        created_at TIMESTAMP DEFAULT NOW(),
        is_verified BOOLEAN DEFAULT FALSE,
        is_featured BOOLEAN DEFAULT FALSE
      );
      
      CREATE TABLE IF NOT EXISTS saved_vehicles (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        vehicle_id INTEGER REFERENCES vehicles(id),
        created_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(user_id, vehicle_id)
      );
      
      CREATE TABLE IF NOT EXISTS compare_vehicles (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        vehicle_ids INTEGER[],
        created_at TIMESTAMP DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS promotions (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP NOT NULL,
        discount_amount INTEGER,
        discount_percentage INTEGER,
        promo_code TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        applies_to TEXT[], -- vehicle IDs or categories
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    log("Database tables created or already exist");
    
    // Initialize sample vehicles
    if (storage instanceof DatabaseStorage) {
      await storage.initSampleVehicles();
      log("Sample vehicles initialized");
    }
  } catch (error) {
    console.error("Database initialization error:", error);
  }
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', uptime: process.uptime() });
});

(async () => {
  try {
    // Initialize database before starting the server
    await initDatabase();
    
    const server = await registerRoutes(app);

    // Global error handler with improved error classification and logging
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      // Determine the status code
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";
      
      // Create a sanitized error response
      const errorResponse = {
        message,
        status,
        timestamp: new Date().toISOString(),
        path: _req.path,
        // Include stack trace in development but not in production
        ...(app.get('env') !== 'production' && { stack: err.stack })
      };

      // Log detailed error information
      console.error(`[ERROR] ${status} - ${message}`);
      console.error(`Request: ${_req.method} ${_req.originalUrl}`);
      console.error(`Body: ${JSON.stringify(_req.body)}`);
      console.error(err);

      // Send appropriate response to client
      res.status(status).json({
        error: errorResponse.message,
        status: errorResponse.status,
        timestamp: errorResponse.timestamp
      });
    });

    // importantly only setup vite in development and after
    // setting up all the other routes so the catch-all route
    // doesn't interfere with the other routes
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // Use the PORT from environment variables or default to 5000
    // this serves both the API and the client.
    const port = process.env.PORT ? parseInt(process.env.PORT) : 5000;
    server.listen({
      port,
      host: "0.0.0.0",
      reusePort: true,
    }, () => {
      log(`AutoDealerHub server running on port ${port}`);
      log(`Environment: ${app.get("env")}`);
    });
    
    // Setup graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      log(`Received ${signal}. Shutting down gracefully...`);
      server.close(() => {
        log('HTTP server closed');
      });
      
      try {
        // Close database connections
        await pool.end();
        log('Database connections closed');
        process.exit(0);
      } catch (err) {
        console.error('Error during shutdown:', err);
        process.exit(1);
      }
    };
    
    // Listen for termination signals
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error("Server startup error:", error);
    process.exit(1); // Exit with error code
  }
})();