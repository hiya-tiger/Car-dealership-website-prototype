import {
  users, type User, type InsertUser,
  vehicles, type Vehicle, type InsertVehicle,
  contactSubmissions, type ContactSubmission, type InsertContactSubmission,
  creditApplications, type CreditApplication, type InsertCreditApplication,
  tradeInAppraisals, type TradeInAppraisal, type InsertTradeInAppraisal,
  appointments, type Appointment, type InsertAppointment,
  inquiries, type Inquiry, type InsertInquiry
} from "@shared/schema";
import { db } from "./db";
import { eq, asc, desc } from "drizzle-orm";

// Interface for our storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Vehicle operations
  getVehicles(): Promise<Vehicle[]>;
  getVehicle(id: number): Promise<Vehicle | undefined>;
  addVehicle(vehicle: InsertVehicle): Promise<Vehicle>;

  // Contact form operations
  addContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;

  // Credit application operations
  addCreditApplication(application: InsertCreditApplication): Promise<CreditApplication>;
  getCreditApplications(): Promise<CreditApplication[]>;

  // Trade-in appraisal operations
  addTradeInAppraisal(appraisal: InsertTradeInAppraisal): Promise<TradeInAppraisal>;
  getTradeInAppraisals(): Promise<TradeInAppraisal[]>;

  // Appointment operations
  addAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointments(): Promise<Appointment[]>;
  getAppointmentsByType(type: string): Promise<Appointment[]>;

  // Inquiry operations
  addInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
  getInquiries(): Promise<Inquiry[]>;
}

// Database Storage implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Vehicle operations
  async getVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles);
  }

  async getVehicle(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle;
  }

  async addVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const [newVehicle] = await db.insert(vehicles).values(vehicle).returning();
    return newVehicle;
  }

  // Contact form operations
  async addContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const [newSubmission] = await db.insert(contactSubmissions).values(submission).returning();
    return newSubmission;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return await db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
  }

  // Credit application operations
  async addCreditApplication(application: InsertCreditApplication): Promise<CreditApplication> {
    const [newApplication] = await db.insert(creditApplications).values(application).returning();
    return newApplication;
  }

  async getCreditApplications(): Promise<CreditApplication[]> {
    return await db.select().from(creditApplications).orderBy(desc(creditApplications.createdAt));
  }

  // Trade-in appraisal operations
  async addTradeInAppraisal(appraisal: InsertTradeInAppraisal): Promise<TradeInAppraisal> {
    const [newAppraisal] = await db.insert(tradeInAppraisals).values(appraisal).returning();
    return newAppraisal;
  }

  async getTradeInAppraisals(): Promise<TradeInAppraisal[]> {
    return await db.select().from(tradeInAppraisals).orderBy(desc(tradeInAppraisals.createdAt));
  }

  // Appointment operations
  async addAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db.insert(appointments).values({
      ...appointment,
      status: "pending"
    }).returning();
    return newAppointment;
  }

  async getAppointments(): Promise<Appointment[]> {
    return await db.select().from(appointments).orderBy(desc(appointments.createdAt));
  }

  async getAppointmentsByType(type: string): Promise<Appointment[]> {
    return await db.select().from(appointments)
      .where(eq(appointments.type, type))
      .orderBy(desc(appointments.createdAt));
  }

  // Inquiry operations
  async addInquiry(inquiry: InsertInquiry): Promise<Inquiry> {
    const [newInquiry] = await db.insert(inquiries).values(inquiry).returning();
    return newInquiry;
  }

  async getInquiries(): Promise<Inquiry[]> {
    return await db.select().from(inquiries).orderBy(desc(inquiries.createdAt));
  }

  // Initialize sample vehicles
  async initSampleVehicles() {
    const sampleVehicles: InsertVehicle[] = [
      {
        make: "Chevrolet",
        model: "Camaro ZL1",
        year: 2022,
        price: 71995,
        mileage: 7630,
        exteriorColor: "Rapid Blue",
        interiorColor: "Jet Black with Red Accents",
        vin: "1G1FK1R69N0123456",
        transmission: "6-Speed Manual",
        fuelEconomy: "16/24 mpg",
        description: "Track-ready performance with 650 horsepower supercharged V8 engine",
        condition: "used",
        bodyStyle: "Coupe",
        features: ["Supercharged 6.2L V8", "Magnetic Ride Control", "Recaro Performance Seats", "Brembo Brakes", "Performance Data Recorder"],
        images: [
          "https://images.pexels.com/photos/12086528/pexels-photo-12086528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
        ],
        modelUrl: "https://sketchfab.com/models/e922cc630dbe41089bce65d1c4f116f7/embed",
        isNewArrival: false,
        isSpecialOffer: false,
        isSold: true,
      },
      {
        make: "Mercedes-Benz",
        model: "S-Class",
        year: 2023,
        price: 89995,
        mileage: 15523,
        exteriorColor: "Obsidian Black",
        interiorColor: "Black Leather",
        vin: "WDDUG8GB3MA456789",
        transmission: "Automatic",
        fuelEconomy: "25/32 mpg",
        description: "Luxury Sedan with Premium Package",
        condition: "new",
        bodyStyle: "Sedan",
        features: ["Navigation", "Heated Seats", "Sunroof", "Bluetooth", "Backup Camera"],
        images: [
          "https://images.unsplash.com/photo-1616422285623-13ff0162193c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=533&q=80"
        ],
        modelUrl: "https://sketchfab.com/models/a208b91171254a7cbc257f1ab73d6118/embed", 
        isNewArrival: true,
        isSpecialOffer: false,
      },
      {
        make: "BMW",
        model: "5 Series",
        year: 2022,
        price: 62495,
        mileage: 18201,
        exteriorColor: "Alpine White",
        interiorColor: "Cognac Leather",
        vin: "WBA53BL03NCG12345",
        transmission: "Automatic",
        fuelEconomy: "23/30 mpg",
        description: "Executive Sedan with M Sport Package",
        condition: "used",
        bodyStyle: "Sedan",
        features: ["M Sport Package", "Heated Steering Wheel", "Premium Sound", "Parking Sensors", "Heads-up Display"],
        images: [
          "https://images.unsplash.com/photo-1570733577524-3a047079e80d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=533&q=80"
        ],
        modelUrl: "https://sketchfab.com/models/f8169266571c4644a4e97c15ed64a531/embed",
        isNewArrival: false,
        isSpecialOffer: true,
      },
      {
        make: "Audi",
        model: "Q5",
        year: 2023,
        price: 54995,
        mileage: 12750,
        exteriorColor: "Navarra Blue",
        interiorColor: "Gray Leather",
        vin: "WA1BNAFY7P2123456",
        transmission: "Automatic",
        fuelEconomy: "22/28 mpg",
        description: "Premium Plus SUV with Technology Package",
        condition: "used",
        bodyStyle: "SUV",
        features: ["Quattro AWD", "Bang & Olufsen Sound", "Panoramic Sunroof", "Virtual Cockpit", "Lane Assist"],
        images: [
          "https://images.unsplash.com/photo-1580273916550-e323be2ae537?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=533&q=80"
        ],
        modelUrl: "https://sketchfab.com/models/ab80752f9fb7492d8b0848682e310a85/embed",
        isNewArrival: false,
        isSpecialOffer: false,
      },
      {
        make: "Lexus",
        model: "RX 350",
        year: 2023,
        price: 58995,
        mileage: 8500,
        exteriorColor: "Eminent White Pearl",
        interiorColor: "Black NuLuxe",
        vin: "2T2HZMDA7PC123456",
        transmission: "Automatic",
        fuelEconomy: "20/27 mpg",
        description: "Luxury SUV with F Sport Package",
        condition: "certified",
        bodyStyle: "SUV",
        features: ["F Sport Package", "Mark Levinson Audio", "Panoramic View Monitor", "Adaptive Suspension", "Leather Seats"],
        images: [
          "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
        ],
        modelUrl: "https://sketchfab.com/models/d1d0f7a3d6334a00874cae0c944c73af/embed",
        isNewArrival: true,
        isSpecialOffer: false,
      },
      {
        make: "Porsche",
        model: "911 Carrera",
        year: 2022,
        price: 119900,
        mileage: 7823,
        exteriorColor: "GT Silver Metallic",
        interiorColor: "Black Leather",
        vin: "WP0AB2A94NS123456",
        transmission: "PDK",
        fuelEconomy: "18/24 mpg",
        description: "Sports Car with Premium Package Plus",
        condition: "used",
        bodyStyle: "Coupe",
        features: ["Sport Chrono Package", "Sport Exhaust", "Adaptive Sport Seats", "BOSE Surround Sound", "Lane Change Assist"],
        images: [
          "https://images.unsplash.com/photo-1580274455191-1c62238fa333?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
        ],
        modelUrl: "https://sketchfab.com/models/50970aeebc144969bbf0112874b3b1ea/embed",
        isNewArrival: false,
        isSpecialOffer: true,
      },
      {
        make: "Tesla",
        model: "Model Y",
        year: 2023,
        price: 65990,
        mileage: 5210,
        exteriorColor: "Pearl White",
        interiorColor: "Black",
        vin: "5YJYGDEE1NF123456",
        transmission: "Automatic",
        fuelEconomy: "129/112 MPGe",
        description: "Long Range All-Wheel Drive Electric SUV",
        condition: "used",
        bodyStyle: "SUV",
        features: ["Autopilot", "Glass Roof", "Premium Interior", "20\" Induction Wheels", "Tow Hitch"],
        images: [
          "https://images.unsplash.com/photo-1619115854012-695e733e1ef8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
        ],
        modelUrl: "https://sketchfab.com/models/60a36bda9e1a472a8dbcad0db163bc25/embed",
        isNewArrival: true,
        isSpecialOffer: false,
      }
    ];

    // Check if we already have vehicles in the database
    const existingVehicles = await db.select().from(vehicles);
    
    // Only add sample vehicles if the database is empty
    if (existingVehicles.length === 0) {
      for (const vehicle of sampleVehicles) {
        await this.addVehicle(vehicle);
      }
    }
  }
}

// Create an instance of the database storage
export const storage = new DatabaseStorage();
