import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model - kept from the original template
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Vehicles table
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  price: integer("price").notNull(),
  mileage: integer("mileage"),
  exteriorColor: text("exterior_color"),
  interiorColor: text("interior_color"),
  vin: text("vin"),
  transmission: text("transmission"),
  fuelEconomy: text("fuel_economy"),
  description: text("description"),
  condition: text("condition"), // new, used, certified
  bodyStyle: text("body_style"), // sedan, suv, truck, etc.
  features: text("features").array(),
  images: text("images").array(),
  modelUrl: text("model_url"),  // URL to 3D model
  isSpecialOffer: boolean("is_special_offer").default(false),
  isNewArrival: boolean("is_new_arrival").default(false),
  isSold: boolean("is_sold").default(false),
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
});

// Contact Form Submissions
export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  message: text("message").notNull(),
  subject: text("subject"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContactSchema = createInsertSchema(contactSubmissions).omit({
  id: true,
  createdAt: true,
});

// Credit Applications
export const creditApplications = pgTable("credit_applications", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zip: text("zip").notNull(),
  employmentStatus: text("employment_status").notNull(),
  employerName: text("employer_name"),
  monthlyIncome: integer("monthly_income"),
  driversLicense: text("drivers_license"), // Changed from SSN to driver's license
  dob: text("dob").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCreditApplicationSchema = createInsertSchema(creditApplications).omit({
  id: true,
  createdAt: true,
});

// Trade-In Appraisals
export const tradeInAppraisals = pgTable("trade_in_appraisals", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  mileage: integer("mileage").notNull(),
  condition: text("condition").notNull(),
  exteriorColor: text("exterior_color"),
  hasLoan: boolean("has_loan"),
  loanAmount: integer("loan_amount"),
  additionalInfo: text("additional_info"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTradeInSchema = createInsertSchema(tradeInAppraisals).omit({
  id: true,
  createdAt: true,
});

// Appointments (Service and Inquiry)
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  type: text("type").notNull(), // service, test-drive, general-inquiry
  vehicleId: integer("vehicle_id"), // Optional, for specific vehicle inquiries
  serviceType: text("service_type"), // For service appointments
  notes: text("notes"),
  status: text("status").default("pending"), // pending, confirmed, completed, cancelled
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  status: true,
  createdAt: true,
});

// Quick Inquiries
export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  interestType: text("interest_type").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInquirySchema = createInsertSchema(inquiries).omit({
  id: true,
  createdAt: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = z.infer<typeof insertContactSchema>;

export type CreditApplication = typeof creditApplications.$inferSelect;
export type InsertCreditApplication = z.infer<typeof insertCreditApplicationSchema>;

export type TradeInAppraisal = typeof tradeInAppraisals.$inferSelect;
export type InsertTradeInAppraisal = z.infer<typeof insertTradeInSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type Inquiry = typeof inquiries.$inferSelect;
export type InsertInquiry = z.infer<typeof insertInquirySchema>;
