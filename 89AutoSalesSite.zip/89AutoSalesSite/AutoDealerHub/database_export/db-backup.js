#!/usr/bin/env node

/**
 * Database Backup/Import Utility for 89 Auto Sales
 * 
 * This script provides command line utilities to:
 * 1. Export the current database to a SQL backup file
 * 2. Import a SQL backup file to restore the database
 * 
 * Usage:
 *   - Export: node db-backup.js export [output_file.sql]
 *   - Import: node db-backup.js import [input_file.sql]
 *
 * If no filename is provided, it uses the default: dealership_backup.sql
 */

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import readline from 'readline';
import { fileURLToPath } from 'url';

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Default configuration
const DEFAULT_FILENAME = 'dealership_backup.sql';
const BACKUP_DIR = path.join(__dirname, '../backup');

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

// Get command line arguments
const command = process.argv[2];
const fileArg = process.argv[3];
const backupFile = fileArg || path.join(BACKUP_DIR, DEFAULT_FILENAME);

// Get database credentials from environment
const dbConfig = {
  user: process.env.PGUSER,
  host: process.env.PGHOST,
  port: process.env.PGPORT,
  database: process.env.PGDATABASE
};

// Validate required environment variables
function checkEnvironment() {
  const requiredVars = ['PGUSER', 'PGHOST', 'PGPORT', 'PGDATABASE'];
  const missing = requiredVars.filter(v => !process.env[v]);
  
  if (missing.length > 0) {
    console.error(`❌ Missing required environment variables: ${missing.join(', ')}`);
    console.error('Make sure your database connection is properly configured.');
    process.exit(1);
  }
}

// Export database to SQL file
async function exportDatabase() {
  console.log(`📤 Exporting database to ${backupFile}...`);
  
  const pgDump = spawn('pg_dump', [
    '-U', dbConfig.user,
    '-h', dbConfig.host,
    '-p', dbConfig.port,
    '-d', dbConfig.database,
    '-f', backupFile,
    '--clean'
  ]);

  pgDump.stdout.on('data', (data) => console.log(data.toString()));
  pgDump.stderr.on('data', (data) => console.error(`pg_dump: ${data}`));

  return new Promise((resolve, reject) => {
    pgDump.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ Database successfully exported to ${backupFile}`);
        console.log(`📏 Backup file size: ${(fs.statSync(backupFile).size / 1024).toFixed(2)} KB`);
        resolve();
      } else {
        console.error(`❌ pg_dump exited with code ${code}`);
        reject(new Error(`pg_dump failed with code ${code}`));
      }
    });
  });
}

// Import database from SQL file
async function importDatabase() {
  if (!fs.existsSync(backupFile)) {
    console.error(`❌ Backup file not found: ${backupFile}`);
    process.exit(1);
  }

  console.log(`📥 Importing database from ${backupFile}...`);
  
  // Ask for confirmation before proceeding
  if (await confirmImport() === false) {
    console.log('Import canceled.');
    process.exit(0);
  }

  const psql = spawn('psql', [
    '-U', dbConfig.user,
    '-h', dbConfig.host,
    '-p', dbConfig.port,
    '-d', dbConfig.database,
    '-f', backupFile
  ]);

  psql.stdout.on('data', (data) => console.log(data.toString()));
  psql.stderr.on('data', (data) => console.error(`psql: ${data}`));

  return new Promise((resolve, reject) => {
    psql.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ Database successfully imported from ${backupFile}`);
        resolve();
      } else {
        console.error(`❌ psql exited with code ${code}`);
        reject(new Error(`psql failed with code ${code}`));
      }
    });
  });
}

// Function to ask for confirmation before import
function confirmImport() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  return new Promise((resolve) => {
    rl.question('⚠️ WARNING: This will overwrite the current database. Continue? (y/n) ', (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y');
    });
  });
}

// Create zip archive of backup file
async function createZipArchive() {
  const zipFilename = backupFile.replace('.sql', '.zip');
  console.log(`🗜️ Creating zip archive: ${zipFilename}...`);
  
  const zip = spawn('zip', [zipFilename, backupFile]);
  
  zip.stdout.on('data', (data) => console.log(data.toString()));
  zip.stderr.on('data', (data) => console.error(`zip: ${data}`));

  return new Promise((resolve, reject) => {
    zip.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ Zip archive created: ${zipFilename}`);
        resolve(zipFilename);
      } else {
        console.error(`❌ zip exited with code ${code}`);
        reject(new Error(`zip failed with code ${code}`));
      }
    });
  });
}

// Main execution
async function main() {
  try {
    checkEnvironment();
    
    switch(command) {
      case 'export':
        await exportDatabase();
        // Create a zip archive if requested
        if (process.argv.includes('--zip')) {
          await createZipArchive();
        }
        break;
      case 'import':
        await importDatabase();
        break;
      default:
        console.error('❌ Invalid command. Use "export" or "import".');
        console.log('Usage examples:');
        console.log('  node db-backup.js export [filename.sql]');
        console.log('  node db-backup.js export --zip');
        console.log('  node db-backup.js import [filename.sql]');
    }
  } catch (error) {
    console.error(`❌ Error: ${error.message}`);
    process.exit(1);
  }
}

main();