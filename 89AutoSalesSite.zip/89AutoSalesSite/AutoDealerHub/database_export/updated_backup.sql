--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.vehicles DROP CONSTRAINT vehicles_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_username_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.trade_in_appraisals DROP CONSTRAINT trade_in_appraisals_pkey;
ALTER TABLE ONLY public.inquiries DROP CONSTRAINT inquiries_pkey;
ALTER TABLE ONLY public.credit_applications DROP CONSTRAINT credit_applications_pkey;
ALTER TABLE ONLY public.contact_submissions DROP CONSTRAINT contact_submissions_pkey;
ALTER TABLE ONLY public.appointments DROP CONSTRAINT appointments_pkey;
ALTER TABLE public.vehicles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.trade_in_appraisals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inquiries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.credit_applications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contact_submissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.appointments ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.vehicles_id_seq;
DROP TABLE public.vehicles;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.trade_in_appraisals_id_seq;
DROP TABLE public.trade_in_appraisals;
DROP SEQUENCE public.inquiries_id_seq;
DROP TABLE public.inquiries;
DROP SEQUENCE public.credit_applications_id_seq;
DROP TABLE public.credit_applications;
DROP SEQUENCE public.contact_submissions_id_seq;
DROP TABLE public.contact_submissions;
DROP SEQUENCE public.appointments_id_seq;
DROP TABLE public.appointments;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    date text NOT NULL,
    "time" text NOT NULL,
    type text NOT NULL,
    vehicle_id integer,
    service_type text,
    notes text,
    status text DEFAULT 'pending'::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.appointments OWNER TO neondb_owner;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO neondb_owner;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: contact_submissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.contact_submissions (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    subject text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.contact_submissions OWNER TO neondb_owner;

--
-- Name: contact_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.contact_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contact_submissions_id_seq OWNER TO neondb_owner;

--
-- Name: contact_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.contact_submissions_id_seq OWNED BY public.contact_submissions.id;


--
-- Name: credit_applications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.credit_applications (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    zip text NOT NULL,
    employment_status text NOT NULL,
    employer_name text,
    monthly_income integer,
    ssn text,
    dob text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.credit_applications OWNER TO neondb_owner;

--
-- Name: credit_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.credit_applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_applications_id_seq OWNER TO neondb_owner;

--
-- Name: credit_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.credit_applications_id_seq OWNED BY public.credit_applications.id;


--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.inquiries (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    interest_type text NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inquiries OWNER TO neondb_owner;

--
-- Name: inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.inquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inquiries_id_seq OWNER TO neondb_owner;

--
-- Name: inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.inquiries_id_seq OWNED BY public.inquiries.id;


--
-- Name: trade_in_appraisals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.trade_in_appraisals (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    year integer NOT NULL,
    mileage integer NOT NULL,
    condition text NOT NULL,
    exterior_color text,
    has_loan boolean,
    loan_amount integer,
    additional_info text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trade_in_appraisals OWNER TO neondb_owner;

--
-- Name: trade_in_appraisals_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.trade_in_appraisals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trade_in_appraisals_id_seq OWNER TO neondb_owner;

--
-- Name: trade_in_appraisals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.trade_in_appraisals_id_seq OWNED BY public.trade_in_appraisals.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vehicles (
    id integer NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    year integer NOT NULL,
    price integer NOT NULL,
    mileage integer,
    exterior_color text,
    interior_color text,
    vin text,
    transmission text,
    fuel_economy text,
    description text,
    condition text,
    body_style text,
    features text[],
    images text[],
    model_url text,
    is_special_offer boolean DEFAULT false,
    is_new_arrival boolean DEFAULT false,
    is_sold boolean DEFAULT false
);


ALTER TABLE public.vehicles OWNER TO neondb_owner;

--
-- Name: vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicles_id_seq OWNER TO neondb_owner;

--
-- Name: vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vehicles_id_seq OWNED BY public.vehicles.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: contact_submissions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.contact_submissions ALTER COLUMN id SET DEFAULT nextval('public.contact_submissions_id_seq'::regclass);


--
-- Name: credit_applications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_applications ALTER COLUMN id SET DEFAULT nextval('public.credit_applications_id_seq'::regclass);


--
-- Name: inquiries id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.inquiries ALTER COLUMN id SET DEFAULT nextval('public.inquiries_id_seq'::regclass);


--
-- Name: trade_in_appraisals id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.trade_in_appraisals ALTER COLUMN id SET DEFAULT nextval('public.trade_in_appraisals_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicles id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN id SET DEFAULT nextval('public.vehicles_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.appointments (id, name, email, phone, date, "time", type, vehicle_id, service_type, notes, status, created_at) FROM stdin;
\.


--
-- Data for Name: contact_submissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.contact_submissions (id, name, email, phone, message, subject, created_at) FROM stdin;
\.


--
-- Data for Name: credit_applications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.credit_applications (id, first_name, last_name, email, phone, address, city, state, zip, employment_status, employer_name, monthly_income, ssn, dob, created_at) FROM stdin;
\.


--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.inquiries (id, name, email, phone, interest_type, message, created_at) FROM stdin;
\.


--
-- Data for Name: trade_in_appraisals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.trade_in_appraisals (id, name, email, phone, make, model, year, mileage, condition, exterior_color, has_loan, loan_amount, additional_info, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, password) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vehicles (id, make, model, year, price, mileage, exterior_color, interior_color, vin, transmission, fuel_economy, description, condition, body_style, features, images, model_url, is_special_offer, is_new_arrival, is_sold) FROM stdin;
1	Chevrolet	Camaro ZL1	2022	71995	7630	Rapid Blue	Jet Black with Red Accents	1G1FK1R69N0123456	6-Speed Manual	16/24 mpg	Track-ready performance with 650 horsepower supercharged V8 engine	used	Coupe	{"Supercharged 6.2L V8","Magnetic Ride Control","Recaro Performance Seats","Brembo Brakes","Performance Data Recorder"}	{https://images.pexels.com/photos/12086528/pexels-photo-12086528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1}	https://sketchfab.com/models/e922cc630dbe41089bce65d1c4f116f7/embed	f	f	t
3	BMW	5 Series	2022	62495	18201	Alpine White	Cognac Leather	WBA53BL03NCG12345	Automatic	23/30 mpg	Executive Sedan with M Sport Package	used	Sedan	{"M Sport Package","Heated Steering Wheel","Premium Sound","Parking Sensors","Heads-up Display"}	{https://images.unsplash.com/photo-1570733577524-3a047079e80d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=533&q=80}	https://sketchfab.com/models/f8169266571c4644a4e97c15ed64a531/embed	t	f	f
4	Audi	Q5	2023	54995	12750	Navarra Blue	Gray Leather	WA1BNAFY7P2123456	Automatic	22/28 mpg	Premium Plus SUV with Technology Package	used	SUV	{"Quattro AWD","Bang & Olufsen Sound","Panoramic Sunroof","Virtual Cockpit","Lane Assist"}	{https://images.unsplash.com/photo-1580273916550-e323be2ae537?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=533&q=80}	https://sketchfab.com/models/ab80752f9fb7492d8b0848682e310a85/embed	f	f	f
5	Lexus	RX 350	2023	58995	8500	Eminent White Pearl	Black NuLuxe	2T2HZMDA7PC123456	Automatic	20/27 mpg	Luxury SUV with F Sport Package	certified	SUV	{"F Sport Package","Mark Levinson Audio","Panoramic View Monitor","Adaptive Suspension","Leather Seats"}	{https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80}	https://sketchfab.com/models/d1d0f7a3d6334a00874cae0c944c73af/embed	f	t	f
6	Porsche	911 Carrera	2022	119900	7823	GT Silver Metallic	Black Leather	WP0AB2A94NS123456	PDK	18/24 mpg	Sports Car with Premium Package Plus	used	Coupe	{"Sport Chrono Package","Sport Exhaust","Adaptive Sport Seats","BOSE Surround Sound","Lane Change Assist"}	{https://images.unsplash.com/photo-1580274455191-1c62238fa333?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80}	https://sketchfab.com/models/50970aeebc144969bbf0112874b3b1ea/embed	t	f	f
7	Tesla	Model Y	2023	65990	5210	Pearl White	Black	5YJYGDEE1NF123456	Automatic	129/112 MPGe	Long Range All-Wheel Drive Electric SUV	used	SUV	{Autopilot,"Glass Roof","Premium Interior","20\\" Induction Wheels","Tow Hitch"}	{https://images.unsplash.com/photo-1619115854012-695e733e1ef8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80}	https://sketchfab.com/models/60a36bda9e1a472a8dbcad0db163bc25/embed	f	t	f
2	Mercedes-Benz	S-Class	2023	89995	15523	Obsidian Black	Black Leather	WDDUG8GB3MA456789	Automatic	25/32 mpg	Luxury Sedan with Premium Package	new	Sedan	{Navigation,"Heated Seats",Sunroof,Bluetooth,"Backup Camera"}	{https://images.unsplash.com/photo-1616422285623-13ff0162193c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=533&q=80}	https://sketchfab.com/models/a208b91171254a7cbc257f1ab73d6118/embed	f	t	t
8	Ford	Mustang GT	2023	55995	2500	Race Red	Black Leather	1FA6P8CF0P5123456	10-Speed Automatic	15/24 mpg	Performance Package with 460HP V8 engine	new	Coupe	{"V8 Engine","Performance Package","Leather Seats",Navigation,"Premium Sound"}	{https://images.unsplash.com/photo-1585011070337-c95ce6e8cf93?q=80&w=1700&auto=format&fit=crop}	https://sketchfab.com/models/88469a095df04a728c54350ebf022e55/embed	t	t	f
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.appointments_id_seq', 1, false);


--
-- Name: contact_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.contact_submissions_id_seq', 1, false);


--
-- Name: credit_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.credit_applications_id_seq', 1, false);


--
-- Name: inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.inquiries_id_seq', 1, false);


--
-- Name: trade_in_appraisals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.trade_in_appraisals_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vehicles_id_seq', 8, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: contact_submissions contact_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.contact_submissions
    ADD CONSTRAINT contact_submissions_pkey PRIMARY KEY (id);


--
-- Name: credit_applications credit_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_applications
    ADD CONSTRAINT credit_applications_pkey PRIMARY KEY (id);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: trade_in_appraisals trade_in_appraisals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.trade_in_appraisals
    ADD CONSTRAINT trade_in_appraisals_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

