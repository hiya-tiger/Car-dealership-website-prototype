import { useState, useEffect, useRef } from "react";
import { useLocation, Link } from "wouter";
import { Menu, MapPin, Phone, Mail, X, Car, Clock, Search, User, Heart, ChevronDown, ShieldCheck } from "lucide-react";
import MobileMenu from "./mobile-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Tooltip } from "@/components/ui/tooltip";

const Header = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [megaMenuOpen, setMegaMenuOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [savedVehicles, setSavedVehicles] = useState(0); // This would be fetched from user state in a real app
  
  // Handle scroll effect for sticky header
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 80) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  // Focus search input when search bar is opened
  useEffect(() => {
    if (searchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [searchOpen]);
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
    if (searchOpen) setSearchOpen(false);
    if (megaMenuOpen) setMegaMenuOpen(false);
  };
  
  const toggleSearch = () => {
    setSearchOpen(!searchOpen);
    if (mobileMenuOpen) setMobileMenuOpen(false);
    if (megaMenuOpen) setMegaMenuOpen(false);
  };
  
  const toggleMegaMenu = () => {
    setMegaMenuOpen(!megaMenuOpen);
    if (searchOpen) setSearchOpen(false);
    if (mobileMenuOpen) setMobileMenuOpen(false);
  };
  
  const handleEscKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      if (searchOpen) setSearchOpen(false);
      if (megaMenuOpen) setMegaMenuOpen(false);
    }
  };

  return (
    <header className={cn(
      "fixed w-full z-50 transition-all duration-300",
      scrolled ? "bg-black/95 shadow-lg backdrop-blur-sm" : "bg-black"
    )}>
      <div className="container mx-auto">
        {/* Top Bar */}
        <div className="hidden md:flex justify-between items-center py-2 text-sm text-white border-b border-gray-800 px-4 transition-all duration-300">
          <div className="flex space-x-6">
            <a href="tel:1-800-555-1234" className="hover:text-primary flex items-center group transition-colors duration-200">
              <Phone className="w-4 h-4 mr-1 group-hover:animate-pulse text-primary" /> 1-800-555-1234
            </a>
            <a href="mailto:info@89autosales.com" className="hover:text-primary flex items-center group transition-colors duration-200">
              <Mail className="w-4 h-4 mr-1 group-hover:animate-pulse text-primary" /> info@89autosales.com
            </a>
            <div className="flex items-center group">
              <Clock className="w-4 h-4 mr-1 text-primary" /> 
              <span>Mon-Sat: 9AM-7PM | Sun: 10AM-5PM</span>
            </div>
          </div>
          <div className="flex space-x-6">
            <Link href="/location" className="hover:text-primary flex items-center group transition-colors duration-200">
              <MapPin className="w-4 h-4 mr-1 group-hover:animate-pulse text-primary" /> Find a Dealership
            </Link>
            <Link href="/service" className="hover:text-primary flex items-center group transition-colors duration-200">
              <Car className="w-4 h-4 mr-1 group-hover:animate-pulse text-primary" /> Schedule Service
            </Link>
            <div className="flex items-center group mr-2">
              <ShieldCheck className="w-4 h-4 mr-1 text-primary" />
              <span className="text-white/90">Certified Pre-Owned</span>
            </div>
            <div className="flex space-x-2 items-center">
              <a href="#" className="hover:text-primary px-2 py-1 rounded transition-colors duration-200">EN</a>
              <span className="text-gray-600">|</span>
              <a href="#" className="hover:text-primary px-2 py-1 rounded transition-colors duration-200">ES</a>
            </div>
          </div>
        </div>
        
        {/* Main Header */}
        <div className="flex justify-between items-center py-4 px-4 transition-all duration-300">
          {/* Logo */}
          <Link href="/" className="flex items-center group">
            <div className="text-2xl font-bold font-heading relative">
              <span className="text-primary group-hover:animate-pulse transition-all duration-300">89</span>{" "}
              <span className="text-white">AUTO SALES</span>
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </div>
          </Link>
          
          {/* Main Navigation - Desktop */}
          <nav className="hidden lg:flex items-center space-x-8">
            <div className="relative group">
              <button 
                onClick={toggleMegaMenu}
                className={`flex items-center font-medium hover:text-primary transition-colors ${location.startsWith('/inventory') ? 'text-primary' : 'text-white'}`}
              >
                Inventory <ChevronDown className={`ml-1 w-4 h-4 transition-transform duration-200 ${megaMenuOpen ? 'rotate-180' : ''}`} />
              </button>
              <div className={`absolute top-full left-0 w-[600px] bg-black/95 backdrop-blur-sm shadow-lg rounded-b-lg p-6 transition-all duration-300 ${megaMenuOpen ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible -translate-y-2'}`}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-primary font-medium mb-3 text-lg">Browse by Type</h3>
                    <ul className="space-y-2">
                      <li><Link href="/inventory/sedan" className="text-white hover:text-primary transition-colors block">Sedans</Link></li>
                      <li><Link href="/inventory/suv" className="text-white hover:text-primary transition-colors block">SUVs</Link></li>
                      <li><Link href="/inventory/truck" className="text-white hover:text-primary transition-colors block">Trucks</Link></li>
                      <li><Link href="/inventory/luxury" className="text-white hover:text-primary transition-colors block">Luxury</Link></li>
                      <li><Link href="/inventory/electric" className="text-white hover:text-primary transition-colors block">Electric & Hybrid</Link></li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-primary font-medium mb-3 text-lg">Quick Links</h3>
                    <ul className="space-y-2">
                      <li><Link href="/inventory/special-offers" className="text-white hover:text-primary transition-colors block">Special Offers</Link></li>
                      <li><Link href="/inventory/new-arrivals" className="text-white hover:text-primary transition-colors block">New Arrivals</Link></li>
                      <li><Link href="/inventory/certified-pre-owned" className="text-white hover:text-primary transition-colors block">Certified Pre-Owned</Link></li>
                      <li><Link href="/inventory/under-15k" className="text-white hover:text-primary transition-colors block">Under $15,000</Link></li>
                    </ul>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-800">
                  <Link href="/inventory">
                    <Button className="w-full bg-primary hover:bg-primary-600 text-white">View All Inventory</Button>
                  </Link>
                </div>
              </div>
            </div>
            <Link href="/financing" className={`font-medium hover:text-primary transition-colors relative group ${location.startsWith('/financing') ? 'text-primary' : 'text-white'}`}>
              Financing
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </Link>
            <Link href="/trade-in" className={`font-medium hover:text-primary transition-colors relative group ${location === '/trade-in' ? 'text-primary' : 'text-white'}`}>
              Trade-In
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </Link>
            <Link href="/service" className={`font-medium hover:text-primary transition-colors relative group ${location === '/service' ? 'text-primary' : 'text-white'}`}>
              Service
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </Link>
            <Link href="/about" className={`font-medium hover:text-primary transition-colors relative group ${location === '/about' ? 'text-primary' : 'text-white'}`}>
              About Us
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </Link>
            <Link href="/contact" className={`font-medium hover:text-primary transition-colors relative group ${location === '/contact' ? 'text-primary' : 'text-white'}`}>
              Contact
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></div>
            </Link>
          </nav>
          
          {/* Action Buttons */}
          <div className="hidden lg:flex items-center space-x-4">
            <Tooltip content="Search Inventory">
              <button 
                onClick={toggleSearch}
                className="text-white hover:text-primary focus:outline-none transition-colors duration-200 p-2 rounded-full hover:bg-white/10"
                aria-label="Search inventory"
              >
                <Search className="w-5 h-5" />
              </button>
            </Tooltip>
            
            <Tooltip content="Saved Vehicles">
              <Link href="/saved-vehicles">
                <button className="text-white hover:text-primary focus:outline-none transition-colors duration-200 p-2 rounded-full hover:bg-white/10 relative">
                  <Heart className="w-5 h-5" />
                  <Badge className="absolute -top-1 -right-1 bg-primary text-white text-xs w-5 h-5 flex items-center justify-center p-0 rounded-full shadow-lg animate-pulse-subtle">{savedVehicles}</Badge>
                </button>
              </Link>
            </Tooltip>
            
            <Tooltip content="My Account">
              <Link href="/account">
                <button className="text-white hover:text-primary focus:outline-none transition-colors duration-200 p-2 rounded-full hover:bg-white/10">
                  <User className="w-5 h-5" />
                </button>
              </Link>
            </Tooltip>
            
            <Link href="/service">
              <Button className="bg-primary hover:bg-primary-600 text-white shadow-md font-medium border-0 transition-transform duration-200 hover:scale-105">
                Book Appointment
              </Button>
            </Link>
          </div>
          
          {/* Hamburger Menu Button */}
          <button 
            className="lg:hidden text-white hover:text-primary focus:outline-none transition-colors"
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
        
        {/* Search Bar */}
        <div className={cn(
          "overflow-hidden transition-all duration-300 bg-gray-900/95 backdrop-blur-sm border-t border-gray-800",
          searchOpen ? "max-h-20 py-4" : "max-h-0"
        )}>
          <div className="container mx-auto px-4 flex" onKeyDown={handleEscKey}>
            <Input 
              ref={searchInputRef}
              type="search" 
              placeholder="Search by make, model, or keyword..." 
              className="flex-grow bg-white/10 border-gray-700 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary"
            />
            <Button className="ml-2 bg-primary hover:bg-primary-600 transition-transform duration-200 hover:scale-105">
              <Search className="w-4 h-4 mr-2" /> Search
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <MobileMenu isOpen={mobileMenuOpen} onClose={toggleMobileMenu} />
      
      {/* Spacer for fixed header */}
      <div className="h-[72px] md:h-[116px]"></div>
    </header>
  );
};

export default Header;
