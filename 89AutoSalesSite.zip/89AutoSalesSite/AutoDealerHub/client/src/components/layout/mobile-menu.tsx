import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Phone, Mail, MapPin, ChevronRight, Heart, User, Search, Car, Clock, ShieldCheck, X, BarChart2, Zap, Sparkles, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Tooltip } from "@/components/ui/tooltip";
import { formatNumber } from "@/lib/utils";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  const [location] = useLocation();
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [savedVehicles, setSavedVehicles] = useState(3); // This would be fetched from user state in a real app
  const [compareVehicles, setCompareVehicles] = useState(2); // Number of vehicles in comparison
  const [recentlyViewed, setRecentlyViewed] = useState(5); // Recently viewed vehicles count
  const menuRef = useRef<HTMLDivElement>(null);
  
  // Handle click outside to close menu
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node) && isOpen) {
        onClose();
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  // Reset expanded section when menu closes
  useEffect(() => {
    if (!isOpen) {
      setExpandedSection(null);
    } else {
      // Lock body scroll when menu is open
      document.body.style.overflow = 'hidden';
    }
    
    return () => {
      // Restore body scroll when component unmounts or menu closes
      document.body.style.overflow = '';
    };
  }, [isOpen]);
  
  // Handle escape key to close menu
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEscKey);
    return () => {
      window.removeEventListener('keydown', handleEscKey);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };
  
  // Check if a route is active
  const isActive = (path: string) => {
    if (path === '/') return location === '/';
    return location.startsWith(path);
  };
  
  // Animation variants
  const menuVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0, transition: { staggerChildren: 0.07, delayChildren: 0.2 } },
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  };
  
  const pulseVariants = {
    pulse: {
      scale: [1, 1.05, 1],
      opacity: [0.7, 1, 0.7],
      transition: { repeat: Infinity, duration: 2 }
    }
  };

  return (
    <motion.div 
      ref={menuRef}
      className="fixed inset-0 z-50 lg:hidden overflow-hidden bg-black/95 backdrop-blur-sm shadow-lg text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      aria-modal="true"
      role="dialog"
      aria-label="Mobile navigation menu"
    >
      <div className="container mx-auto px-4 py-6 h-full overflow-y-auto">
        {/* Close button */}
        <div className="flex justify-end mb-4">
          <button 
            onClick={onClose} 
            className="p-2 rounded-full hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-black"
            aria-label="Close menu"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Quick Contact Info */}
        <div className="mb-6 space-y-3 border-b border-gray-800 pb-4">
          <motion.div variants={itemVariants}>
            <a href="tel:1-800-555-1234" className="flex items-center text-white hover:text-primary transition-colors group">
              <Phone className="w-4 h-4 mr-2 text-primary group-hover:animate-pulse" /> 1-800-555-1234
            </a>
          </motion.div>
          <motion.div variants={itemVariants}>
            <a href="mailto:info@89autosales.com" className="flex items-center text-white hover:text-primary transition-colors group">
              <Mail className="w-4 h-4 mr-2 text-primary group-hover:animate-pulse" /> info@89autosales.com
            </a>
          </motion.div>
          <motion.div variants={itemVariants}>
            <div className="flex items-center text-white group">
              <Clock className="w-4 h-4 mr-2 text-primary" /> 
              <span>Mon-Sat: 9AM-7PM | Sun: 10AM-5PM</span>
            </div>
          </motion.div>
          <motion.div variants={itemVariants}>
            <Link href="/location" className="flex items-center text-white hover:text-primary transition-colors group">
              <MapPin className="w-4 h-4 mr-2 text-primary group-hover:animate-pulse" /> Find a Dealership
            </Link>
          </motion.div>
        </div>

        {/* Quick Actions */}
        <motion.div 
          className="grid grid-cols-3 gap-2 mb-6 border-b border-gray-800 pb-4"
          variants={menuVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <Link 
              href="/saved-vehicles" 
              onClick={onClose} 
              className="flex flex-col items-center justify-center p-3 hover:bg-white/10 rounded-lg transition-all duration-200 relative group"
              aria-label="Saved vehicles"
            >
              <Heart className="w-5 h-5 mb-1 text-primary group-hover:scale-110 transition-transform duration-200" />
              <span className="text-xs">Saved</span>
              <Badge 
                className="absolute top-1 right-1 bg-primary text-white text-xs w-4 h-4 flex items-center justify-center p-0 rounded-full shadow-glow animate-pulse-subtle"
                aria-label={`${savedVehicles} saved vehicles`}
              >
                {savedVehicles}
              </Badge>
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/account" 
              onClick={onClose} 
              className="flex flex-col items-center justify-center p-3 hover:bg-white/10 rounded-lg transition-all duration-200 group"
              aria-label="My account"
            >
              <User className="w-5 h-5 mb-1 text-primary group-hover:scale-110 transition-transform duration-200" />
              <span className="text-xs">Account</span>
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/search" 
              onClick={onClose} 
              className="flex flex-col items-center justify-center p-3 hover:bg-white/10 rounded-lg transition-all duration-200 group"
              aria-label="Search inventory"
            >
              <Search className="w-5 h-5 mb-1 text-primary group-hover:scale-110 transition-transform duration-200" />
              <span className="text-xs">Search</span>
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/compare-vehicles" 
              onClick={onClose} 
              className="flex flex-col items-center justify-center p-3 hover:bg-white/10 rounded-lg transition-all duration-200 group relative"
              aria-label="Compare vehicles"
            >
              <BarChart2 className="w-5 h-5 mb-1 text-primary group-hover:scale-110 transition-transform duration-200" />
              <span className="text-xs">Compare</span>
              {compareVehicles > 0 && (
                <Badge 
                  className="absolute top-1 right-1 bg-primary text-white text-xs w-4 h-4 flex items-center justify-center p-0 rounded-full shadow-glow animate-pulse-subtle"
                  aria-label={`${compareVehicles} vehicles in comparison`}
                >
                  {compareVehicles}
                </Badge>
              )}
            </Link>
          </motion.div>
        </motion.div>

        {/* Recently Viewed */}
        <motion.div 
          className="mb-6 border-b border-gray-800 pb-4"
          variants={menuVariants}
          initial="hidden"
          animate="visible"
        >
          <h3 className="text-sm font-medium text-white/80 mb-3 flex items-center">
            <Clock className="w-4 h-4 mr-2 text-primary" /> Recently Viewed
            <Badge className="ml-2 bg-white/10 text-white text-xs">{recentlyViewed}</Badge>
          </h3>
          <div className="flex overflow-x-auto pb-2 gap-3 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
            <motion.div 
              variants={itemVariants}
              className="flex-shrink-0 w-32 rounded-lg overflow-hidden bg-white/5 group relative"
            >
              <div className="aspect-[4/3] bg-gray-800 relative">
                <div className="absolute inset-0 flex items-center justify-center text-white/30">
                  <Car className="w-8 h-8" />
                </div>
              </div>
              <div className="p-2">
                <div className="text-xs font-medium text-white truncate">Honda Accord</div>
                <div className="text-xs text-white/60">2020 • $18,500</div>
              </div>
              <div className="absolute top-1 right-1">
                <button className="text-white/70 hover:text-primary p-1 rounded-full bg-black/50 transition-colors">
                  <Heart className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="flex-shrink-0 w-32 rounded-lg overflow-hidden bg-white/5 group relative"
            >
              <div className="aspect-[4/3] bg-gray-800 relative">
                <div className="absolute inset-0 flex items-center justify-center text-white/30">
                  <Car className="w-8 h-8" />
                </div>
              </div>
              <div className="p-2">
                <div className="text-xs font-medium text-white truncate">Toyota RAV4</div>
                <div className="text-xs text-white/60">2021 • $24,990</div>
              </div>
              <div className="absolute top-1 right-1">
                <button className="text-white/70 hover:text-primary p-1 rounded-full bg-black/50 transition-colors">
                  <Heart className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="flex-shrink-0 w-32 rounded-lg overflow-hidden bg-white/5 group relative"
            >
              <div className="aspect-[4/3] bg-gray-800 relative">
                <div className="absolute inset-0 flex items-center justify-center text-white/30">
                  <Car className="w-8 h-8" />
                </div>
              </div>
              <div className="p-2">
                <div className="text-xs font-medium text-white truncate">Ford F-150</div>
                <div className="text-xs text-white/60">2019 • $32,750</div>
              </div>
              <div className="absolute top-1 right-1">
                <button className="text-white/70 hover:text-primary p-1 rounded-full bg-black/50 transition-colors">
                  <Heart className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          </div>
        </motion.div>
        
        {/* Main Navigation */}
        <motion.nav 
          className="flex flex-col space-y-2"
          variants={menuVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <Link 
              href="/" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Home"
            >
              <span className="font-medium">Home</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          {/* Inventory with submenu */}
          <motion.div variants={itemVariants} className="rounded-lg overflow-hidden">
            <button 
              onClick={() => toggleSection('inventory')} 
              className={cn(
                "w-full py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/inventory') || expandedSection === 'inventory' ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-expanded={expandedSection === 'inventory'}
              aria-controls="inventory-submenu"
            >
              <span className="font-medium">Inventory</span>
              <ChevronRight className={cn(
                "w-5 h-5 transition-transform duration-300",
                expandedSection === 'inventory' ? 'rotate-90 text-primary' : '',
                isActive('/inventory') ? "text-primary" : "text-gray-500"
              )} />
            </button>
            
            <AnimatePresence>
              {expandedSection === 'inventory' && (
                <motion.div 
                  id="inventory-submenu"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="pl-4 py-2 space-y-2 bg-white/5 rounded-lg mt-1">
                    <Link 
                      href="/inventory/sedan" 
                      onClick={onClose} 
                      className={cn(
                        "block py-2 px-2 transition-colors",
                        isActive('/inventory/sedan') ? "text-primary" : "text-white hover:text-primary"
                      )}
                    >
                      Sedans
                    </Link>
                    <Link 
                      href="/inventory/suv" 
                      onClick={onClose} 
                      className={cn(
                        "block py-2 px-2 transition-colors",
                        isActive('/inventory/suv') ? "text-primary" : "text-white hover:text-primary"
                      )}
                    >
                      SUVs
                    </Link>
                    <Link 
                      href="/inventory/truck" 
                      onClick={onClose} 
                      className={cn(
                        "block py-2 px-2 transition-colors",
                        isActive('/inventory/truck') ? "text-primary" : "text-white hover:text-primary"
                      )}
                    >
                      Trucks
                    </Link>
                    <Link 
                      href="/inventory/luxury" 
                      onClick={onClose} 
                      className={cn(
                        "block py-2 px-2 transition-colors",
                        isActive('/inventory/luxury') ? "text-primary" : "text-white hover:text-primary"
                      )}
                    >
                      Luxury
                    </Link>
                    <Link 
                      href="/inventory/electric" 
                      onClick={onClose} 
                      className={cn(
                        "block py-2 px-2 transition-colors",
                        isActive('/inventory/electric') ? "text-primary" : "text-white hover:text-primary"
                      )}
                    >
                      Electric & Hybrid
                    </Link>
                    <Link 
                      href="/inventory/special-offers" 
                      onClick={onClose} 
                      className={cn(
                        "block py-2 px-2 transition-colors",
                        isActive('/inventory/special-offers') ? "text-primary" : "text-white hover:text-primary"
                      )}
                    >
                      Special Offers
                    </Link>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/financing" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/financing') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Financing"
            >
              <span className="font-medium">Financing</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/financing') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/finance-calculator" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/finance-calculator') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Finance Calculator"
            >
              <span className="font-medium">Finance Calculator</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/finance-calculator') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/trade-in" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/trade-in') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Trade-In"
            >
              <span className="font-medium">Trade-In</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/trade-in') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/service" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/service') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Service"
            >
              <span className="font-medium">Service</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/service') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/about" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/about') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="About Us"
            >
              <span className="font-medium">About Us</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/about') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/contact" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/contact') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Contact Us"
            >
              <span className="font-medium">Contact Us</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/contact') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/credit-application" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/credit-application') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Credit Application"
            >
              <span className="font-medium">Credit Application</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/credit-application') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <Link 
              href="/location" 
              onClick={onClose} 
              className={cn(
                "py-3 px-2 rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center justify-between",
                isActive('/location') ? "bg-white/10 text-primary" : "text-white hover:text-primary"
              )}
              aria-label="Locations"
            >
              <span className="font-medium">Locations</span>
              <ChevronRight className={cn("w-5 h-5", isActive('/location') ? "text-primary" : "text-gray-500")} />
            </Link>
          </motion.div>
        </motion.nav>
        
        {/* Featured Deals */}
        <motion.div 
          className="mt-6 pt-4 border-t border-gray-800"
          variants={menuVariants}
          initial="hidden"
          animate="visible"
        >
          <h3 className="text-sm font-medium text-white/80 mb-3 flex items-center">
            <Sparkles className="w-4 h-4 mr-2 text-primary" /> Featured Deals
          </h3>
          
          <motion.div 
            className="bg-gradient-to-r from-black/60 to-primary/20 rounded-lg p-4 mb-4 relative overflow-hidden"
            variants={itemVariants}
          >
            <motion.div 
              className="absolute top-2 right-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded-full"
              variants={pulseVariants}
              animate="pulse"
            >
              HOT DEAL
            </motion.div>
            <h4 className="text-white font-medium mb-1">Summer Clearance</h4>
            <p className="text-white/70 text-sm mb-2">Up to $3,000 off select models</p>
            <Link 
              href="/inventory/special-offers" 
              onClick={onClose}
              className="text-primary hover:text-white text-sm font-medium flex items-center transition-colors"
            >
              View Offers <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
            <div className="absolute -bottom-6 -right-6 opacity-10">
              <Car className="w-24 h-24" />
            </div>
          </motion.div>
        </motion.div>
        
        {/* CTA Buttons */}
        <motion.div 
          className="mt-4 space-y-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <Link href="/service" onClick={onClose} className="block">
            <Button 
              className="w-full bg-primary hover:bg-primary-600 text-white shadow-md font-medium border-0 py-6 transition-all duration-300 hover:scale-105 hover:shadow-glow"
              aria-label="Book service appointment"
            >
              <Car className="w-5 h-5 mr-2" />
              Book Appointment
            </Button>
          </Link>
          
          <div className="grid grid-cols-2 gap-3">
            <Link 
              href="/credit-application" 
              onClick={onClose}
              className="bg-white/10 hover:bg-white/20 rounded-lg p-3 text-white text-sm flex flex-col items-center justify-center transition-all duration-200 hover:scale-105"
            >
              <ShieldCheck className="w-5 h-5 mb-1 text-primary" />
              Apply for Financing
            </Link>
            
            <Link 
              href="/virtual-showroom" 
              onClick={onClose}
              className="bg-white/10 hover:bg-white/20 rounded-lg p-3 text-white text-sm flex flex-col items-center justify-center transition-all duration-200 hover:scale-105"
            >
              <Zap className="w-5 h-5 mb-1 text-primary" />
              Virtual Showroom
            </Link>
          </div>
          
          <div className="flex justify-center mt-4 text-xs text-white/50">
            <button 
              onClick={onClose}
              className="hover:text-primary transition-colors flex items-center"
            >
              <RefreshCw className="w-3 h-3 mr-1" /> Refresh Inventory
            </button>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default MobileMenu;
