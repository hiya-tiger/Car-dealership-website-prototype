import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail, Clock } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-black text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold font-sans mb-4">89 Auto Sales</h3>
            <p className="text-neutral-400 mb-4">
              Your trusted partner in finding high-performance vehicles for racing enthusiasts.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold font-sans mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-neutral-400 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/inventory" className="text-neutral-400 hover:text-white transition-colors">
                  Inventory
                </Link>
              </li>
              <li>
                <Link href="/financing" className="text-neutral-400 hover:text-white transition-colors">
                  Financing
                </Link>
              </li>
              <li>
                <Link href="/service" className="text-neutral-400 hover:text-white transition-colors">
                  Service Center
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-neutral-400 hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-neutral-400 hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-lg font-bold font-sans mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/inventory?condition=new" className="text-neutral-400 hover:text-white transition-colors">
                  New Vehicles
                </Link>
              </li>
              <li>
                <Link href="/inventory?condition=used" className="text-neutral-400 hover:text-white transition-colors">
                  Pre-Owned Vehicles
                </Link>
              </li>
              <li>
                <Link href="/trade-in" className="text-neutral-400 hover:text-white transition-colors">
                  Vehicle Trade-In
                </Link>
              </li>
              <li>
                <Link href="/financing" className="text-neutral-400 hover:text-white transition-colors">
                  Financing Options
                </Link>
              </li>
              <li>
                <Link href="/service" className="text-neutral-400 hover:text-white transition-colors">
                  Service & Repair
                </Link>
              </li>
              <li>
                <Link href="/service" className="text-neutral-400 hover:text-white transition-colors">
                  Parts Department
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold font-sans mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 mt-1 mr-3 text-red-600" />
                <span className="text-neutral-400">
                  890 Speedway Blvd<br />Charlotte, NC 28216
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 mr-3 text-red-600" />
                <span className="text-neutral-400">(704) 555-8989</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 mr-3 text-red-600" />
                <span className="text-neutral-400">info@89autosales.com</span>
              </li>
              <li className="flex items-center">
                <Clock className="w-5 h-5 mr-3 text-red-600" />
                <div className="text-neutral-400">
                  <div>Mon-Fri: 9AM - 9PM</div>
                  <div>Sat: 9AM - 7PM</div>
                  <div>Sun: 11AM - 5PM</div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-800 pt-6 mt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-neutral-500 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} 89 Auto Sales. All rights reserved.
            </div>
            <div className="flex space-x-4 text-sm text-neutral-500">
              <Link href="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link>
              <Link href="/terms-of-service" className="hover:text-white transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
