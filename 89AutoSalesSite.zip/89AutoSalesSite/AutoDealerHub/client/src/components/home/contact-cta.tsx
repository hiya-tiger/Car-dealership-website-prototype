import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import QuickInquiryForm from "@/components/forms/quick-inquiry-form";

const ContactCTA = () => {
  return (
    <section className="py-16 bg-[#1A3A5F] text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <div className="mb-8 lg:mb-0 text-center lg:text-left max-w-lg">
            <h2 className="text-3xl font-bold font-sans mb-2">Ready to Find Your Perfect Vehicle?</h2>
            <p className="text-neutral-200 mb-6">
              Visit our showroom today or schedule a test drive online. Our team is ready to assist you in finding the perfect vehicle that meets your needs and preferences.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/service">
                <a>
                  <Button className="bg-white text-[#1A3A5F] hover:bg-neutral-100 w-full sm:w-auto">
                    Schedule Test Drive
                  </Button>
                </a>
              </Link>
              <Link href="/contact">
                <a>
                  <Button className="bg-[#D92332] hover:bg-[#C91322] text-white w-full sm:w-auto">
                    Contact Us
                  </Button>
                </a>
              </Link>
            </div>
          </div>
          <div className="w-full lg:w-1/3">
            <QuickInquiryForm />
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactCTA;
