import { Award, Handshake, Wrench, Shield } from "lucide-react";

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard = ({ icon, title, description }: FeatureProps) => {
  return (
    <div className="text-center">
      <div className="w-16 h-16 bg-red-600/10 rounded-full flex items-center justify-center mx-auto mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-bold font-sans mb-2">{title}</h3>
      <p className="text-neutral-600">{description}</p>
    </div>
  );
};

const FeaturesSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold font-sans mb-2">Why Choose 89 Auto Sales</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            We're committed to providing high-performance vehicles and racing-inspired service for automotive enthusiasts.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <FeatureCard
            icon={<Award className="text-red-600 w-8 h-8" />}
            title="Performance Verified"
            description="Every vehicle undergoes performance testing and inspection by our racing technicians."
          />
          
          <FeatureCard
            icon={<Handshake className="text-red-600 w-8 h-8" />}
            title="Enthusiast Experience"
            description="Our staff are passionate gear-heads who understand performance vehicles and racing culture."
          />
          
          <FeatureCard
            icon={<Wrench className="text-red-600 w-8 h-8" />}
            title="Pit Crew Service"
            description="Our certified technicians provide NASCAR-inspired quick and precise maintenance and upgrades."
          />
          
          <FeatureCard
            icon={<Shield className="text-red-600 w-8 h-8" />}
            title="Performance Guarantee"
            description="Comprehensive warranty options backed by our performance guarantee on all vehicles sold."
          />
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
