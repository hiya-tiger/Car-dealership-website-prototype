import { Link } from "wouter";
import { Car, CreditCard, Repeat, ChevronRight } from "lucide-react";

interface QuickLinkProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  linkText: string;
  linkUrl: string;
}

const QuickLinkCard = ({ icon, title, description, linkText, linkUrl }: QuickLinkProps) => {
  return (
    <div className="bg-neutral-100 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 bg-[#1A3A5F] rounded-full flex items-center justify-center text-white">
            {icon}
          </div>
          <h3 className="ml-4 text-xl font-bold font-sans">{title}</h3>
        </div>
        <p className="text-neutral-600 mb-4">{description}</p>
        <Link href={linkUrl}>
          <a className="text-[#D92332] font-medium hover:underline flex items-center">
            {linkText} <ChevronRight className="ml-2 w-4 h-4" />
          </a>
        </Link>
      </div>
    </div>
  );
};

const QuickLinks = () => {
  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <QuickLinkCard
            icon={<Car className="w-6 h-6" />}
            title="Performance Inventory"
            description="Explore our selection of track-ready and high-performance vehicles."
            linkText="View All Vehicles"
            linkUrl="/inventory"
          />
          
          <QuickLinkCard
            icon={<CreditCard className="w-6 h-6" />}
            title="Performance Financing"
            description="Race-ready financing options to get you behind the wheel of your dream performance vehicle."
            linkText="Apply Now"
            linkUrl="/credit-application"
          />
          
          <QuickLinkCard
            icon={<Repeat className="w-6 h-6" />}
            title="Trade-In Your Ride"
            description="Upgrade to a high-performance vehicle with our competitive trade-in program."
            linkText="Start Appraisal"
            linkUrl="/trade-in"
          />
        </div>
      </div>
    </section>
  );
};

export default QuickLinks;
