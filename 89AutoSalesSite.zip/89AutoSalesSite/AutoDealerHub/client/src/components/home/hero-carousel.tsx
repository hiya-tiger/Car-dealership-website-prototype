import { useState, useEffect, useCallback } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface CarouselSlide {
  id: number;
  imageUrl: string;
  heading: string;
  subheading: string;
  ctaLink: string;
  ctaText: string;
  secondaryLink?: string;
  secondaryText?: string;
}

const carouselItems: CarouselSlide[] = [
  {
    id: 1,
    imageUrl: "https://images.pexels.com/photos/1035108/pexels-photo-1035108.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    heading: "Quality Vehicles For Every Driver",
    subheading: "Discover our premium selection of cars, trucks and SUVs for your everyday driving needs.",
    ctaLink: "/inventory",
    ctaText: "View Inventory",
    secondaryLink: "/service",
    secondaryText: "Book a Test Drive"
  },
  {
    id: 2,
    imageUrl: "https://images.pexels.com/photos/3806252/pexels-photo-3806252.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    heading: "Professional Service & Maintenance",
    subheading: "Our expert technicians provide quality maintenance and service for all makes and models.",
    ctaLink: "/service",
    ctaText: "Schedule Service",
    secondaryLink: "/contact",
    secondaryText: "Contact Us"
  },
  {
    id: 3,
    imageUrl: "https://images.pexels.com/photos/97079/pexels-photo-97079.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    heading: "Flexible Financing Solutions",
    subheading: "Affordable financing options to get you behind the wheel of your dream vehicle today.",
    ctaLink: "/financing",
    ctaText: "Explore Options", 
    secondaryLink: "/credit-application",
    secondaryText: "Apply Now"
  }
];

const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % carouselItems.length);
  }, []);

  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [nextSlide]);

  return (
    <section className="relative bg-neutral-800 h-[60vh] md:h-[70vh] overflow-hidden">
      <div className="h-full">
        {/* Carousel items */}
        {carouselItems.map((item, index) => (
          <div 
            key={item.id}
            className={cn(
              "absolute inset-0 transition-opacity duration-1000",
              currentSlide === index ? "opacity-100 z-10" : "opacity-0 z-0"
            )}
          >
            <img 
              src={item.imageUrl} 
              alt={item.heading} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center">
              <div className="container mx-auto px-4 md:px-8">
                <div className="max-w-lg text-white">
                  <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold font-sans mb-4 text-white">
                    <span className="bg-gradient-to-r from-[#D92332] to-white text-transparent bg-clip-text">{item.heading}</span>
                  </h1>
                  <p className="text-lg mb-8">{item.subheading}</p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Link href={item.ctaLink}>
                      <a>
                        <Button 
                          className="w-full sm:w-auto bg-[#D92332] hover:bg-[#B81221] text-white border-0 font-bold shadow-md"
                          size="lg"
                        >
                          {item.ctaText}
                        </Button>
                      </a>
                    </Link>
                    {item.secondaryLink && (
                      <Link href={item.secondaryLink}>
                        <a>
                          <Button 
                            className="w-full sm:w-auto bg-black/70 hover:bg-black/90 text-white border border-[#D92332] backdrop-blur-sm"
                            size="lg"
                          >
                            {item.secondaryText}
                          </Button>
                        </a>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Carousel Controls */}
      <div className="absolute left-0 right-0 bottom-4 flex justify-center gap-3">
        {carouselItems.map((_, index) => (
          <button
            key={index}
            className={cn(
              "w-6 h-2 focus:outline-none transition-all transform duration-300",
              currentSlide === index
                ? "bg-[#D92332] scale-110"
                : "bg-white/60 hover:bg-white/80"
            )}
            onClick={() => setCurrentSlide(index)}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroCarousel;
