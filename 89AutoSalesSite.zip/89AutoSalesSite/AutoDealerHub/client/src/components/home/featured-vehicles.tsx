import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import VehicleCard from "@/components/inventory/vehicle-card";
import { Vehicle } from "@shared/schema";
import { Loader2 } from "lucide-react";

const FeaturedVehicles = () => {
  const { data, isLoading, error } = useQuery<{ vehicles: Vehicle[] }>({
    queryKey: ['/api/vehicles'],
  });

  const vehicles = data?.vehicles || [];

  // Get first 3 vehicles for featured section
  const featuredVehicles = vehicles.slice(0, 3);

  if (isLoading) {
    return (
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h2 className="text-3xl font-bold font-sans mb-2">Featured Vehicles</h2>
            <p className="text-neutral-600 max-w-2xl mx-auto">Loading our premium selection...</p>
            <div className="flex justify-center mt-10">
              <Loader2 className="w-12 h-12 animate-spin text-[#D92332]" />
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h2 className="text-3xl font-bold font-sans mb-2">Featured Vehicles</h2>
            <p className="text-red-600 max-w-2xl mx-auto">
              Unable to load vehicles. Please try again later.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold font-sans mb-2">Featured Performance Vehicles</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Explore our track-tested selection of high-performance vehicles that deliver racing-inspired power and handling.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredVehicles.map((vehicle: Vehicle) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} />
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Link href="/inventory">
            <a>
              <Button className="bg-[#D92332] hover:bg-[#B81221] text-white">
                Browse All Vehicles
              </Button>
            </a>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedVehicles;
