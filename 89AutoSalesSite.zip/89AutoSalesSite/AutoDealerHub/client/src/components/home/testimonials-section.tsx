import { Star, StarHalf } from "lucide-react";

interface Testimonial {
  id: number;
  content: string;
  name: string;
  vehicle: string;
  rating: number;
  avatar: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    content: "The entire car buying process was smooth and transparent. Our sales representative was knowledgeable and helped us find the perfect vehicle for our family's needs.",
    name: "Michael Thompson",
    vehicle: "BMW X5 Owner",
    rating: 5,
    avatar: "https://i.pravatar.cc/100?img=1"
  },
  {
    id: 2,
    content: "I appreciated the no-pressure approach from the sales team. They listened to my needs and helped me find a car that fit my budget. The financing process was quick and easy too.",
    name: "Sarah Johnson",
    vehicle: "Audi A4 Owner",
    rating: 4.5,
    avatar: "https://i.pravatar.cc/100?img=5"
  },
  {
    id: 3,
    content: "The service department is exceptional. They completed the maintenance on my vehicle quickly and kept me informed throughout the process. I wouldn't take my car anywhere else.",
    name: "David Rodriguez",
    vehicle: "Mercedes-Benz C-Class Owner",
    rating: 5,
    avatar: "https://i.pravatar.cc/100?img=12"
  }
];

interface RatingStarsProps {
  rating: number;
}

const RatingStars = ({ rating }: RatingStarsProps) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 !== 0;
  
  return (
    <div className="flex items-center text-[#F7B731] mb-4">
      {[...Array(fullStars)].map((_, i) => (
        <Star key={i} className="fill-current" />
      ))}
      {hasHalfStar && <StarHalf className="fill-current" />}
    </div>
  );
};

const TestimonialsSection = () => {
  return (
    <section className="py-16 bg-neutral-800 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold font-sans mb-2">Customer Experiences</h2>
          <p className="text-neutral-300 max-w-2xl mx-auto">
            Don't just take our word for it. See what our performance enthusiasts have to say about their experience with 89 Auto Sales.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-neutral-700/50 backdrop-blur-sm p-6 rounded-lg">
              <RatingStars rating={testimonial.rating} />
              <p className="mb-4 italic">"{testimonial.content}"</p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-neutral-600 rounded-full overflow-hidden mr-4">
                  <img src={testimonial.avatar} alt={`${testimonial.name} avatar`} className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-bold">{testimonial.name}</div>
                  <div className="text-neutral-300 text-sm">{testimonial.vehicle}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
