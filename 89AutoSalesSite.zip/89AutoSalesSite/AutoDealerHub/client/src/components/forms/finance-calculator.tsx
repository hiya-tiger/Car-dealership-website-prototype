import { useState, useEffect } from "react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

const formSchema = z.object({
  vehiclePrice: z.coerce.number().min(1000, "Price must be at least $1,000").max(1000000, "Price must be less than $1,000,000"),
  downPayment: z.coerce.number().min(0, "Down payment must be a positive number"),
  tradeInValue: z.coerce.number().min(0, "Trade-in value must be a positive number"),
  loanTerm: z.coerce.number().min(12, "Loan term must be at least 12 months").max(84, "Loan term must be at most 84 months"),
  interestRate: z.coerce.number().min(0, "Interest rate must be a positive number").max(30, "Interest rate must be less than 30%"),
});

type CalculatorFormValues = z.infer<typeof formSchema>;

interface PaymentDetails {
  monthlyPayment: number;
  totalInterest: number;
  totalPayment: number;
  financeAmount: number;
}

const FinanceCalculator = () => {
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);
  
  const form = useForm<CalculatorFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      vehiclePrice: 50000,
      downPayment: 5000,
      tradeInValue: 0,
      loanTerm: 60,
      interestRate: 4.5,
    },
  });

  const calculatePayment = (data: CalculatorFormValues) => {
    const { vehiclePrice, downPayment, tradeInValue, loanTerm, interestRate } = data;
    
    // Calculate finance amount
    const financeAmount = vehiclePrice - downPayment - tradeInValue;
    
    if (financeAmount <= 0) {
      setPaymentDetails({
        monthlyPayment: 0,
        totalInterest: 0,
        totalPayment: vehiclePrice - tradeInValue,
        financeAmount: 0,
      });
      return;
    }
    
    // Calculate monthly interest rate
    const monthlyRate = interestRate / 100 / 12;
    
    // Calculate monthly payment using formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
    const monthlyPayment = financeAmount * monthlyRate * Math.pow(1 + monthlyRate, loanTerm) / (Math.pow(1 + monthlyRate, loanTerm) - 1);
    
    // Calculate total interest
    const totalPayment = monthlyPayment * loanTerm;
    const totalInterest = totalPayment - financeAmount;
    
    setPaymentDetails({
      monthlyPayment,
      totalInterest,
      totalPayment,
      financeAmount,
    });
  };

  useEffect(() => {
    // Calculate initial payment
    calculatePayment(form.getValues());
  }, []);

  const onSubmit = (data: CalculatorFormValues) => {
    calculatePayment(data);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  };

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="vehiclePrice"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Vehicle Price</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                      <Input 
                        type="number" 
                        {...field} 
                        className="pl-7" 
                        min={1000}
                        onChange={(e) => {
                          field.onChange(e);
                          if (form.formState.isValid) {
                            calculatePayment(form.getValues());
                          }
                        }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="downPayment"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Down Payment</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                      <Input 
                        type="number" 
                        {...field} 
                        className="pl-7" 
                        min={0}
                        onChange={(e) => {
                          field.onChange(e);
                          if (form.formState.isValid) {
                            calculatePayment(form.getValues());
                          }
                        }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="tradeInValue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Trade-In Value</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                      <Input 
                        type="number" 
                        {...field} 
                        className="pl-7" 
                        min={0}
                        onChange={(e) => {
                          field.onChange(e);
                          if (form.formState.isValid) {
                            calculatePayment(form.getValues());
                          }
                        }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="loanTerm"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Loan Term (months): {field.value}</FormLabel>
                  <FormControl>
                    <Slider
                      min={12}
                      max={84}
                      step={12}
                      defaultValue={[field.value]}
                      onValueChange={(value) => {
                        field.onChange(value[0]);
                        if (form.formState.isValid) {
                          calculatePayment(form.getValues());
                        }
                      }}
                    />
                  </FormControl>
                  <FormDescription className="flex justify-between">
                    <span>12 months</span>
                    <span>84 months</span>
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="interestRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Interest Rate: {field.value}%</FormLabel>
                  <FormControl>
                    <Slider
                      min={0}
                      max={30}
                      step={0.25}
                      defaultValue={[field.value]}
                      onValueChange={(value) => {
                        field.onChange(value[0]);
                        if (form.formState.isValid) {
                          calculatePayment(form.getValues());
                        }
                      }}
                    />
                  </FormControl>
                  <FormDescription className="flex justify-between">
                    <span>0%</span>
                    <span>30%</span>
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-[#1A3A5F] hover:bg-[#0A2A4F]"
            >
              Calculate Payment
            </Button>
          </form>
        </Form>
      </div>
      
      <div>
        <Card>
          <CardHeader>
            <CardTitle>Payment Summary</CardTitle>
            <CardDescription>
              Based on the information you provided
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {paymentDetails && (
              <>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Estimated Monthly Payment</p>
                  <p className="text-4xl font-bold text-[#1A3A5F]">
                    {formatCurrency(paymentDetails.monthlyPayment)}
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Finance Amount</p>
                    <p className="text-lg font-semibold">
                      {formatCurrency(paymentDetails.financeAmount)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Interest</p>
                    <p className="text-lg font-semibold">
                      {formatCurrency(paymentDetails.totalInterest)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Loan Term</p>
                    <p className="text-lg font-semibold">
                      {form.getValues().loanTerm} months
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Cost</p>
                    <p className="text-lg font-semibold">
                      {formatCurrency(paymentDetails.totalPayment + form.getValues().downPayment + form.getValues().tradeInValue)}
                    </p>
                  </div>
                </div>
              </>
            )}
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-muted-foreground text-center">
              This is only an estimate. Contact our financing department for accurate payment information.
            </p>
          </CardFooter>
        </Card>
        
        <div className="mt-6">
          <Button variant="outline" className="w-full">
            <a href="/credit-application">Apply for Financing</a>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FinanceCalculator;
