import React, { Suspense, useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Expand, X } from "lucide-react";

interface ModelEmbedProps {
  modelUrl: string;
}

const ModelEmbed: React.FC<ModelEmbedProps> = ({ modelUrl }) => {
  // Add Sketchfab specific URL parameters for better viewing experience
  const enhancedUrl = modelUrl.includes('?') 
    ? `${modelUrl}&autostart=1&ui_theme=dark&transparent=1`
    : `${modelUrl}?autostart=1&ui_theme=dark&transparent=1`;
  
  return (
    <iframe 
      src={enhancedUrl}
      style={{
        width: "100%",
        height: "100%",
        border: "none",
      }}
      title="3D Model Viewer"
      allow="autoplay; fullscreen; xr-spatial-tracking"
      frameBorder="0"
      allowFullScreen
    />
  );
};

interface ModelViewerProps {
  modelUrl: string | null;
  make: string;
  model: string;
  isFullscreen?: boolean;
}

export const ModelViewer = ({ modelUrl, make, model, isFullscreen = false }: ModelViewerProps) => {
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(false);
  
  if (!modelUrl) {
    return null;
  }

  return (
    <div className={`relative bg-neutral-100 rounded-lg overflow-hidden ${
      isFullscreen ? "w-full h-full min-h-[400px]" : "aspect-video"
    }`}>
      {!isFullscreen && (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              size="icon" 
              className="absolute top-2 right-2 z-10 bg-white/70 hover:bg-white"
            >
              <Expand className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl w-[90vw] h-[80vh] p-0">
            <div className="relative w-full h-full">
              <Button 
                variant="outline" 
                size="icon" 
                className="absolute top-2 right-2 z-10 bg-white/70 hover:bg-white"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
              <ModelEmbed modelUrl={modelUrl} />
            </div>
          </DialogContent>
        </Dialog>
      )}
      <div className="absolute top-0 left-0 z-10 p-3 bg-gradient-to-b from-black/50 to-transparent text-white w-full">
        <h3 className="text-lg font-semibold">
          {make} {model} 3D Model
        </h3>
        <p className="text-sm opacity-80">
          Interactive 3D View - Drag to rotate
        </p>
      </div>
      <div className="w-full h-full">
        <ModelEmbed modelUrl={modelUrl} />
      </div>
    </div>
  );
};

export default ModelViewer;