import { Heart, Box, Image as ImageIcon } from "lucide-react";
import { Link } from "wouter";
import { Vehicle } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useState } from "react";
import ModelViewer from "@/components/3d/model-viewer";
import { Button } from "@/components/ui/button";

interface VehicleCardProps {
  vehicle: Vehicle;
}

const VehicleCard = ({ vehicle }: VehicleCardProps) => {
  const [showModel, setShowModel] = useState(false);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(price);
  };

  // CSS classes that change based on sold status
  const cardClasses = cn(
    "vehicle-card bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 border-b-4 border-[#D92332]",
    {
      "opacity-75 filter grayscale": vehicle.isSold,
      "hover:shadow-xl": !vehicle.isSold
    }
  );

  const imageClasses = cn(
    "w-full h-48 object-cover",
    { "filter grayscale": vehicle.isSold }
  );
  
  const toggleView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!vehicle.isSold && vehicle.modelUrl) {
      setShowModel(!showModel);
    }
  };

  return (
    <div className={cardClasses}>
      <div className="relative">
        {showModel && vehicle.modelUrl ? (
          <div className="h-48">
            <ModelViewer 
              modelUrl={vehicle.modelUrl} 
              make={vehicle.make} 
              model={vehicle.model}
            />
          </div>
        ) : (
          <img 
            src={Array.isArray(vehicle.images) && vehicle.images.length > 0 
              ? vehicle.images[0] 
              : 'https://placehold.co/800x533?text=No+Image'} 
            alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`} 
            className={imageClasses}
          />
        )}
        
        {!vehicle.isSold && vehicle.modelUrl && (
          <Button
            variant="secondary"
            size="sm"
            className="absolute bottom-2 left-2 z-10 bg-white/70 hover:bg-white flex items-center gap-1 text-xs"
            onClick={toggleView}
          >
            {showModel ? <ImageIcon className="h-3 w-3" /> : <Box className="h-3 w-3" />}
            {showModel ? "View Photo" : "View 3D Model"}
          </Button>
        )}
        
        {vehicle.isSold && (
          <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
            <div className="bg-black text-white px-8 py-3 rotate-[-20deg] font-bold text-2xl">SOLD</div>
          </div>
        )}
        {vehicle.isNewArrival && !vehicle.isSold && (
          <div className="absolute top-3 right-3 bg-[#D92332] text-white px-3 py-1 rounded-full text-sm font-medium">
            New Arrival
          </div>
        )}
        {vehicle.isSpecialOffer && !vehicle.isSold && (
          <div className="absolute top-3 right-3 bg-[#F7B731] text-[#1A3A5F] px-3 py-1 rounded-full text-sm font-medium">
            Special Offer
          </div>
        )}
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold">
            {vehicle.year} {vehicle.make} {vehicle.model}
          </h3>
          <div className="text-[#D92332] font-bold">{formatPrice(vehicle.price)}</div>
        </div>
        <p className="text-neutral-500 text-sm mb-3">{vehicle.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {vehicle.mileage && (
            <span className="bg-neutral-100 text-neutral-600 px-2 py-1 rounded text-xs">
              <span className="mr-1">🧮</span> {vehicle.mileage.toLocaleString()} mi
            </span>
          )}
          {vehicle.fuelEconomy && (
            <span className="bg-neutral-100 text-neutral-600 px-2 py-1 rounded text-xs">
              <span className="mr-1">⛽</span> {vehicle.fuelEconomy}
            </span>
          )}
          {vehicle.transmission && (
            <span className="bg-neutral-100 text-neutral-600 px-2 py-1 rounded text-xs">
              <span className="mr-1">⚙️</span> {vehicle.transmission}
            </span>
          )}
          {vehicle.exteriorColor && (
            <span className="bg-neutral-100 text-neutral-600 px-2 py-1 rounded text-xs">
              <span className="mr-1">🎨</span> {vehicle.exteriorColor}
            </span>
          )}
        </div>
        <div className="flex justify-between">
          {!vehicle.isSold ? (
            <>
              <Link 
                href={`/inventory/${vehicle.id}`}
                className="text-[#D92332] hover:text-[#B81221] font-medium transition-colors"
              >
                View Details
              </Link>
              <button 
                className="text-[#D92332] hover:text-[#C91322]" 
                aria-label="Add to saved vehicles"
              >
                <Heart className="w-5 h-5" />
              </button>
            </>
          ) : (
            <div className="text-neutral-500 font-medium">
              Vehicle has been sold
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VehicleCard;
