import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Search, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Slider } from "@/components/ui/slider";

interface FilterProps {
  onFilter: (filters: any) => void;
}

const VehicleFilters = ({ onFilter }: FilterProps) => {
  const [location, setLocation] = useLocation();
  
  const [filters, setFilters] = useState({
    search: "",
    make: "any",
    model: "any",
    year: "any",
    minPrice: 0,
    maxPrice: 200000,
    condition: "any",
    bodyStyle: "any",
  });

  // Update filters from URL on initial load
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const urlFilters: any = {};
    
    for (const [key, value] of params.entries()) {
      urlFilters[key] = value;
    }
    
    if (Object.keys(urlFilters).length > 0) {
      setFilters(prev => ({
        ...prev,
        ...urlFilters
      }));
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePriceChange = (value: number[]) => {
    setFilters(prev => ({
      ...prev,
      minPrice: value[0],
      maxPrice: value[1]
    }));
  };

  const applyFilters = () => {
    // Create a new filter object without "any" values
    const filterParams = { ...filters } as Record<string, string | number>;
    Object.entries(filterParams).forEach(([key, value]) => {
      if (value === "any") {
        filterParams[key] = "";
      }
    });
    
    onFilter(filterParams);
    
    // Update URL with filters
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== "any" && value !== "" && value !== 0) {
        params.append(key, value.toString());
      }
    });
    
    const newUrl = `/inventory${params.toString() ? `?${params.toString()}` : ''}`;
    setLocation(newUrl);
  };

  const clearFilters = () => {
    setFilters({
      search: "",
      make: "any",
      model: "any",
      year: "any",
      minPrice: 0,
      maxPrice: 200000,
      condition: "any",
      bodyStyle: "any",
    });
    
    onFilter({});
    setLocation('/inventory');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <Filter className="mr-2 w-5 h-5" /> Search Filters
      </h2>
      
      <div className="mb-6">
        <div className="relative">
          <Input
            type="search"
            placeholder="Search by make, model, or features..."
            name="search"
            value={filters.search}
            onChange={handleInputChange}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        </div>
      </div>
      
      <Accordion type="single" collapsible defaultValue="item-1">
        <AccordionItem value="item-1">
          <AccordionTrigger>Vehicle Details</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label htmlFor="make">Make</Label>
                  <Select 
                    value={filters.make} 
                    onValueChange={(value) => handleSelectChange("make", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Any Make" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Make</SelectItem>
                      <SelectItem value="Audi">Audi</SelectItem>
                      <SelectItem value="BMW">BMW</SelectItem>
                      <SelectItem value="Lexus">Lexus</SelectItem>
                      <SelectItem value="Mercedes-Benz">Mercedes-Benz</SelectItem>
                      <SelectItem value="Porsche">Porsche</SelectItem>
                      <SelectItem value="Tesla">Tesla</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="model">Model</Label>
                  <Select 
                    value={filters.model} 
                    onValueChange={(value) => handleSelectChange("model", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Any Model" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Model</SelectItem>
                      <SelectItem value="5 Series">5 Series</SelectItem>
                      <SelectItem value="911 Carrera">911 Carrera</SelectItem>
                      <SelectItem value="Model Y">Model Y</SelectItem>
                      <SelectItem value="Q5">Q5</SelectItem>
                      <SelectItem value="RX 350">RX 350</SelectItem>
                      <SelectItem value="S-Class">S-Class</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Select 
                    value={filters.year} 
                    onValueChange={(value) => handleSelectChange("year", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Any Year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any Year</SelectItem>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2022">2022</SelectItem>
                      <SelectItem value="2021">2021</SelectItem>
                      <SelectItem value="2020">2020</SelectItem>
                      <SelectItem value="2019">2019</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-2">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <span>${filters.minPrice.toLocaleString()}</span>
                  <span>${filters.maxPrice.toLocaleString()}</span>
                </div>
                <Slider
                  defaultValue={[filters.minPrice, filters.maxPrice]}
                  max={200000}
                  step={5000}
                  value={[filters.minPrice, filters.maxPrice]}
                  onValueChange={handlePriceChange}
                  className="mb-2"
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="item-3">
          <AccordionTrigger>Vehicle Type</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="condition">Condition</Label>
                <Select 
                  value={filters.condition} 
                  onValueChange={(value) => handleSelectChange("condition", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any Condition</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="used">Used</SelectItem>
                    <SelectItem value="certified">Certified Pre-Owned</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="bodyStyle">Body Style</Label>
                <Select 
                  value={filters.bodyStyle} 
                  onValueChange={(value) => handleSelectChange("bodyStyle", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Body Style" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any Body Style</SelectItem>
                    <SelectItem value="Sedan">Sedan</SelectItem>
                    <SelectItem value="SUV">SUV</SelectItem>
                    <SelectItem value="Coupe">Coupe</SelectItem>
                    <SelectItem value="Truck">Truck</SelectItem>
                    <SelectItem value="Convertible">Convertible</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      
      <div className="mt-6 flex gap-2">
        <Button 
          onClick={applyFilters} 
          className="w-full bg-[#1A3A5F] hover:bg-[#0A2A4F]"
        >
          Apply Filters
        </Button>
        <Button 
          onClick={clearFilters} 
          variant="outline"
          className="flex-shrink-0"
        >
          Clear
        </Button>
      </div>
    </div>
  );
};

export default VehicleFilters;
