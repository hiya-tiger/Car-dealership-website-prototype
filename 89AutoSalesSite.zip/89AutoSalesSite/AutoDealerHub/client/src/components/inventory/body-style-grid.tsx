import React from 'react';
import { Button } from "@/components/ui/button";
import { 
  Car, Truck, Ship, 
  CircleOff, CarFront, Boxes, 
  Landmark
} from 'lucide-react';

interface BodyStyleGridProps {
  onSelectBodyStyle: (bodyStyle: string) => void;
  selectedStyle: string;
}

const BodyStyleGrid: React.FC<BodyStyleGridProps> = ({ 
  onSelectBodyStyle, 
  selectedStyle 
}) => {
  const bodyStyles = [
    { id: 'any', label: 'All Types', icon: CircleOff },
    { id: 'Sedan', label: 'Sedan', icon: Car },
    { id: 'SUV', label: 'SUV', icon: Landmark },
    { id: 'Coupe', label: 'Coupe', icon: CarFront },
    { id: 'Truck', label: 'Truck', icon: Truck },
    { id: 'Convertible', label: 'Convertible', icon: Ship },
    { id: 'Other', label: 'Other', icon: Boxes },
  ];

  return (
    <div className="mb-8">
      <h3 className="text-lg font-medium mb-4">Browse by Body Style</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-2">
        {bodyStyles.map((style) => {
          const Icon = style.icon;
          const isActive = selectedStyle === style.id;
          
          return (
            <Button
              key={style.id}
              variant={isActive ? "default" : "outline"}
              className={`flex flex-col items-center justify-center h-24 p-2 ${
                isActive 
                  ? "bg-[#D92332] hover:bg-[#B81221] text-white border-0" 
                  : "hover:border-[#D92332] hover:text-[#D92332]"
              }`}
              onClick={() => onSelectBodyStyle(style.id)}
            >
              <Icon className={`h-8 w-8 mb-2 ${isActive ? "text-white" : ""}`} />
              <span className="text-xs text-center">{style.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
};

export default BodyStyleGrid;