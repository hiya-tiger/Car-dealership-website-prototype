import { Router, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/query";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/ui/theme-provider";

// Layout components
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";

// Pages
import Home from "@/pages/home";
import Inventory from "@/pages/inventory";
import VehicleDetail from "@/pages/vehicle-detail";
import Contact from "@/pages/contact";
import About from "@/pages/about";
import Financing from "@/pages/financing";
import FinanceCalculator from "@/pages/finance-calculator";
import TradeIn from "@/pages/trade-in";
import Service from "@/pages/service";
import Location from "@/pages/location";
import CreditApplication from "@/pages/credit-application";
import BuyerIndex from "@/pages/buyer-index";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import VirtualShowroom from "@/pages/virtual-showroom";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Router>
          <Route path="/" component={Home} />
          <Route path="/inventory" component={Inventory} />
          <Route path="/inventory/:id" component={VehicleDetail} />
          <Route path="/contact" component={Contact} />
          <Route path="/about" component={About} />
          <Route path="/financing" component={Financing} />
          <Route path="/finance-calculator" component={FinanceCalculator} />
          <Route path="/trade-in" component={TradeIn} />
          <Route path="/service" component={Service} />
          <Route path="/location" component={Location} />
          <Route path="/credit-application" component={CreditApplication} />
          <Route path="/buyer-index" component={BuyerIndex} />
          <Route path="/privacy-policy" component={PrivacyPolicy} />
          <Route path="/terms-of-service" component={TermsOfService} />
          <Route path="/virtual-showroom" component={VirtualShowroom} />
          <Route component={NotFound} />
        </Router>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <Router />
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
