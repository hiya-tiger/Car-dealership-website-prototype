import { Separator } from "@/components/ui/separator";
import { useEffect } from "react";

const TermsOfService = () => {
  useEffect(() => {
    document.title = "Terms of Service | 89 Auto Sales";
  }, []);
  
  return (
    <div className="bg-white">
      
      {/* Header Banner */}
      <div className="bg-black py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-white text-center">Terms of Service</h1>
          <p className="text-neutral-400 text-center mt-4">Our dealership policies and legal agreements</p>
        </div>
      </div>
      
      {/* Content Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-sm p-8">
            <h2 className="text-2xl font-bold mb-6">Terms of Service for 89 Auto Sales</h2>
            <p className="text-neutral-700 mb-4">Last Updated: March 29, 2025</p>
            
            <p className="text-neutral-700 mb-6">
              Please read these Terms of Service ("Terms") carefully before using the 89 Auto Sales website or purchasing any vehicles or services from our dealership. These Terms constitute a legal agreement between you and 89 Auto Sales.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Acceptance of Terms</h3>
            <p className="text-neutral-700 mb-6">
              By accessing our website, visiting our dealership, or purchasing our products and services, you agree to be bound by these Terms. If you do not agree to these Terms, please do not use our services.
            </p>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Website Usage</h3>
            <p className="text-neutral-700 mb-4">
              Our website is provided on an "as is" and "as available" basis. You agree to use the website at your own risk.
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>
                <strong>Accuracy of Information:</strong> While we strive to provide accurate and up-to-date information, we do not warrant that product descriptions, pricing, availability, or other content on our website is complete, reliable, or error-free.
              </li>
              <li>
                <strong>Vehicle Listings:</strong> All vehicle listings are subject to prior sale. Pricing, specifications, and availability may change without notice. Images may not represent the actual vehicle for sale.
              </li>
              <li>
                <strong>Intellectual Property:</strong> All content on our website, including text, graphics, logos, images, and software, is the property of 89 Auto Sales or its content suppliers and is protected by copyright and other intellectual property laws.
              </li>
            </ul>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Vehicle Purchase Terms</h3>
            <p className="text-neutral-700 mb-4">
              When purchasing a vehicle from 89 Auto Sales:
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>
                <strong>Pricing and Payments:</strong> All prices are in US dollars and do not include applicable taxes, title, registration, or documentation fees unless specifically stated. Payment methods accepted include cash, certified checks, bank transfers, and financing through approved lenders.
              </li>
              <li>
                <strong>Vehicle Condition:</strong> Used vehicles are sold "as is" unless otherwise specified in a written agreement. New vehicles are covered by the manufacturer's warranty.
              </li>
              <li>
                <strong>Deposits:</strong> Deposits to hold vehicles are non-refundable unless otherwise specified in writing.
              </li>
              <li>
                <strong>Documentation:</strong> You are responsible for providing valid identification and completing all required paperwork for vehicle purchase and registration.
              </li>
            </ul>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Financing Applications</h3>
            <p className="text-neutral-700 mb-6">
              When applying for financing through our dealership, you authorize us to submit your information to potential lenders. Approval of financing is subject to credit review and lender requirements. Interest rates, term lengths, and approval decisions are at the sole discretion of the lenders.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Service and Repairs</h3>
            <p className="text-neutral-700 mb-4">
              For service and repair work:
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>Service estimates are provided based on initially diagnosed issues. Additional costs may be incurred if additional problems are discovered during service.</li>
              <li>Parts installed by our service department may be covered by a limited warranty as specified at the time of service.</li>
              <li>We are not responsible for personal items left in vehicles during service appointments.</li>
            </ul>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Limitation of Liability</h3>
            <p className="text-neutral-700 mb-6">
              To the fullest extent permitted by law, 89 Auto Sales shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to, loss of profits, data, use, or goodwill, arising out of or in connection with your use of our website or services, even if we have been advised of the possibility of such damages.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Indemnification</h3>
            <p className="text-neutral-700 mb-6">
              You agree to indemnify and hold harmless 89 Auto Sales and its employees, officers, directors, and agents from and against any claims, liabilities, damages, losses, and expenses, including reasonable attorneys' fees, arising out of or in any way connected with your access to or use of our services or your violation of these Terms.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Governing Law</h3>
            <p className="text-neutral-700 mb-6">
              These Terms shall be governed by and construed in accordance with the laws of the State of North Carolina, without regard to its conflict of law provisions. Any legal action or proceeding relating to your access to or use of our services shall be brought exclusively in the state or federal courts located in Mecklenburg County, North Carolina.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Changes to These Terms</h3>
            <p className="text-neutral-700 mb-6">
              We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting on our website. Your continued use of our services after any such changes constitutes your acceptance of the new Terms.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Contact Information</h3>
            <p className="text-neutral-700 mb-6">
              If you have any questions about these Terms, please contact us at:
            </p>
            <div className="text-neutral-700">
              <p>89 Auto Sales</p>
              <p>890 Speedway Blvd</p>
              <p>Charlotte, NC 28216</p>
              <p>Email: legal@89autosales.com</p>
              <p>Phone: (704) 555-8989</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;