import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import VehicleCard from "@/components/inventory/vehicle-card";
import VehicleFilters from "@/components/inventory/vehicle-filters";
import BodyStyleGrid from "@/components/inventory/body-style-grid";
import { Vehicle } from "@shared/schema";
import { Loader2 } from "lucide-react";

const Inventory = () => {
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>([]);
  const [filters, setFilters] = useState({});
  const [selectedBodyStyle, setSelectedBodyStyle] = useState("any");

  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/vehicles'],
  });

  // Apply filters when data or filters change
  useEffect(() => {
    if (data?.vehicles) {
      applyFilters(filters);
    }
  }, [data, filters]);

  // Filter function
  const applyFilters = (filterOptions: any) => {
    if (!data?.vehicles) return;

    let filtered = [...data.vehicles];

    // Filter based on search term (make, model, description)
    if (filterOptions.search) {
      const searchLower = filterOptions.search.toLowerCase();
      filtered = filtered.filter(vehicle => 
        vehicle.make.toLowerCase().includes(searchLower) ||
        vehicle.model.toLowerCase().includes(searchLower) ||
        (vehicle.description && vehicle.description.toLowerCase().includes(searchLower)) ||
        (vehicle.features && vehicle.features.some(feature => 
          feature.toLowerCase().includes(searchLower)
        ))
      );
    }

    // Filter by make
    if (filterOptions.make && filterOptions.make !== "any") {
      filtered = filtered.filter(vehicle => 
        vehicle.make.toLowerCase() === filterOptions.make.toLowerCase()
      );
    }

    // Filter by model
    if (filterOptions.model && filterOptions.model !== "any") {
      filtered = filtered.filter(vehicle => 
        vehicle.model.toLowerCase() === filterOptions.model.toLowerCase()
      );
    }

    // Filter by year
    if (filterOptions.year && filterOptions.year !== "any") {
      filtered = filtered.filter(vehicle => 
        vehicle.year === parseInt(filterOptions.year)
      );
    }

    // Filter by price range
    if (filterOptions.minPrice || filterOptions.maxPrice) {
      const minPrice = filterOptions.minPrice || 0;
      const maxPrice = filterOptions.maxPrice || Number.MAX_SAFE_INTEGER;
      
      filtered = filtered.filter(vehicle => 
        vehicle.price >= minPrice && vehicle.price <= maxPrice
      );
    }

    // Filter by condition
    if (filterOptions.condition && filterOptions.condition !== "any") {
      filtered = filtered.filter(vehicle => 
        vehicle.condition === filterOptions.condition
      );
    }

    // Filter by body style
    if (filterOptions.bodyStyle && filterOptions.bodyStyle !== "any") {
      filtered = filtered.filter(vehicle => 
        vehicle.bodyStyle === filterOptions.bodyStyle
      );
    }

    setFilteredVehicles(filtered);
  };

  const handleFilterChange = (newFilters: any) => {
    setFilters({ ...newFilters, bodyStyle: selectedBodyStyle !== "any" ? selectedBodyStyle : undefined });
  };
  
  const handleBodyStyleSelect = (style: string) => {
    setSelectedBodyStyle(style);
    setFilters({ ...filters, bodyStyle: style !== "any" ? style : undefined });
  };

  if (isLoading) {
    return (
      <div className="py-16 container mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Vehicle Inventory</h1>
          <p className="text-neutral-600">Loading our inventory...</p>
        </div>
        <div className="flex justify-center mt-10">
          <Loader2 className="w-12 h-12 animate-spin text-[#D92332]" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="py-16 container mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Vehicle Inventory</h1>
          <p className="text-red-600">
            Unable to load inventory. Please try again later.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Vehicle Inventory</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Explore our extensive collection of premium vehicles. Use the filters to find the perfect match for your needs.
          </p>
        </div>

        {/* Body Style Grid */}
        <div className="mb-8 bg-white p-6 rounded-lg shadow">
          <BodyStyleGrid 
            onSelectBodyStyle={handleBodyStyleSelect} 
            selectedStyle={selectedBodyStyle} 
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <VehicleFilters onFilter={handleFilterChange} />
          </div>
          
          <div className="lg:col-span-3">
            {filteredVehicles.length === 0 ? (
              <div className="bg-white p-8 rounded-lg shadow text-center">
                <h3 className="text-xl font-medium mb-2">No Vehicles Found</h3>
                <p className="text-neutral-600 mb-4">
                  We couldn't find any vehicles matching your criteria. Please try adjusting your filters.
                </p>
              </div>
            ) : (
              <>
                <div className="mb-4 bg-white p-4 rounded-lg shadow">
                  <p className="text-neutral-600">
                    <span className="font-medium">{filteredVehicles.length}</span> vehicles found
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredVehicles.map((vehicle) => (
                    <VehicleCard key={vehicle.id} vehicle={vehicle} />
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
