import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronRight } from "lucide-react";
import { Link } from "wouter";

const VirtualShowroom = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <header className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Virtual Showroom</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Explore our inventory from the comfort of your home with our interactive virtual showroom
          </p>
        </header>

        <Tabs defaultValue="featured" className="mb-12">
          <div className="flex justify-center mb-8">
            <TabsList>
              <TabsTrigger value="featured">Featured Vehicles</TabsTrigger>
              <TabsTrigger value="new">New Arrivals</TabsTrigger>
              <TabsTrigger value="popular">Most Popular</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="featured" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Virtual Tour Cards - Featured */}
              <VirtualTourCard 
                title="2023 Chevrolet Corvette Z06"
                description="Experience the thrill of America's supercar with our immersive 360° tour"
                imageUrl="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
              <VirtualTourCard 
                title="2023 Ford F-150 Raptor"
                description="Explore every detail of this off-road performance truck in our virtual tour"
                imageUrl="https://images.unsplash.com/photo-1605893477799-b99e3b8b93fe?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
              <VirtualTourCard 
                title="2023 Dodge Challenger SRT"
                description="Take a virtual walk around this modern muscle car with our interactive tour"
                imageUrl="https://images.unsplash.com/photo-1612544448445-b8232cff3b6a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
            </div>
          </TabsContent>
          
          <TabsContent value="new" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Virtual Tour Cards - New Arrivals */}
              <VirtualTourCard 
                title="2024 Toyota Supra"
                description="Be among the first to explore our newest sports car addition"
                imageUrl="https://images.unsplash.com/photo-1626668893632-6f3a4466d109?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
              <VirtualTourCard 
                title="2024 Chevrolet Silverado ZR2"
                description="Check out this rugged off-road truck with our detailed virtual tour"
                imageUrl="https://images.unsplash.com/photo-1616455263449-0bd3aac04029?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
              <VirtualTourCard 
                title="2024 Ford Mustang GT"
                description="Experience the latest generation of America's iconic pony car"
                imageUrl="https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
            </div>
          </TabsContent>
          
          <TabsContent value="popular" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Virtual Tour Cards - Most Popular */}
              <VirtualTourCard 
                title="2023 Jeep Wrangler Rubicon"
                description="Our most viewed virtual tour - see why this off-road icon is so popular"
                imageUrl="https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
              <VirtualTourCard 
                title="2023 Ram 1500 TRX"
                description="Experience the 702-hp supercharged truck that's capturing everyone's attention"
                imageUrl="https://images.unsplash.com/photo-1599256872237-5dcc0fbe9668?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
              <VirtualTourCard 
                title="2023 Chevrolet Camaro ZL1"
                description="Take a virtual tour of this track-ready American performance machine"
                imageUrl="https://images.unsplash.com/photo-1603553329474-99f95f35394f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80"
              />
            </div>
          </TabsContent>
        </Tabs>

        <div className="bg-white p-8 rounded-lg shadow-md mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">How Our Virtual Showroom Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-[#1A3A5F] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-xl font-bold">1</span>
              </div>
              <h3 className="font-bold mb-2">Select a Vehicle</h3>
              <p className="text-neutral-600">Choose from our featured vehicles or browse our complete inventory</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[#1A3A5F] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-xl font-bold">2</span>
              </div>
              <h3 className="font-bold mb-2">Explore in 360°</h3>
              <p className="text-neutral-600">Use your mouse or touch screen to rotate and view the vehicle from all angles</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[#1A3A5F] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-xl font-bold">3</span>
              </div>
              <h3 className="font-bold mb-2">Schedule a Test Drive</h3>
              <p className="text-neutral-600">Found your perfect match? Book a test drive or contact our sales team</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1A3A5F] text-white p-8 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Ready for the Real Experience?</h2>
            <p className="max-w-3xl mx-auto mb-6">
              While our virtual showroom offers an immersive experience, nothing compares to seeing these vehicles in person. Visit our dealership or schedule a test drive today.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/contact">
                <Button variant="secondary" className="w-full sm:w-auto">Contact Us</Button>
              </Link>
              <Link to="/inventory">
                <Button className="w-full sm:w-auto">Browse All Inventory</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Virtual Tour Card Component
const VirtualTourCard = ({ title, description, imageUrl }: { title: string, description: string, imageUrl: string }) => {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg">
      <div className="relative">
        <div className="relative pb-[56.25%] w-full">
          <img 
            src={imageUrl} 
            alt={`${title} - 360° Virtual Tour`} 
            className="object-cover absolute inset-0 w-full h-full"
            loading="lazy"
            decoding="async"
          />
        </div>
        <div className="absolute top-4 right-4 bg-[#D92332] text-white text-xs font-bold px-2 py-1 rounded">
          360° TOUR
        </div>
      </div>
      <CardContent className="p-6">
        <h3 className="font-bold text-lg mb-2">{title}</h3>
        <p className="text-neutral-600 mb-4">{description}</p>
        <Link to={`/inventory/${title.toLowerCase().replace(/\s+/g, '-')}`}>
          <Button variant="outline" className="w-full">
            Start Virtual Tour <ChevronRight className="ml-1 w-4 h-4" aria-hidden="true" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
};

export default VirtualShowroom;