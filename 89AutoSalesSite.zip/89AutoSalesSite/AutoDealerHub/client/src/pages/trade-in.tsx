import TradeInForm from "@/components/forms/trade-in-form";
import { Card, CardContent } from "@/components/ui/card";
import { BadgeCheck } from "lucide-react";

const TradeIn = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Value Your Trade-In</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Get a competitive offer for your current vehicle in minutes
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-bold mb-6">Submit Your Vehicle Information</h2>
            <Card>
              <CardContent className="pt-6">
                <TradeInForm />
              </CardContent>
            </Card>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">How It Works</h2>
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#1A3A5F] text-white flex items-center justify-center mr-4">
                      1
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Submit Your Vehicle Details</h3>
                      <p className="text-neutral-600">
                        Fill out the form with accurate information about your vehicle's make, model, year, condition, and features.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#1A3A5F] text-white flex items-center justify-center mr-4">
                      2
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Receive an Initial Estimate</h3>
                      <p className="text-neutral-600">
                        Our team will review your information and provide an initial trade-in value estimate based on current market conditions.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#1A3A5F] text-white flex items-center justify-center mr-4">
                      3
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Schedule an Inspection</h3>
                      <p className="text-neutral-600">
                        Bring your vehicle to our dealership for a thorough inspection to confirm its condition and finalize the offer.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#1A3A5F] text-white flex items-center justify-center mr-4">
                      4
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Get Your Offer</h3>
                      <p className="text-neutral-600">
                        Receive your final trade-in offer, which you can apply toward your next vehicle purchase or take as cash.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <h2 className="text-2xl font-bold mb-6">Why Trade With Us</h2>
            <Card>
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Competitive, market-based valuations</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Transparent appraisal process</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>No obligation to purchase</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>We accept vehicles in any condition</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Potential tax advantages when trading in</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Simplified process - we handle the paperwork</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-center mb-6">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-bold mb-2">What factors affect my trade-in value?</h3>
              <p className="text-neutral-600 mb-4">
                Vehicle make/model, year, mileage, condition, service history, market demand, and regional factors all influence your trade-in value.
              </p>
              
              <h3 className="font-bold mb-2">Do I need an appointment for an appraisal?</h3>
              <p className="text-neutral-600 mb-4">
                While walk-ins are welcome, scheduling an appointment ensures that our appraisal specialists will be available to give your vehicle their full attention.
              </p>
              
              <h3 className="font-bold mb-2">What documents should I bring?</h3>
              <p className="text-neutral-600">
                Please bring your vehicle title or payoff information, registration, all keys/remotes, service records, and your driver's license.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold mb-2">Can I trade in a vehicle I still owe money on?</h3>
              <p className="text-neutral-600 mb-4">
                Yes. If your trade-in value exceeds what you owe, the difference can be applied to your new purchase. If you owe more than the trade-in value, the remaining balance can be rolled into your new financing.
              </p>
              
              <h3 className="font-bold mb-2">How long is my trade-in offer valid?</h3>
              <p className="text-neutral-600 mb-4">
                Typically, our trade-in offers are valid for 7 days, subject to no changes in the vehicle's condition.
              </p>
              
              <h3 className="font-bold mb-2">Do I have to buy a car to trade in my vehicle?</h3>
              <p className="text-neutral-600">
                No. While many customers apply their trade-in value to a new purchase, you can sell us your vehicle without buying one from us.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TradeIn;
