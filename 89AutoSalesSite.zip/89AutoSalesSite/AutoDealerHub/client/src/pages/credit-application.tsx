import CreditApplicationForm from "@/components/forms/credit-application";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, BadgeCheck } from "lucide-react";

const CreditApplication = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Credit Application</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Take the first step toward financing your dream vehicle
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="md:col-span-2">
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-2xl font-bold mb-6">Secure Online Application</h2>
                <CreditApplicationForm />
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Shield className="w-8 h-8 text-[#1A3A5F] mr-3" />
                  <h2 className="text-xl font-bold">Secure & Confidential</h2>
                </div>
                <p className="text-neutral-600 mb-4">
                  Your information is protected with industry-standard encryption. We follow strict privacy protocols to ensure your personal and financial information remains secure.
                </p>
                <div className="flex items-center text-sm text-[#1A3A5F]">
                  <BadgeCheck className="w-4 h-4 mr-1" />
                  <span>256-bit SSL encryption</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold text-lg mb-4">What to Expect</h3>
                <ol className="space-y-3 list-decimal list-inside text-neutral-600">
                  <li>Submit your application</li>
                  <li>Receive a response within 24 hours</li>
                  <li>Review your financing options</li>
                  <li>Choose your vehicle</li>
                  <li>Complete the purchase process</li>
                </ol>
                <div className="border-t mt-4 pt-4">
                  <h4 className="font-medium mb-2">Required Documents</h4>
                  <ul className="space-y-1 text-neutral-600">
                    <li>Valid driver's license</li>
                    <li>Proof of income</li>
                    <li>Proof of residence</li>
                    <li>Proof of insurance</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-6">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold mb-2">Will my credit score be affected by applying?</h3>
                <p className="text-neutral-600">
                  When you submit an application, we perform a hard credit inquiry, which may temporarily impact your credit score. However, multiple auto loan inquiries within a short period (typically 14-45 days) are usually counted as a single inquiry by credit scoring models.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold mb-2">What if I have less-than-perfect credit?</h3>
                <p className="text-neutral-600">
                  We work with multiple lenders who specialize in various credit situations. Many factors beyond credit scores are considered, including income, down payment, and employment history. We strive to find financing solutions for all credit profiles.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold mb-2">How long does the approval process take?</h3>
                <p className="text-neutral-600">
                  Most applications receive a response within 24 hours. In some cases, approvals can happen within minutes. Our finance team will contact you as soon as we receive a decision from our lending partners.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold mb-2">Do I need to choose a vehicle before applying?</h3>
                <p className="text-neutral-600">
                  No, you can apply for pre-approval before selecting a specific vehicle. This helps you understand your budget and options before shopping. Once pre-approved, you can browse our inventory with confidence.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-[#1A3A5F] text-white p-8 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Need Assistance?</h2>
            <p className="max-w-3xl mx-auto mb-6">
              Our finance experts are available to answer your questions and guide you through the application process. Contact us via phone or email, or visit our dealership for personalized assistance.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a href="tel:8005551238" className="bg-white text-[#1A3A5F] px-6 py-3 rounded-md font-medium transition-colors hover:bg-neutral-100">
                Call Finance Department
              </a>
              <a href="mailto:finance@89autosales.com" className="bg-[#D92332] hover:bg-[#C91322] text-white px-6 py-3 rounded-md font-medium transition-colors">
                Email Finance Team
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreditApplication;
