import HeroCarousel from "@/components/home/hero-carousel";
import QuickLinks from "@/components/home/quick-links";
import FeaturedVehicles from "@/components/home/featured-vehicles";
import FeaturesSection from "@/components/home/features-section";
import TestimonialsSection from "@/components/home/testimonials-section";
import ContactCTA from "@/components/home/contact-cta";

const Home = () => {
  return (
    <div>
      <HeroCarousel />
      <QuickLinks />
      <FeaturedVehicles />
      <FeaturesSection />
      <TestimonialsSection />
      <ContactCTA />
    </div>
  );
};

export default Home;
