import ContactForm from "@/components/forms/contact-form";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const Contact = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Contact Us</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            We're here to help with any questions you might have. Reach out to our team using the form below or visit our dealership.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
            <Card>
              <CardContent className="pt-6">
                <ContactForm />
              </CardContent>
            </Card>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Address</h3>
                      <p className="text-neutral-600">123 Luxury Lane<br />Beverly Hills, CA 90210</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Phone</h3>
                      <p className="text-neutral-600">(800) 555-1234</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Mail className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Email</h3>
                      <p className="text-neutral-600">info@89autosales.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Clock className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Hours of Operation</h3>
                      <div className="text-neutral-600">
                        <p>Monday - Friday: 9AM - 8PM</p>
                        <p>Saturday: 10AM - 6PM</p>
                        <p>Sunday: Closed</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <h2 className="text-2xl font-bold mb-6">Departments</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium">Sales Department</h3>
                    <p className="text-neutral-600">(800) 555-1235</p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium">Service Department</h3>
                    <p className="text-neutral-600">(800) 555-1236</p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium">Parts Department</h3>
                    <p className="text-neutral-600">(800) 555-1237</p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium">Finance Department</h3>
                    <p className="text-neutral-600">(800) 555-1238</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-white rounded-lg overflow-hidden shadow-md">
          <div className="aspect-w-16 aspect-h-9">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26430.39297327055!2d-118.43177214371658!3d34.09024386555184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2bc04d6d147ab%3A0xd6c7c379fd081ed1!2sBeverly%20Hills%2C%20CA%2090210!5e0!3m2!1sen!2sus!4v1620292605810!5m2!1sen!2sus" 
              width="100%" 
              height="450" 
              style={{ border: 0 }} 
              allowFullScreen 
              loading="lazy"
              title="Dealership Location"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
