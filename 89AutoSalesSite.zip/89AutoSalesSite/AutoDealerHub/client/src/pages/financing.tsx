import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BadgeCheck, Calculator, CreditCard, FileText, HelpCircle } from "lucide-react";

const Financing = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Financing Options</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Flexible financing solutions tailored to your budget and lifestyle
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <div className="flex flex-col justify-center">
            <h2 className="text-2xl font-bold mb-4">Performance Financing Solutions</h2>
            <p className="text-neutral-600 mb-4">
              At 89 Auto Sales, we understand that financing a high-performance vehicle is a significant decision. Our finance experts work with racing enthusiasts to find the best possible terms and rates, making your dream performance car affordable.
            </p>
            <p className="text-neutral-600 mb-6">
              Whether you're looking to buy a muscle car or lease a European sports car, we offer competitive rates, flexible terms, and a quick approval process to get you behind the wheel and on the track faster.
            </p>
            <div className="space-y-2">
              <div className="flex items-center">
                <BadgeCheck className="text-[#D92332] mr-2" />
                <span>Competitive interest rates</span>
              </div>
              <div className="flex items-center">
                <BadgeCheck className="text-[#D92332] mr-2" />
                <span>Flexible terms from 24 to 84 months</span>
              </div>
              <div className="flex items-center">
                <BadgeCheck className="text-[#D92332] mr-2" />
                <span>Special programs for first-time buyers</span>
              </div>
              <div className="flex items-center">
                <BadgeCheck className="text-[#D92332] mr-2" />
                <span>Refinancing options for existing loans</span>
              </div>
            </div>
          </div>
          <div className="rounded-lg overflow-hidden shadow-md">
            <img 
              src="https://images.unsplash.com/photo-1589310243389-96a5483213a8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80" 
              alt="Financing consultation" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center mb-8">Financing Options</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CreditCard className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold">Traditional Financing</h3>
                </div>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Fixed monthly payments</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Build equity with each payment</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>No mileage restrictions</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Full ownership at the end of term</span>
                  </li>
                </ul>
                <Link href="/credit-application">
                  <a>
                    <Button className="w-full">Apply Now</Button>
                  </a>
                </Link>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <FileText className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold">Leasing</h3>
                </div>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Lower monthly payments</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Drive a new vehicle every few years</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Warranty coverage for most of lease term</span>
                  </li>
                  <li className="flex items-start">
                    <BadgeCheck className="text-[#D92332] mr-2 mt-1 flex-shrink-0" />
                    <span>Option to purchase at end of lease</span>
                  </li>
                </ul>
                <Link href="/credit-application">
                  <a>
                    <Button className="w-full">Learn More</Button>
                  </a>
                </Link>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Calculator className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold">Payment Calculator</h3>
                </div>
                <p className="text-neutral-600 mb-6">
                  Estimate your monthly payments based on vehicle price, down payment, trade-in value, and interest rate.
                </p>
                <Link href="/finance-calculator">
                  <a>
                    <Button className="w-full">Calculate Payment</Button>
                  </a>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-[#1A3A5F] text-white p-8 rounded-lg shadow-md">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl font-bold mb-4">Have Questions?</h2>
              <p className="mb-6">
                Our finance team is here to answer any questions you might have about financing or leasing a vehicle. We're committed to making the process transparent and straightforward.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/contact">
                  <a>
                    <Button variant="secondary">Contact Finance Team</Button>
                  </a>
                </Link>
                <Link href="/service">
                  <a>
                    <Button className="bg-[#D92332] hover:bg-[#C91322] text-white">
                      Schedule Consultation
                    </Button>
                  </a>
                </Link>
              </div>
            </div>
            <div className="flex justify-center">
              <HelpCircle className="w-32 h-32 text-white/20" />
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto mb-6">
            Take the first step toward driving your dream car. Apply for financing today and one of our finance experts will contact you to discuss your options.
          </p>
          <Link href="/credit-application">
            <a>
              <Button size="lg" className="bg-[#1A3A5F] hover:bg-[#0A2A4F]">
                Apply for Credit
              </Button>
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Financing;
