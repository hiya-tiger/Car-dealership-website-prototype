import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { 
  Calendar, Clock, Check, Fuel, Gauge, Car, Users, Award, FileText, Box,
  Maximize2, X, ChevronLeft, ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils";
import { Vehicle } from "@shared/schema";
import { Spinner } from "@/components/ui/spinner";
import ModelViewer from "@/components/3d/model-viewer";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const VehicleDetail = () => {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/inventory/:id");
  const vehicleId = params?.id ? parseInt(params.id) : undefined;
  
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/vehicles', vehicleId],
    queryFn: async () => {
      const res = await fetch(`/api/vehicles/${vehicleId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch vehicle');
      }
      return res.json();
    },
    enabled: !!vehicleId,
  });
  
  const vehicle: Vehicle | undefined = data?.vehicle;
  
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showModel, setShowModel] = useState(false);
  const [fullscreenView, setFullscreenView] = useState(false);
  const [fullscreenImageIndex, setFullscreenImageIndex] = useState(0);

  // Redirect to inventory page if vehicle is sold
  useEffect(() => {
    if (vehicle?.isSold) {
      setLocation("/inventory");
    }
  }, [vehicle, setLocation]);
  
  useEffect(() => {
    if (vehicle?.images && vehicle.images.length > 0) {
      const timer = setInterval(() => {
        setActiveImageIndex((prev) => 
          prev === vehicle.images.length - 1 ? 0 : prev + 1
        );
      }, 5000);
      
      return () => clearInterval(timer);
    }
  }, [vehicle]);
  
  const handlePrevImage = () => {
    if (!vehicle?.images) return;
    setActiveImageIndex((prev) => 
      prev === 0 ? vehicle.images.length - 1 : prev - 1
    );
  };
  
  const handleNextImage = () => {
    if (!vehicle?.images) return;
    setActiveImageIndex((prev) => 
      prev === vehicle.images.length - 1 ? 0 : prev + 1
    );
  };
  
  const handleContactClick = () => {
    setLocation("/contact");
  };
  
  const openFullscreenView = (index: number) => {
    if (vehicle?.images && vehicle.images.length > 0) {
      setFullscreenImageIndex(index);
      setFullscreenView(true);
    }
  };
  
  if (isLoading) {
    return (
      <div className="py-16 container mx-auto px-4">
        <div className="flex justify-center items-center min-h-[60vh]">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-8 w-64 bg-gray-200 rounded mb-4"></div>
            <div className="h-4 w-40 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !vehicle) {
    return (
      <div className="py-16 container mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Vehicle Not Found</h1>
          <p className="text-neutral-600 mb-6">
            Sorry, we couldn't find the vehicle you're looking for.
          </p>
          <Button onClick={() => setLocation("/inventory")}>
            Return to Inventory
          </Button>
        </div>
      </div>
    );
  }
  
  // CarFax data (in a real app, this would come from the CarFax API)
  const carfaxData = {
    reportDate: new Date().toLocaleDateString(),
    vinNumber: vehicle.vin || "VIN12345678901234",
    noAccidents: true,
    oneOwner: vehicle.year > 2020,
    serviceRecords: Math.floor(Math.random() * 10) + 1,
    recallsReported: false,
    mileageConsistent: true,
    structureDamage: false
  };
  
  return (
    <div className="bg-neutral-100 py-16">
      {/* Fullscreen Image Viewer */}
      {vehicle?.images && vehicle.images.length > 0 && (
        <FullscreenImageViewer
          images={vehicle.images}
          activeIndex={fullscreenImageIndex}
          isOpen={fullscreenView}
          onClose={() => setFullscreenView(false)}
          title={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
        />
      )}
      
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <Button 
            variant="ghost" 
            className="mb-4"
            onClick={() => setLocation("/inventory")}
          >
            ← Back to Inventory
          </Button>
          
          <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
              <h1 className="text-3xl font-bold">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </h1>
              <p className="text-xl text-neutral-600">{vehicle.model} {vehicle.condition}</p>
            </div>
            <div className="text-3xl font-bold text-[#D92332]">
              {formatCurrency(vehicle.price)}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Vehicle Images and 3D Model */}
            <div className="bg-white rounded-lg shadow mb-8 overflow-hidden">
              <div className="relative">
                <div className="aspect-video bg-neutral-200">
                  {showModel && vehicle.modelUrl ? (
                    <ModelViewer 
                      modelUrl={vehicle.modelUrl} 
                      make={vehicle.make} 
                      model={vehicle.model}
                      isFullscreen={true}
                    />
                  ) : vehicle.images && vehicle.images.length > 0 ? (
                    <div 
                      onClick={() => openFullscreenView(activeImageIndex)}
                      className="w-full h-full cursor-pointer relative"
                    >
                      <img 
                        src={vehicle.images[activeImageIndex]} 
                        alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`} 
                        className="w-full h-full object-cover"
                      />
                      <Button
                        variant="secondary"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          openFullscreenView(activeImageIndex);
                        }}
                        className="absolute bottom-4 right-4 z-10 bg-white/70 hover:bg-white"
                      >
                        <Maximize2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Car className="w-20 h-20 text-neutral-400" />
                    </div>
                  )}
                </div>
                
                {!showModel && vehicle.images && vehicle.images.length > 1 && (
                  <>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                      onClick={handlePrevImage}
                    >
                      ←
                    </Button>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                      onClick={handleNextImage}
                    >
                      →
                    </Button>
                  </>
                )}
                
                <Badge className="absolute top-4 left-4 bg-[#D92332]">
                  {vehicle.condition}
                </Badge>

                {vehicle.modelUrl && (
                  <Button
                    variant="secondary"
                    className="absolute top-4 right-4 z-10 bg-white/70 hover:bg-white flex items-center gap-2"
                    onClick={() => setShowModel(!showModel)}
                  >
                    {showModel ? (
                      <>
                        <img src="/assets/camera.svg" alt="Camera" className="w-4 h-4" />
                        View Photos
                      </>
                    ) : (
                      <>
                        <Box className="w-4 h-4" />
                        View 3D Model
                      </>
                    )}
                  </Button>
                )}
              </div>
              
              {!showModel && vehicle.images && vehicle.images.length > 1 && (
                <div className="p-4 grid grid-cols-5 sm:grid-cols-7 md:grid-cols-8 gap-2">
                  {vehicle.images.map((img, index) => (
                    <div 
                      key={index}
                      className={`cursor-pointer flex-shrink-0 w-full h-16 rounded overflow-hidden ${
                        index === activeImageIndex ? "ring-2 ring-[#D92332]" : "opacity-70"
                      }`}
                      onClick={() => setActiveImageIndex(index)}
                    >
                      <img 
                        src={img} 
                        alt={`Thumbnail ${index + 1}`} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Vehicle Details Tabs */}
            <Tabs defaultValue="overview" className="mb-8">
              <TabsList className="grid grid-cols-3 mb-8">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="specs">Specifications</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold mb-4">Vehicle Overview</h2>
                <p className="text-neutral-700 mb-4">
                  {vehicle.description || `This ${vehicle.year} ${vehicle.make} ${vehicle.model} is in excellent ${vehicle.condition || 'good'} condition with ${vehicle.mileage ? `only ${vehicle.mileage.toLocaleString()} miles` : 'low mileage'}. ${vehicle.exteriorColor ? `It features a ${vehicle.exteriorColor} exterior` : ''} ${vehicle.interiorColor ? `with a ${vehicle.interiorColor} interior.` : ''}`}
                </p>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 mt-8">
                  <div className="flex items-center">
                    <Gauge className="w-5 h-5 mr-2 text-[#D92332]" />
                    <div>
                      <p className="font-medium">Mileage</p>
                      <p className="text-neutral-600">{vehicle.mileage ? `${vehicle.mileage.toLocaleString()} miles` : 'Contact for mileage'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Fuel className="w-5 h-5 mr-2 text-[#D92332]" />
                    <div>
                      <p className="font-medium">Fuel Economy</p>
                      <p className="text-neutral-600">{vehicle.fuelEconomy || "Gasoline"}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-[#D92332]" />
                    <div>
                      <p className="font-medium">Year</p>
                      <p className="text-neutral-600">{vehicle.year}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Car className="w-5 h-5 mr-2 text-[#D92332]" />
                    <div>
                      <p className="font-medium">Body Style</p>
                      <p className="text-neutral-600">{vehicle.bodyStyle}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 mr-2 text-[#D92332]" />
                    <div>
                      <p className="font-medium">Transmission</p>
                      <p className="text-neutral-600">{vehicle.transmission || "Automatic"}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Users className="w-5 h-5 mr-2 text-[#D92332]" />
                    <div>
                      <p className="font-medium">Condition</p>
                      <p className="text-neutral-600">{vehicle.condition}</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="features" className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold mb-4">Features & Options</h2>
                
                {vehicle.features && vehicle.features.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {vehicle.features.map((feature, index) => (
                      <div key={index} className="flex items-center">
                        <Check className="w-4 h-4 mr-2 text-[#D92332]" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-neutral-600">Feature information not available.</p>
                )}
              </TabsContent>
              
              <TabsContent value="specs" className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold mb-4">Specifications</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-8">
                  <div>
                    <h3 className="font-medium mb-2">Engine</h3>
                    <p className="text-neutral-600 mb-1">
                      {vehicle.engine || `${vehicle.year >= 2020 ? '2.0L Turbo 4-Cylinder' : '3.5L V6'}`}
                    </p>
                    <p className="text-neutral-600 mb-1">
                      Horsepower: {vehicle.horsepower || "180-250 hp"}
                    </p>
                    <p className="text-neutral-600">
                      Torque: {vehicle.torque || "170-230 lb-ft"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">Dimensions</h3>
                    <p className="text-neutral-600 mb-1">
                      Length: {vehicle.length || "180-195 inches"}
                    </p>
                    <p className="text-neutral-600 mb-1">
                      Width: {vehicle.width || "70-80 inches"}
                    </p>
                    <p className="text-neutral-600">
                      Height: {vehicle.height || "55-70 inches"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">Performance</h3>
                    <p className="text-neutral-600 mb-1">
                      0-60 mph: {vehicle.acceleration || "6.5-8.0 seconds"}
                    </p>
                    <p className="text-neutral-600 mb-1">
                      Top Speed: {vehicle.topSpeed || "120-140 mph"}
                    </p>
                    <p className="text-neutral-600">
                      Fuel Economy: {vehicle.mpg || "22-32 mpg combined"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">Capacity</h3>
                    <p className="text-neutral-600 mb-1">
                      Seating: {vehicle.seating || "5 passengers"}
                    </p>
                    <p className="text-neutral-600 mb-1">
                      Cargo Volume: {vehicle.cargoVolume || "15-30 cubic feet"}
                    </p>
                    <p className="text-neutral-600">
                      Fuel Tank: {vehicle.fuelTank || "15-18 gallons"}
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            {/* CarFax Section */}
            <div className="bg-white rounded-lg shadow p-6 mb-8">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <FileText className="w-6 h-6 mr-2 text-[#D92332]" />
                  <h2 className="text-xl font-semibold">CarFax Vehicle History Report</h2>
                </div>
                <img 
                  src="https://www.carfax.com/assets/logo_carfax.svg" 
                  alt="CARFAX" 
                  className="h-8"
                />
              </div>
              
              <Separator className="my-4" />
              
              <div className="mb-4">
                <p className="text-sm text-neutral-500">Report Date: {carfaxData.reportDate}</p>
                <p className="text-sm text-neutral-500">VIN: {carfaxData.vinNumber}</p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${carfaxData.noAccidents ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'} mr-3`}>
                        {carfaxData.noAccidents ? <Check className="w-5 h-5" /> : '!'}
                      </div>
                      <div>
                        <h3 className="font-semibold">Accident History</h3>
                        <p className="text-sm text-neutral-600">
                          {carfaxData.noAccidents ? 'No accidents reported' : 'Accidents reported'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${carfaxData.oneOwner ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'} mr-3`}>
                        <Users className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Ownership</h3>
                        <p className="text-sm text-neutral-600">
                          {carfaxData.oneOwner ? 'One owner vehicle' : 'Multiple owners'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-blue-100 text-blue-600 mr-3`}>
                        <Award className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Service History</h3>
                        <p className="text-sm text-neutral-600">
                          {carfaxData.serviceRecords} service records available
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${!carfaxData.recallsReported ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'} mr-3`}>
                        {!carfaxData.recallsReported ? <Check className="w-5 h-5" /> : '!'}
                      </div>
                      <div>
                        <h3 className="font-semibold">Recalls</h3>
                        <p className="text-sm text-neutral-600">
                          {carfaxData.recallsReported ? 'Open recalls reported' : 'No open recalls reported'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Button className="w-full bg-[#D92332] hover:bg-[#B81221] text-white">
                View Full CarFax Report
              </Button>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            {/* Contact & Actions */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h3 className="text-xl font-semibold mb-4">Interested in this vehicle?</h3>
              <Button 
                className="w-full bg-[#D92332] hover:bg-[#B81221] text-white mb-3"
                onClick={handleContactClick}
              >
                Contact Us
              </Button>
              <Button 
                variant="outline" 
                className="w-full mb-3 border-[#D92332] text-[#D92332] hover:bg-[#D92332] hover:text-white"
                onClick={() => window.open(`tel:${555-123-4567}`)}
              >
                Call Dealership
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setLocation("/credit-application")}
              >
                Apply for Financing
              </Button>
            </div>
            
            {/* Additional Information */}
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h3 className="text-lg font-semibold mb-3">Vehicle Information</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Stock #:</span>
                  <span className="font-medium">{vehicle.stockNumber || `ST${vehicle.id}${vehicle.year}`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">VIN:</span>
                  <span className="font-medium">{vehicle.vin || `VIN12345678901234`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Condition:</span>
                  <span className="font-medium">{vehicle.condition}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Exterior Color:</span>
                  <span className="font-medium">{vehicle.exteriorColor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Interior Color:</span>
                  <span className="font-medium">{vehicle.interiorColor}</span>
                </div>
              </div>
            </div>
            
            {/* Similar Vehicles */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-3">You Might Also Like</h3>
              <p className="text-sm text-neutral-600 mb-4">
                Check out similar vehicles from our inventory
              </p>
              <Button 
                className="w-full"
                onClick={() => setLocation("/inventory")}
              >
                Browse Similar Vehicles
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Fullscreen image carousel component
const FullscreenImageViewer = ({ 
  images, 
  activeIndex, 
  isOpen, 
  onClose,
  title
}: { 
  images: string[];
  activeIndex: number;
  isOpen: boolean;
  onClose: () => void;
  title: string;
}) => {
  const [currentIndex, setCurrentIndex] = useState(activeIndex);
  
  const nextImage = () => {
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };
  
  const prevImage = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-7xl w-[95vw] max-h-[95vh] p-0 bg-black border-none">
        <div className="relative h-full flex flex-col">
          <div className="absolute top-4 right-4 z-30">
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="rounded-full bg-black/50 text-white hover:bg-black/70"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="p-4 text-white z-20 bg-black/80">
            <h2 className="text-xl font-bold">{title}</h2>
            <p className="text-sm opacity-80">
              Image {currentIndex + 1} of {images.length}
            </p>
          </div>
          
          <div className="flex-1 flex items-center justify-center overflow-hidden relative">
            <img
              src={images[currentIndex]}
              alt={`Image ${currentIndex + 1}`}
              className="max-h-[80vh] max-w-full object-contain"
            />
            
            <Button
              variant="ghost"
              onClick={prevImage}
              className="absolute left-4 rounded-full w-12 h-12 bg-black/30 hover:bg-black/50 text-white"
              aria-label="Previous image"
            >
              <ChevronLeft className="h-8 w-8" />
            </Button>
            
            <Button
              variant="ghost"
              onClick={nextImage}
              className="absolute right-4 rounded-full w-12 h-12 bg-black/30 hover:bg-black/50 text-white"
              aria-label="Next image"
            >
              <ChevronRight className="h-8 w-8" />
            </Button>
          </div>
          
          <div className="p-4 overflow-x-auto bg-black">
            <div className="flex gap-2">
              {images.map((img, idx) => (
                <div
                  key={idx}
                  className={`cursor-pointer flex-shrink-0 w-16 h-12 rounded overflow-hidden ${
                    idx === currentIndex ? "ring-2 ring-[#D92332]" : "opacity-50"
                  }`}
                  onClick={() => setCurrentIndex(idx)}
                >
                  <img
                    src={img}
                    alt={`Thumbnail ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const VehicleDetailPage = () => {
  const vehicleDetail = VehicleDetail();
  if (!vehicleDetail) return null;
  
  return vehicleDetail;
};

export default VehicleDetail;