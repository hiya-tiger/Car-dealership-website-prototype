import { Separator } from "@/components/ui/separator";
import { useEffect } from "react";

const PrivacyPolicy = () => {
  useEffect(() => {
    document.title = "Privacy Policy | 89 Auto Sales";
  }, []);
  
  return (
    <div className="bg-white">
      
      {/* Header Banner */}
      <div className="bg-black py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-white text-center">Privacy Policy</h1>
          <p className="text-neutral-400 text-center mt-4">How we collect and use your information</p>
        </div>
      </div>
      
      {/* Content Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-sm p-8">
            <h2 className="text-2xl font-bold mb-6">Privacy Policy for 89 Auto Sales</h2>
            <p className="text-neutral-700 mb-4">Last Updated: March 29, 2025</p>
            
            <p className="text-neutral-700 mb-6">
              At 89 Auto Sales, we respect your privacy and are committed to protecting your personal information. This privacy policy outlines the types of information we collect, how we use it, and the measures we take to safeguard your information.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Information We Collect</h3>
            <p className="text-neutral-700 mb-4">
              We collect various types of information to provide and improve our services:
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>
                <strong>Personal Information:</strong> Name, contact information, address, and government-issued ID numbers when you purchase a vehicle, apply for financing, or schedule services.
              </li>
              <li>
                <strong>Vehicle Information:</strong> Details about your current vehicle including make, model, year, VIN, and service history when you request service or trade-in evaluation.
              </li>
              <li>
                <strong>Financial Information:</strong> Income, employment details, and credit information when you apply for financing.
              </li>
              <li>
                <strong>Website Usage Data:</strong> Information about how you interact with our website including IP address, browser type, pages visited, and time spent on pages.
              </li>
            </ul>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">How We Use Your Information</h3>
            <p className="text-neutral-700 mb-4">
              We use the collected information for various purposes:
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>To process vehicle purchases, service requests, and financing applications</li>
              <li>To communicate with you about appointments, services, and vehicle maintenance</li>
              <li>To improve our website and customer experience</li>
              <li>To send you marketing communications about special offers and promotions (with your consent)</li>
              <li>To comply with legal obligations and enforce our terms</li>
            </ul>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Information Sharing</h3>
            <p className="text-neutral-700 mb-4">
              We may share your information with:
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>Financial institutions and lenders when you apply for financing</li>
              <li>Vehicle manufacturers for warranty registration and recall notices</li>
              <li>Service providers who assist us in operating our business</li>
              <li>Government authorities when required by law</li>
            </ul>
            <p className="text-neutral-700 mb-6">
              We do not sell your personal information to third parties for marketing purposes.
            </p>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Cookies and Tracking Technologies</h3>
            <p className="text-neutral-700 mb-6">
              Our website uses cookies and similar tracking technologies to enhance your browsing experience and collect information about how you use our site. You can manage your cookie preferences through your browser settings.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Your Privacy Rights</h3>
            <p className="text-neutral-700 mb-4">
              Depending on your location, you may have the following rights:
            </p>
            <ul className="list-disc pl-6 mb-6 text-neutral-700 space-y-2">
              <li>Access and receive a copy of your personal information</li>
              <li>Request correction of inaccurate information</li>
              <li>Request deletion of your personal information</li>
              <li>Object to or restrict certain processing of your information</li>
              <li>Withdraw consent for marketing communications</li>
            </ul>
            
            <Separator className="my-6" />
            
            <h3 className="text-xl font-semibold mb-4">Data Security</h3>
            <p className="text-neutral-700 mb-6">
              We implement appropriate security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Changes to This Privacy Policy</h3>
            <p className="text-neutral-700 mb-6">
              We may update this privacy policy from time to time to reflect changes in our practices or legal requirements. We will notify you of any material changes by posting the updated policy on our website with a new "Last Updated" date.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <p className="text-neutral-700 mb-6">
              If you have any questions or concerns about our privacy policy or practices, please contact us at:
            </p>
            <div className="text-neutral-700">
              <p>89 Auto Sales</p>
              <p>890 Speedway Blvd</p>
              <p>Charlotte, NC 28216</p>
              <p>Email: privacy@89autosales.com</p>
              <p>Phone: (704) 555-8989</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;