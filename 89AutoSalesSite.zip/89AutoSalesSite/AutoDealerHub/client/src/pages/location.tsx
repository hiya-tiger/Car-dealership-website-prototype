import { Card, CardContent } from "@/components/ui/card";
import { Clock, MapPin, Phone, Mail } from "lucide-react";

const Location = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Our Locations</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Visit one of our convenient dealership locations to explore our inventory and meet our team
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-bold mb-6">Main Showroom</h2>
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Address</h3>
                      <p className="text-neutral-600">123 Luxury Lane<br />Beverly Hills, CA 90210</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Phone</h3>
                      <p className="text-neutral-600">(800) 555-1234</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Mail className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Email</h3>
                      <p className="text-neutral-600">info@89autosales.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Clock className="w-5 h-5 mt-1 mr-3 text-[#D92332]" />
                    <div>
                      <h3 className="font-medium">Hours</h3>
                      <div className="text-neutral-600">
                        <div>Monday - Friday: 9AM - 8PM</div>
                        <div>Saturday: 10AM - 6PM</div>
                        <div>Sunday: Closed</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-bold mb-4">Dealership Amenities</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-[#D92332] rounded-full mr-2"></div>
                  <span>Customer Lounge</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-[#D92332] rounded-full mr-2"></div>
                  <span>Complimentary WiFi</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-[#D92332] rounded-full mr-2"></div>
                  <span>Coffee Bar</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-[#D92332] rounded-full mr-2"></div>
                  <span>Children's Play Area</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-[#D92332] rounded-full mr-2"></div>
                  <span>Private Consultation Rooms</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-[#D92332] rounded-full mr-2"></div>
                  <span>Vehicle Delivery Area</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg overflow-hidden shadow-md h-[500px]">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26430.39297327055!2d-118.43177214371658!3d34.09024386555184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2bc04d6d147ab%3A0xd6c7c379fd081ed1!2sBeverly%20Hills%2C%20CA%2090210!5e0!3m2!1sen!2sus!4v1620292605810!5m2!1sen!2sus" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen 
              loading="lazy"
              title="Main Showroom Location"
            ></iframe>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-center mb-6">Additional Locations</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-bold text-lg mb-4">Downtown Service Center</h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <MapPin className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <p className="text-neutral-600">456 Service Ave<br />Los Angeles, CA 90017</p>
                </div>
                <div className="flex items-start">
                  <Phone className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <p className="text-neutral-600">(800) 555-2345</p>
                </div>
                <div className="flex items-start">
                  <Clock className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <div className="text-neutral-600">
                    <div>Mon-Fri: 7:30AM - 7PM</div>
                    <div>Sat: 8AM - 5PM</div>
                    <div>Sun: Closed</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-bold text-lg mb-4">Westside Pre-Owned Center</h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <MapPin className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <p className="text-neutral-600">789 Auto Row Dr<br />Santa Monica, CA 90401</p>
                </div>
                <div className="flex items-start">
                  <Phone className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <p className="text-neutral-600">(800) 555-3456</p>
                </div>
                <div className="flex items-start">
                  <Clock className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <div className="text-neutral-600">
                    <div>Mon-Fri: 9AM - 8PM</div>
                    <div>Sat: 10AM - 7PM</div>
                    <div>Sun: 11AM - 5PM</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-bold text-lg mb-4">Valley Luxury Showroom</h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <MapPin className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <p className="text-neutral-600">321 Premium Blvd<br />Sherman Oaks, CA 91403</p>
                </div>
                <div className="flex items-start">
                  <Phone className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <p className="text-neutral-600">(800) 555-4567</p>
                </div>
                <div className="flex items-start">
                  <Clock className="w-4 h-4 mt-1 mr-2 text-[#D92332]" />
                  <div className="text-neutral-600">
                    <div>Mon-Fri: 9AM - 8PM</div>
                    <div>Sat: 10AM - 6PM</div>
                    <div>Sun: Closed</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold mb-4">Get Directions</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto mb-6">
            Use your preferred navigation app to get directions to any of our locations. Our staff is ready to welcome you and assist with all your automotive needs.
          </p>
          <div className="flex justify-center space-x-4">
            <a 
              href="https://maps.apple.com/?address=123+Luxury+Lane,Beverly+Hills,CA+90210" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="px-4 py-2 bg-[#1A3A5F] text-white rounded-md hover:bg-[#0A2A4F] transition-colors"
            >
              Apple Maps
            </a>
            <a 
              href="https://www.google.com/maps/search/?api=1&query=123+Luxury+Lane,Beverly+Hills,CA+90210" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="px-4 py-2 bg-[#D92332] text-white rounded-md hover:bg-[#C91322] transition-colors"
            >
              Google Maps
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Location;
