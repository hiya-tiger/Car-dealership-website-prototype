import FinanceCalculator from "@/components/forms/finance-calculator";
import { Card, CardContent } from "@/components/ui/card";

const FinanceCalculatorPage = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Payment Calculator</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Estimate your monthly payments based on your preferred vehicle and financing terms
          </p>
        </div>

        <Card className="mb-12">
          <CardContent className="pt-6">
            <FinanceCalculator />
          </CardContent>
        </Card>

        <div className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-6">Understanding Auto Financing</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold mb-3">Interest Rate</h3>
                <p className="text-neutral-600">
                  Interest rates are determined by your credit score, loan term, and current market conditions. Lower interest rates lead to lower monthly payments and less paid over the life of the loan.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold mb-3">Down Payment</h3>
                <p className="text-neutral-600">
                  A larger down payment reduces the amount you need to finance, which lowers your monthly payment and may help you qualify for better interest rates.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold mb-3">Loan Term</h3>
                <p className="text-neutral-600">
                  Longer loan terms (60-84 months) result in lower monthly payments but higher total interest paid. Shorter terms mean higher monthly payments but less interest over time.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold mb-3">Trade-In Value</h3>
                <p className="text-neutral-600">
                  The value of your trade-in vehicle can be applied to your purchase, reducing the amount you need to finance and lowering your monthly payments.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold mb-3">Taxes and Fees</h3>
                <p className="text-neutral-600">
                  Remember to account for sales tax, registration, documentation fees, and other costs that may be added to the purchase price or financed with your loan.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-bold mb-3">Credit Score Impact</h3>
                <p className="text-neutral-600">
                  A higher credit score typically qualifies you for better interest rates. Before applying, check your credit report and address any issues to improve your score.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-center mb-6">Need Personalized Assistance?</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto text-center mb-6">
            While our calculator provides a good estimate, our finance professionals can help you explore all your options and find the best solution for your specific situation. Schedule a consultation today.
          </p>
          <div className="flex justify-center">
            <a href="/contact" className="bg-[#1A3A5F] hover:bg-[#0A2A4F] text-white px-6 py-3 rounded-md font-medium transition-colors">
              Contact Our Finance Team
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinanceCalculatorPage;
