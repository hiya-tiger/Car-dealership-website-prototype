import { Link } from "wouter";
import AppointmentForm from "@/components/forms/appointment-form";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Wrench, Car, Clock, Calendar, BadgeCheck } from "lucide-react";

const Service = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Service Center</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Expert care for your vehicle from factory-trained technicians
          </p>
        </div>

        <Tabs defaultValue="appointment" className="mb-12">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="appointment">Book Appointment</TabsTrigger>
            <TabsTrigger value="services">Our Services</TabsTrigger>
          </TabsList>
          
          <TabsContent value="appointment">
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-2xl font-bold mb-6">Schedule a Service Appointment</h2>
                <AppointmentForm defaultType="service" />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="services">
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-2xl font-bold mb-6">Our Services</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Oil Changes</h3>
                    </div>
                    <p className="text-neutral-600">
                      Regular oil changes to keep your engine running smoothly.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Tire Services</h3>
                    </div>
                    <p className="text-neutral-600">
                      Rotation, balancing, alignment, and replacement.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Brake Service</h3>
                    </div>
                    <p className="text-neutral-600">
                      Inspection and replacement of brake pads, rotors, and fluids.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Battery Service</h3>
                    </div>
                    <p className="text-neutral-600">
                      Testing, charging, and replacement.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">A/C Service</h3>
                    </div>
                    <p className="text-neutral-600">
                      Inspection, recharge, and repair of A/C systems.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Diagnostics</h3>
                    </div>
                    <p className="text-neutral-600">
                      Computerized diagnostics for all systems.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Transmission Service</h3>
                    </div>
                    <p className="text-neutral-600">
                      Fluid changes and transmission repairs.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Engine Repair</h3>
                    </div>
                    <p className="text-neutral-600">
                      From minor tune-ups to major repairs.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Wrench className="text-[#D92332] mr-2" />
                      <h3 className="font-bold">Electrical Systems</h3>
                    </div>
                    <p className="text-neutral-600">
                      Diagnosis and repair of electrical issues.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-bold mb-6">Why Choose Our Service Center</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                      <Shield className="text-[#1A3A5F] w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Factory-Trained Technicians</h3>
                      <p className="text-neutral-600">
                        Our certified technicians receive ongoing training to stay current with the latest automotive technology.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                      <Wrench className="text-[#1A3A5F] w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">State-of-the-Art Equipment</h3>
                      <p className="text-neutral-600">
                        We invest in the latest diagnostic tools and equipment to properly service today's advanced vehicles.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                      <Car className="text-[#1A3A5F] w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Genuine Parts</h3>
                      <p className="text-neutral-600">
                        We use only genuine OEM parts to ensure proper fit, function, and longevity for your vehicle.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                      <Clock className="text-[#1A3A5F] w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">Convenient Hours</h3>
                      <p className="text-neutral-600">
                        Early morning drop-offs, late pick-ups, and Saturday service appointments available.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <h2 className="text-2xl font-bold mb-6">Service Packages</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="border-b pb-4">
                    <h3 className="text-lg font-bold mb-2">Basic Maintenance Package</h3>
                    <p className="text-neutral-600 mb-2">
                      Oil change, tire rotation, multi-point inspection, and fluid top-off.
                    </p>
                    <p className="font-medium">Starting at $99.95</p>
                  </div>
                  
                  <div className="border-b pb-4">
                    <h3 className="text-lg font-bold mb-2">Premium Maintenance Package</h3>
                    <p className="text-neutral-600 mb-2">
                      Everything in Basic plus brake inspection, battery test, and cabin air filter replacement.
                    </p>
                    <p className="font-medium">Starting at $189.95</p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold mb-2">Complete Care Package</h3>
                    <p className="text-neutral-600 mb-2">
                      Everything in Premium plus alignment check, engine air filter, and wiper blade replacement.
                    </p>
                    <p className="font-medium">Starting at $269.95</p>
                  </div>
                  
                  <div className="pt-4">
                    <Link href="#">
                      <a className="text-[#D92332] font-medium hover:underline">
                        View All Service Specials
                      </a>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-[#1A3A5F] text-white rounded-lg p-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl font-bold mb-4">Schedule a Test Drive</h2>
              <p className="mb-6">
                Looking to purchase a new vehicle? Schedule a test drive with one of our sales specialists to experience your dream car firsthand.
              </p>
              <div className="space-y-2">
                <div className="flex items-center">
                  <BadgeCheck className="mr-2" />
                  <span>No pressure sales environment</span>
                </div>
                <div className="flex items-center">
                  <BadgeCheck className="mr-2" />
                  <span>Knowledgeable product specialists</span>
                </div>
                <div className="flex items-center">
                  <BadgeCheck className="mr-2" />
                  <span>Extended test drives available</span>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <Link href="/service">
                <a className="bg-white text-[#1A3A5F] hover:bg-neutral-100 px-6 py-3 rounded-md font-medium transition-colors inline-flex items-center">
                  <Calendar className="mr-2 w-5 h-5" />
                  Book a Test Drive
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Service;
