import { Card, CardContent } from "@/components/ui/card";
import { Award, Shield, Users, History } from "lucide-react";

const About = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">About 89 Auto Sales</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Performance vehicles, racing excellence, and customer satisfaction since 2005
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <div className="flex flex-col justify-center">
            <h2 className="text-2xl font-bold mb-4">Our Story</h2>
            <p className="text-neutral-600 mb-4">
              89 Auto Sales was founded in 2005 with a passion for racing and high-performance vehicles. What began as a small dealership focused on muscle cars and sports vehicles has grown into one of the premier automotive destinations for racing enthusiasts in North Carolina.
            </p>
            <p className="text-neutral-600 mb-4">
              For nearly two decades, we've maintained our commitment to performance, integrity, and racing-inspired service. Our team of automotive enthusiasts and NASCAR experts are dedicated to matching each client with the perfect high-performance vehicle.
            </p>
            <p className="text-neutral-600">
              Today, 89 Auto Sales offers the finest performance vehicles from American and European manufacturers, specializing in muscle cars, sports cars, and race-ready vehicles that exemplify speed, power, and innovation.
            </p>
          </div>
          <div className="rounded-lg overflow-hidden shadow-md">
            <img 
              src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&q=80" 
              alt="Luxury car showroom" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center mb-8">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mb-4">
                    <Award className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Excellence</h3>
                  <p className="text-neutral-600">
                    We strive for excellence in every interaction, every vehicle, and every service we provide.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mb-4">
                    <Shield className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Integrity</h3>
                  <p className="text-neutral-600">
                    We conduct our business with honesty, transparency, and unwavering ethical standards.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mb-4">
                    <Users className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Personalized Service</h3>
                  <p className="text-neutral-600">
                    We take the time to understand our clients' needs and provide tailored solutions.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center mb-4">
                    <History className="text-[#1A3A5F] w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Innovation</h3>
                  <p className="text-neutral-600">
                    We embrace technology and innovation to enhance the automotive experience for our clients.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center mb-8">Our Leadership Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full overflow-hidden mb-4">
                    <img 
                      src="https://i.pravatar.cc/150?img=11" 
                      alt="CEO" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-bold">Robert Johnson</h3>
                  <p className="text-[#D92332] font-medium mb-2">Chief Executive Officer</p>
                  <p className="text-neutral-600">
                    With over 25 years in the luxury automotive industry, Robert leads our company with vision and integrity.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full overflow-hidden mb-4">
                    <img 
                      src="https://i.pravatar.cc/150?img=5" 
                      alt="Sales Director" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-bold">Sarah Martinez</h3>
                  <p className="text-[#D92332] font-medium mb-2">Sales Director</p>
                  <p className="text-neutral-600">
                    Sarah ensures our sales team provides exceptional service while matching clients with their dream vehicles.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="w-24 h-24 rounded-full overflow-hidden mb-4">
                    <img 
                      src="https://i.pravatar.cc/150?img=7" 
                      alt="Service Manager" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-bold">Michael Chen</h3>
                  <p className="text-[#D92332] font-medium mb-2">Service Manager</p>
                  <p className="text-neutral-600">
                    Michael leads our service department with technical expertise and a commitment to customer satisfaction.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-center mb-6">Our Commitment to You</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto text-center">
            At 89 Auto Sales, we're more than just a dealership – we're your racing-inspired automotive partner. Whether you're purchasing your first performance vehicle, upgrading your current car, or exploring financing options for a track-ready machine, our team is dedicated to making your experience exceptional. We invite you to visit our showroom and discover the 89 Auto Sales difference.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
