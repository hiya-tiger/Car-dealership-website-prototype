import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Car, 
  CreditCard, 
  FileText, 
  Repeat, 
  Calculator, 
  Calendar, 
  ChevronRight, 
  ShoppingBag 
} from "lucide-react";

const BuyerIndex = () => {
  return (
    <div className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-2">Buyer Center</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Your one-stop resource for all vehicle purchasing needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Link href="/inventory">
            <a>
              <Card className="h-full transition-all hover:shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-start h-full">
                    <div className="w-12 h-12 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center flex-shrink-0 mr-4">
                      <Car className="text-[#1A3A5F] w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold mb-2">Browse Inventory</h2>
                      <p className="text-neutral-600 mb-4">
                        Explore our extensive selection of new, used, and certified pre-owned vehicles from top luxury brands.
                      </p>
                      <div className="text-[#D92332] font-medium flex items-center mt-auto">
                        View Inventory <ChevronRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
          
          <Link href="/credit-application">
            <a>
              <Card className="h-full transition-all hover:shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-start h-full">
                    <div className="w-12 h-12 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center flex-shrink-0 mr-4">
                      <CreditCard className="text-[#1A3A5F] w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold mb-2">Apply for Credit</h2>
                      <p className="text-neutral-600 mb-4">
                        Get pre-approved for financing with our secure online credit application. Quick responses and competitive rates.
                      </p>
                      <div className="text-[#D92332] font-medium flex items-center mt-auto">
                        Start Application <ChevronRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
          
          <Link href="/trade-in">
            <a>
              <Card className="h-full transition-all hover:shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-start h-full">
                    <div className="w-12 h-12 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center flex-shrink-0 mr-4">
                      <Repeat className="text-[#1A3A5F] w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold mb-2">Value Your Trade</h2>
                      <p className="text-neutral-600 mb-4">
                        Get a fair and competitive offer for your current vehicle in minutes. Apply the value to your new purchase.
                      </p>
                      <div className="text-[#D92332] font-medium flex items-center mt-auto">
                        Appraise Trade-In <ChevronRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
          
          <Link href="/financing">
            <a>
              <Card className="h-full transition-all hover:shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-start h-full">
                    <div className="w-12 h-12 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center flex-shrink-0 mr-4">
                      <FileText className="text-[#1A3A5F] w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold mb-2">Financing Options</h2>
                      <p className="text-neutral-600 mb-4">
                        Learn about our flexible financing solutions, lease options, and special programs for qualified buyers.
                      </p>
                      <div className="text-[#D92332] font-medium flex items-center mt-auto">
                        Explore Financing <ChevronRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
          
          <Link href="/finance-calculator">
            <a>
              <Card className="h-full transition-all hover:shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-start h-full">
                    <div className="w-12 h-12 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center flex-shrink-0 mr-4">
                      <Calculator className="text-[#1A3A5F] w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold mb-2">Payment Calculator</h2>
                      <p className="text-neutral-600 mb-4">
                        Estimate monthly payments based on vehicle price, down payment, interest rate, and term length.
                      </p>
                      <div className="text-[#D92332] font-medium flex items-center mt-auto">
                        Calculate Payment <ChevronRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
          
          <Link href="/service">
            <a>
              <Card className="h-full transition-all hover:shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex items-start h-full">
                    <div className="w-12 h-12 bg-[#1A3A5F]/10 rounded-full flex items-center justify-center flex-shrink-0 mr-4">
                      <Calendar className="text-[#1A3A5F] w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold mb-2">Schedule Test Drive</h2>
                      <p className="text-neutral-600 mb-4">
                        Book an appointment to test drive your preferred vehicle. Experience the performance and features firsthand.
                      </p>
                      <div className="text-[#D92332] font-medium flex items-center mt-auto">
                        Book Appointment <ChevronRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </a>
          </Link>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-md mb-12">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="md:w-1/4 flex justify-center">
              <ShoppingBag className="w-24 h-24 text-[#1A3A5F]" />
            </div>
            <div className="md:w-3/4">
              <h2 className="text-2xl font-bold mb-4">Buying Guide</h2>
              <p className="text-neutral-600 mb-6">
                Our comprehensive buying guide will walk you through the car-buying process step by step, from research to delivery. Learn about important considerations, common pitfalls to avoid, and insider tips to help you make an informed decision.
              </p>
              <ol className="list-decimal list-inside space-y-2 mb-4">
                <li className="text-[#1A3A5F] font-medium">Research vehicles that meet your needs and budget</li>
                <li className="text-[#1A3A5F] font-medium">Get pre-approved for financing</li>
                <li className="text-[#1A3A5F] font-medium">Test drive your shortlisted vehicles</li>
                <li className="text-[#1A3A5F] font-medium">Evaluate your trade-in options</li>
                <li className="text-[#1A3A5F] font-medium">Review and finalize your purchase</li>
              </ol>
              <a href="#" className="text-[#D92332] font-medium hover:underline">
                Download Complete Buying Guide (PDF)
              </a>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-bold mb-4">Why Buy From Us</h2>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-[#D92332] text-white flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">✓</div>
                  <div>
                    <h3 className="font-bold">No-Pressure Sales Environment</h3>
                    <p className="text-neutral-600">Take your time to make the right decision without feeling rushed.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-[#D92332] text-white flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">✓</div>
                  <div>
                    <h3 className="font-bold">Transparent Pricing</h3>
                    <p className="text-neutral-600">Clear, upfront pricing with no hidden fees or surprises.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-[#D92332] text-white flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">✓</div>
                  <div>
                    <h3 className="font-bold">Vehicle History Reports</h3>
                    <p className="text-neutral-600">Detailed history reports provided for all pre-owned vehicles.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="w-6 h-6 rounded-full bg-[#D92332] text-white flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">✓</div>
                  <div>
                    <h3 className="font-bold">Extended Warranty Options</h3>
                    <p className="text-neutral-600">Comprehensive warranty packages for peace of mind.</p>
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-bold mb-4">Customer Testimonials</h2>
              <div className="space-y-4">
                <div className="border-l-4 border-[#1A3A5F] pl-4">
                  <p className="italic text-neutral-600 mb-2">
                    "The entire car buying process was smooth and transparent. Our sales representative was knowledgeable and helped us find the perfect vehicle for our family's needs."
                  </p>
                  <p className="font-medium">— Michael Thompson, BMW X5 Owner</p>
                </div>
                <div className="border-l-4 border-[#1A3A5F] pl-4">
                  <p className="italic text-neutral-600 mb-2">
                    "I appreciated the no-pressure approach from the sales team. They listened to my needs and helped me find a car that fit my budget. The financing process was quick and easy too."
                  </p>
                  <p className="font-medium">— Sarah Johnson, Audi A4 Owner</p>
                </div>
              </div>
              <div className="mt-4 flex justify-center">
                <Link href="#">
                  <a className="text-[#D92332] font-medium hover:underline">
                    Read More Testimonials
                  </a>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default BuyerIndex;
