// Color theme constants - NASCAR-inspired red, black, and white
export const COLORS = {
  primary: {
    DEFAULT: '#D92332',  // Vibrant red
    light: '#E94352',
    dark: '#C91322'
  },
  secondary: {
    DEFAULT: '#000000',  // Black
    light: '#212121',
    dark: '#000000'
  },
  accent: {
    DEFAULT: '#FFFFFF',  // White
    light: '#FFFFFF',
    dark: '#F0F0F0'
  }
};

// Vehicle related constants
export const VEHICLE_CONDITIONS = [
  { value: "new", label: "New" },
  { value: "used", label: "Used" },
  { value: "certified", label: "Certified Pre-Owned" }
];

export const VEHICLE_BODY_STYLES = [
  { value: "Sedan", label: "Sedan" },
  { value: "SUV", label: "SUV" },
  { value: "Coupe", label: "Coupe" },
  { value: "Truck", label: "Truck" },
  { value: "Convertible", label: "Convertible" },
  { value: "Wagon", label: "Wagon" },
  { value: "Van", label: "Van" },
  { value: "Hatchback", label: "Hatchback" }
];

export const POPULAR_MAKES = [
  { value: "Chevrolet", label: "Chevrolet" },
  { value: "Ford", label: "Ford" },
  { value: "Toyota", label: "Toyota" },
  { value: "Dodge", label: "Dodge" },
  { value: "RAM", label: "RAM" },
  { value: "GMC", label: "GMC" },
  { value: "Jeep", label: "Jeep" },
  { value: "Nissan", label: "Nissan" },
  { value: "Honda", label: "Honda" },
  { value: "BMW", label: "BMW" }
];

// Financing constants
export const INTEREST_RATES = [
  { value: 3.5, label: "Excellent (720+): ~3.5%" },
  { value: 4.5, label: "Good (690-719): ~4.5%" },
  { value: 5.5, label: "Fair (660-689): ~5.5%" },
  { value: 7.5, label: "Poor (620-659): ~7.5%" },
  { value: 10.5, label: "Bad (580-619): ~10.5%" }
];

export const LOAN_TERMS = [
  { value: 36, label: "36 months (3 years)" },
  { value: 48, label: "48 months (4 years)" },
  { value: 60, label: "60 months (5 years)" },
  { value: 72, label: "72 months (6 years)" },
  { value: 84, label: "84 months (7 years)" }
];

// Trade-in constants
export const VEHICLE_CONDITIONS_TRADE_IN = [
  { value: "excellent", label: "Excellent - Like new" },
  { value: "good", label: "Good - Minor wear and tear" },
  { value: "fair", label: "Fair - Some mechanical issues" },
  { value: "poor", label: "Poor - Significant problems" }
];

// Employment status options
export const EMPLOYMENT_STATUSES = [
  { value: "fullTime", label: "Full-time" },
  { value: "partTime", label: "Part-time" },
  { value: "selfEmployed", label: "Self-employed" },
  { value: "retired", label: "Retired" },
  { value: "unemployed", label: "Unemployed" }
];

// Service types
export const SERVICE_TYPES = [
  { value: "maintenance", label: "Regular Maintenance" },
  { value: "repair", label: "Repair" },
  { value: "inspection", label: "Vehicle Inspection" },
  { value: "diagnostic", label: "Diagnostic" },
  { value: "other", label: "Other" }
];

// Appointment times
export const APPOINTMENT_TIMES = [
  { value: "9:00 AM", label: "9:00 AM" },
  { value: "10:00 AM", label: "10:00 AM" },
  { value: "11:00 AM", label: "11:00 AM" },
  { value: "12:00 PM", label: "12:00 PM" },
  { value: "1:00 PM", label: "1:00 PM" },
  { value: "2:00 PM", label: "2:00 PM" },
  { value: "3:00 PM", label: "3:00 PM" },
  { value: "4:00 PM", label: "4:00 PM" },
  { value: "5:00 PM", label: "5:00 PM" }
];

// Inquiry interest types
export const INQUIRY_INTEREST_TYPES = [
  { value: "new", label: "New Vehicles" },
  { value: "used", label: "Pre-Owned Vehicles" },
  { value: "service", label: "Service & Maintenance" },
  { value: "finance", label: "Financing Options" },
  { value: "other", label: "Other Inquiry" }
];

// US States for forms
export const US_STATES = [
  { value: "AL", label: "Alabama" },
  { value: "AK", label: "Alaska" },
  { value: "AZ", label: "Arizona" },
  { value: "AR", label: "Arkansas" },
  { value: "CA", label: "California" },
  { value: "CO", label: "Colorado" },
  { value: "CT", label: "Connecticut" },
  { value: "DE", label: "Delaware" },
  { value: "FL", label: "Florida" },
  { value: "GA", label: "Georgia" },
  { value: "HI", label: "Hawaii" },
  { value: "ID", label: "Idaho" },
  { value: "IL", label: "Illinois" },
  { value: "IN", label: "Indiana" },
  { value: "IA", label: "Iowa" },
  { value: "KS", label: "Kansas" },
  { value: "KY", label: "Kentucky" },
  { value: "LA", label: "Louisiana" },
  { value: "ME", label: "Maine" },
  { value: "MD", label: "Maryland" },
  { value: "MA", label: "Massachusetts" },
  { value: "MI", label: "Michigan" },
  { value: "MN", label: "Minnesota" },
  { value: "MS", label: "Mississippi" },
  { value: "MO", label: "Missouri" },
  { value: "MT", label: "Montana" },
  { value: "NE", label: "Nebraska" },
  { value: "NV", label: "Nevada" },
  { value: "NH", label: "New Hampshire" },
  { value: "NJ", label: "New Jersey" },
  { value: "NM", label: "New Mexico" },
  { value: "NY", label: "New York" },
  { value: "NC", label: "North Carolina" },
  { value: "ND", label: "North Dakota" },
  { value: "OH", label: "Ohio" },
  { value: "OK", label: "Oklahoma" },
  { value: "OR", label: "Oregon" },
  { value: "PA", label: "Pennsylvania" },
  { value: "RI", label: "Rhode Island" },
  { value: "SC", label: "South Carolina" },
  { value: "SD", label: "South Dakota" },
  { value: "TN", label: "Tennessee" },
  { value: "TX", label: "Texas" },
  { value: "UT", label: "Utah" },
  { value: "VT", label: "Vermont" },
  { value: "VA", label: "Virginia" },
  { value: "WA", label: "Washington" },
  { value: "WV", label: "West Virginia" },
  { value: "WI", label: "Wisconsin" },
  { value: "WY", label: "Wyoming" }
];

// Company information
export const COMPANY_INFO = {
  name: "89 Auto Sales",
  phone: "(704) 555-8989",
  email: "info@89autosales.com",
  address: {
    street: "890 Speedway Blvd",
    city: "Charlotte",
    state: "NC",
    zip: "28216"
  },
  hours: {
    weekdays: "9AM - 9PM",
    saturday: "9AM - 7PM", 
    sunday: "11AM - 5PM"
  },
  social: {
    facebook: "https://facebook.com/89autosales",
    twitter: "https://twitter.com/89autosales",
    instagram: "https://instagram.com/89autosales",
    linkedin: "https://linkedin.com/company/89autosales"
  }
};
