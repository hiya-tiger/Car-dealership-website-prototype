# 89 Auto Sales Database Backup

This directory contains database backups for the 89 Auto Sales dealership website.

## Files

- `database_backup.sql` - SQL backup file containing all database tables and data
- `dealership_database_backup.zip` - Compressed ZIP archive of the SQL backup file

## Using the Backup Utility

We've included a database backup utility script in the `tools` directory that can help you manage database backups and restoration.

### Exporting a Database Backup

To create a new backup of the current database:

```bash
node tools/db-backup.js export
```

This will create a backup file in the `backup` directory with the default name `dealership_backup.sql`.

To specify a custom filename:

```bash
node tools/db-backup.js export /path/to/my-backup.sql
```

To create a ZIP archive of the backup file:

```bash
node tools/db-backup.js export --zip
```

### Importing a Database Backup

To restore a database from a backup file:

```bash
node tools/db-backup.js import
```

This will import the default backup file (`dealership_backup.sql`).

To specify a custom backup file to import:

```bash
node tools/db-backup.js import /path/to/my-backup.sql
```

## Manual Backup and Restore

If you prefer to use PostgreSQL tools directly:

### Manual Export (Backup)

```bash
pg_dump -U $PGUSER -h $PGHOST -p $PGPORT -d $PGDATABASE > backup_file.sql
```

### Manual Import (Restore)

```bash
psql -U $PGUSER -h $PGHOST -p $PGPORT -d $PGDATABASE -f backup_file.sql
```

## Important Notes

- Always make regular backups of your database to prevent data loss
- Test the restore process periodically to ensure backups are valid
- Keep backup files in a secure location
- Consider backing up to multiple locations (local storage, cloud storage, etc.)