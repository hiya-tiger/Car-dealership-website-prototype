import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  price: integer("price").notNull(),
  mileage: integer("mileage").notNull(),
  exteriorColor: text("exterior_color").notNull(),
  interiorColor: text("interior_color").notNull(),
  fuelType: text("fuel_type").notNull(),
  transmission: text("transmission").notNull(),
  bodyStyle: text("body_style").notNull(),
  engineSize: text("engine_size").notNull(),
  description: text("description").notNull(),
  features: text("features").array(),
  images: text("images").array(),
  vin: text("vin").notNull().unique(),
  mpgCity: integer("mpg_city"),
  mpgHighway: integer("mpg_highway"),
  engineDescription: text("engine_description"),
  horsepower: integer("horsepower"),
  torque: integer("torque"),
  isFeatured: boolean("is_featured").default(false),
  isSpecialOffer: boolean("is_special_offer").default(false),
  monthlyPayment: integer("monthly_payment"),
  // Vehicle status
  status: text("status").default("available").notNull(), // Values: "available", "pending", "sold"
  // 3D and AR model fields
  modelUrl: text("model_url"), // URL to 3D model for showroom
  interiorModelUrl: text("interior_model_url"), // URL to interior 3D model
  arModelUrl: text("ar_model_url"), // URL to AR model for placing on driveways
  arModelScale: doublePrecision("ar_model_scale").default(1.0), // Scale factor for AR model
  createdAt: timestamp("created_at").defaultNow(),
  // CarFax fields
  carfaxLink: text("carfax_link"),
  carfaxReportDate: timestamp("carfax_report_date"),
  carfaxOwners: integer("carfax_owners"),
  carfaxAccidents: integer("carfax_accidents"),
  carfaxServiceRecords: integer("carfax_service_records"),
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
});

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehicles.$inferSelect;

export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  message: text("message").notNull(),
  vehicleId: integer("vehicle_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInquirySchema = createInsertSchema(inquiries).omit({
  id: true,
  createdAt: true,
});

export type InsertInquiry = z.infer<typeof insertInquirySchema>;
export type Inquiry = typeof inquiries.$inferSelect;

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rating: integer("rating").notNull(),
  review: text("review").notNull(),
  vehicle: text("vehicle").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTestimonialSchema = createInsertSchema(testimonials).omit({
  id: true,
  createdAt: true,
});

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

export const tradeIns = pgTable("trade_ins", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: text("year").notNull(),
  mileage: text("mileage").notNull(),
  condition: text("condition").notNull(),
  comments: text("comments"),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTradeInSchema = createInsertSchema(tradeIns).omit({
  id: true,
  status: true,
  createdAt: true,
});

export type InsertTradeIn = z.infer<typeof insertTradeInSchema>;
export type TradeIn = typeof tradeIns.$inferSelect;
