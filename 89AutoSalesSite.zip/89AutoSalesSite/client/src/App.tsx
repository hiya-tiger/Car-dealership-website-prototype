import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import InventoryPage from "@/pages/InventoryPage";
import VehicleDetailPage from "@/pages/VehicleDetailPage";
import FinancingPage from "@/pages/FinancingPage";
import AboutPage from "@/pages/AboutPage";
import ContactPage from "@/pages/ContactPage";
import LocationPage from "@/pages/LocationPage";
import ServicePage from "@/pages/ServicePage";
import VirtualShowroomPage from "@/pages/VirtualShowroomPage";
import BuyerResourcesPage from "@/pages/BuyerResourcesPage";
import PrivacyPolicyPage from "@/pages/PrivacyPolicyPage";
import TermsOfServicePage from "@/pages/TermsOfServicePage";
import TestimonialsPage from "@/pages/TestimonialsPage";
import SitemapPage from "@/pages/SitemapPage";
import TradeInPage from "@/pages/TradeInPage";
import DashboardPage from "@/pages/admin/DashboardPage";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

function Router() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith('/admin');
  
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/inventory" component={InventoryPage} />
      <Route path="/vehicles/:id" component={VehicleDetailPage} />
      <Route path="/financing" component={FinancingPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/location" component={LocationPage} />
      <Route path="/service" component={ServicePage} />
      <Route path="/virtual-showroom" component={VirtualShowroomPage} />
      <Route path="/virtual-showroom/:id" component={VirtualShowroomPage} />
      <Route path="/buyer-resources" component={BuyerResourcesPage} />
      <Route path="/testimonials" component={TestimonialsPage} />
      <Route path="/trade-in" component={TradeInPage} />
      <Route path="/privacy-policy" component={PrivacyPolicyPage} />
      <Route path="/terms-of-service" component={TermsOfServicePage} />
      <Route path="/sitemap" component={SitemapPage} />
      
      {/* Admin Routes */}
      <Route path="/admin" component={DashboardPage} />
      <Route path="/admin/dashboard" component={DashboardPage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith('/admin');
  
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col bg-black text-white">
        {!isAdminRoute && <Header />}
        <main className={`flex-grow ${isAdminRoute ? 'pt-0' : ''}`}>
          <Router />
        </main>
        {!isAdminRoute && <Footer />}
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
