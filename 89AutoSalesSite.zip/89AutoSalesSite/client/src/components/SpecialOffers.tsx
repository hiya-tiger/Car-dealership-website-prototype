import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const SpecialOffers = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-10">Special Offers</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Special Offer 1 */}
          <Card className="overflow-hidden border-gray-200">
            <div className="relative">
              <div className="absolute top-0 left-0 right-0 bg-red-600 text-white py-2 text-center font-bold">
                WEEKEND SPECIAL
              </div>
              <img 
                src="https://images.unsplash.com/photo-1609520505218-7421df70121d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8YXVkaSUyMGE0fGVufDB8MHwwfHw%3D&auto=format&fit=crop&w=600&q=60" 
                alt="Audi A4 Special Offer" 
                className="w-full h-48 object-cover pt-10"
              />
            </div>
            
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">Luxury For Less</h3>
              <p className="text-gray-600 mb-4">Save up to $3,000 on select luxury sedans. Limited time offer.</p>
              
              <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-4">
                <p className="font-medium">2018+ Audi, BMW, and Mercedes models</p>
                <p className="text-sm text-gray-600">Offer valid until June 30, 2023</p>
              </div>
              
              <Button asChild className="w-full">
                <Link href="/inventory">View Eligible Vehicles</Link>
              </Button>
            </CardContent>
          </Card>
          
          {/* Special Offer 2 */}
          <Card className="overflow-hidden border-gray-200">
            <div className="relative">
              <div className="absolute top-0 left-0 right-0 bg-amber-500 text-white py-2 text-center font-bold">
                FINANCING OFFER
              </div>
              <img 
                src="https://images.unsplash.com/photo-1606664515524-ed2f786a0cb8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fGZpbmFuY2luZ3xlbnwwfDB8MHx8&auto=format&fit=crop&w=600&q=60" 
                alt="Financing Special" 
                className="w-full h-48 object-cover pt-10"
              />
            </div>
            
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">0.9% APR Financing</h3>
              <p className="text-gray-600 mb-4">Qualified buyers can get 0.9% APR financing for up to 60 months.</p>
              
              <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-4">
                <p className="font-medium">On certified pre-owned vehicles</p>
                <p className="text-sm text-gray-600">With approved credit. See dealer for details.</p>
              </div>
              
              <Button asChild className="w-full">
                <Link href="/financing">Learn More</Link>
              </Button>
            </CardContent>
          </Card>
          
          {/* Special Offer 3 */}
          <Card className="overflow-hidden border-gray-200">
            <div className="relative">
              <div className="absolute top-0 left-0 right-0 bg-green-600 text-white py-2 text-center font-bold">
                ECO BONUS
              </div>
              <img 
                src="https://images.unsplash.com/photo-1593941707882-a5bba53b1e47?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8ZWxlY3RyaWMlMjBjaGFyZ2luZ3xlbnwwfDB8MHx8&auto=format&fit=crop&w=600&q=60" 
                alt="EV Charging" 
                className="w-full h-48 object-cover pt-10"
              />
            </div>
            
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">EV & Hybrid Incentive</h3>
              <p className="text-gray-600 mb-4">Free home charger installation with purchase of any electric vehicle.</p>
              
              <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-4">
                <p className="font-medium">Plus $500 credit on hybrid vehicles</p>
                <p className="text-sm text-gray-600">For new customers only. Terms apply.</p>
              </div>
              
              <Button asChild className="w-full">
                <Link href="/inventory">Explore Green Vehicles</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default SpecialOffers;
