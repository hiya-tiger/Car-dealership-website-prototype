import { useState } from "react";
import { Vehicle } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  Car, 
  Calendar, 
  Gauge, 
  PaintBucket, 
  Sofa, 
  Fuel, 
  Cog, 
  Truck, 
  Banknote,
  Info, 
  ChartBarStacked,
  Heart,
  PrinterIcon,
  Share2
} from "lucide-react";
import { useVehicleComparison } from "@/hooks/useVehicleComparison";
import { useToast } from "@/hooks/use-toast";
import CarfaxSection from "./CarfaxSection";

interface VehicleDetailsProps {
  vehicle: Vehicle;
}

const VehicleDetails: React.FC<VehicleDetailsProps> = ({ vehicle }) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToComparison, isInComparison } = useVehicleComparison();
  const { toast } = useToast();
  
  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite);
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: `${vehicle.year} ${vehicle.make} ${vehicle.model} ${isFavorite ? "removed from" : "added to"} your favorites.`,
    });
  };
  
  const handleAddToComparison = () => {
    addToComparison(vehicle);
  };
  
  const handleShareVehicle = () => {
    if (navigator.share) {
      navigator.share({
        title: `${vehicle.year} ${vehicle.make} ${vehicle.model}`,
        text: `Check out this ${vehicle.year} ${vehicle.make} ${vehicle.model} on 89 Autosales!`,
        url: window.location.href,
      }).catch((error) => {
        console.log('Error sharing', error);
      });
    } else {
      // Fallback
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Vehicle link copied to clipboard",
      });
    }
  };
  
  const handlePrint = () => {
    window.print();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">{vehicle.year} {vehicle.make} {vehicle.model}</h1>
        <div className="flex space-x-2">
          <Button 
            variant={isFavorite ? "secondary" : "outline"} 
            size="sm"
            onClick={handleToggleFavorite}
            className="flex items-center gap-1"
          >
            <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
            {isFavorite ? "Saved" : "Save"}
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            onClick={handleShareVehicle}
          >
            <Share2 className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            onClick={handlePrint}
          >
            <PrinterIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <p className="text-gray-600 text-lg mb-6">{vehicle.model} {vehicle.engineSize}</p>
      
      {/* Main vehicle image and gallery */}
      <div className="mb-6">
        <div className="bg-gray-100 rounded-lg overflow-hidden mb-2">
          <img 
            src={(vehicle.images && vehicle.images.length > 0) ? vehicle.images[activeImageIndex] : "https://placehold.co/800x500?text=No+Image"} 
            alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
            className="w-full h-96 object-cover object-center"
          />
        </div>
        
        <div className="grid grid-cols-5 gap-2">
          {vehicle.images && vehicle.images.length > 0 && vehicle.images.map((image, index) => (
            <button 
              key={index}
              className={`h-20 bg-gray-100 rounded overflow-hidden ${index === activeImageIndex ? 'ring-2 ring-red-600' : ''}`}
              onClick={() => setActiveImageIndex(index)}
            >
              <img 
                src={image}
                alt={`${vehicle.year} ${vehicle.make} ${vehicle.model} view ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      </div>
      
      {/* Vehicle overview section */}
      <div className="flex flex-wrap justify-between items-start mb-8">
        <div>
          <div className="flex items-center gap-4 mb-4">
            <div className="text-3xl font-bold text-red-600">${parseInt(vehicle.price.toString()).toLocaleString()}</div>
            {vehicle.monthlyPayment && (
              <div className="text-lg text-gray-500">
                ${vehicle.monthlyPayment}/mo
              </div>
            )}
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {vehicle.carfaxAccidents === 0 && (
              <Badge className="bg-red-600">Clean Title</Badge>
            )}
            {vehicle.isSpecialOffer && (
              <Badge className="bg-red-600">Special Offer</Badge>
            )}
            {vehicle.isFeatured && (
              <Badge variant="outline">Featured</Badge>
            )}
          </div>
        </div>
        
        <div className="mt-4 sm:mt-0">
          <Button 
            onClick={handleAddToComparison}
            disabled={isInComparison(vehicle.id)}
            className="flex items-center gap-2"
          >
            <ChartBarStacked className="h-4 w-4" />
            {isInComparison(vehicle.id) ? "Added to Compare" : "Add to Compare"}
          </Button>
        </div>
      </div>
      
      {/* Vehicle specs and details */}
      <Tabs defaultValue="overview" className="mb-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="features">Features & Options</TabsTrigger>
          <TabsTrigger value="details">Vehicle Details</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="pt-4" style={{backgroundColor: 'white', padding: '16px', borderRadius: '8px', border: '1px solid #e5e7eb', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-12 gap-y-6">
            <div className="flex items-center gap-3">
              <Gauge className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Mileage</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.mileage.toLocaleString()} miles</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Year</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.year}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <PaintBucket className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Exterior Color</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.exteriorColor || "Not specified"}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Sofa className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Interior Color</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.interiorColor || "Not specified"}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Fuel className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Fuel Type</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.fuelType || "Not specified"}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Cog className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Transmission</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.transmission || "Not specified"}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Car className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Engine</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.engineSize || "Not specified"}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Truck className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>Drive Type</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.bodyStyle || "Not specified"}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Banknote className="h-5 w-5" style={{color: '#dc2626'}} />
              <div>
                <div className="text-sm" style={{color: '#4b5563'}}>VIN</div>
                <div className="font-medium" style={{color: 'black'}}>{vehicle.vin || "Not available"}</div>
              </div>
            </div>
          </div>
          
          <Separator className="my-6" />
          
          <div>
            <h3 className="text-lg font-bold mb-2 flex items-center gap-2" style={{color: 'black'}}>
              <Info className="h-5 w-5" style={{color: '#dc2626'}} />
              Description
            </h3>
            <p className="whitespace-pre-line" style={{color: '#111827'}}>{vehicle.description || "No description available for this vehicle."}</p>
          </div>
        </TabsContent>
        
        <TabsContent value="features" className="pt-4 vehicle-features-list" style={{backgroundColor: 'white', padding: '16px', borderRadius: '8px', border: '1px solid #e5e7eb', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
          <h3 className="text-lg font-bold mb-4" style={{color: 'black'}}>Features & Options</h3>
          {vehicle.features && vehicle.features.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {vehicle.features.map((feature, index) => (
                <div 
                  key={index} 
                  style={{
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '8px', 
                    backgroundColor: '#f3f4f6', 
                    padding: '8px', 
                    borderRadius: '6px',
                    marginBottom: '8px'
                  }}
                >
                  <div style={{
                    width: '12px', 
                    height: '12px', 
                    borderRadius: '50%', 
                    backgroundColor: '#dc2626', 
                    flexShrink: 0
                  }}></div>
                  <span style={{color: 'black', fontWeight: 600}}>{feature}</span>
                </div>
              ))}
            </div>
          ) : (
            <p style={{color: 'black', fontWeight: 500}}>No features specified for this vehicle.</p>
          )}
        </TabsContent>
        
        <TabsContent value="details" className="pt-4" style={{backgroundColor: 'white', padding: '16px', borderRadius: '8px', border: '1px solid #e5e7eb', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
          <h3 className="text-lg font-bold mb-4" style={{color: 'black'}}>Detailed Specifications</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="pt-6">
                <h4 className="font-bold mb-2" style={{color: 'black'}}>General Information</h4>
                <ul className="space-y-2">
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Make:</span> <span style={{color: 'black'}}>{vehicle.make}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Model:</span> <span style={{color: 'black'}}>{vehicle.model}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Year:</span> <span style={{color: 'black'}}>{vehicle.year}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Trim:</span> <span style={{color: 'black'}}>{vehicle.model || "Not specified"}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Body Style:</span> <span style={{color: 'black'}}>{vehicle.bodyStyle || "Not specified"}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>VIN:</span> <span style={{color: 'black'}}>{vehicle.vin || "Not available"}</span></li>
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <h4 className="font-bold mb-2" style={{color: 'black'}}>Mechanical</h4>
                <ul className="space-y-2">
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Engine:</span> <span style={{color: 'black'}}>{vehicle.engineSize || "Not specified"}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Transmission:</span> <span style={{color: 'black'}}>{vehicle.transmission || "Not specified"}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Drive Type:</span> <span style={{color: 'black'}}>{vehicle.bodyStyle || "Not specified"}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Fuel Type:</span> <span style={{color: 'black'}}>{vehicle.fuelType || "Not specified"}</span></li>
                  <li className="flex justify-between"><span style={{color: '#4b5563'}}>Mileage:</span> <span style={{color: 'black'}}>{vehicle.mileage.toLocaleString()} miles</span></li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* CarFax Section */}
      <CarfaxSection vehicle={vehicle} />
      
      {/* Call to action */}
      <Card className="bg-red-50 mt-8">
        <CardContent className="pt-6">
          <h3 className="text-xl font-bold mb-2 text-gray-900">Interested in this {vehicle.year} {vehicle.make} {vehicle.model}?</h3>
          <p className="text-gray-700 mb-4">
            Contact us today to schedule a test drive or get more information. 
            This {vehicle.make} won't be available for long!
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button size="lg" className="bg-red-600 hover:bg-red-700" asChild>
              <a href={`tel:+18001234567`}>Call Us</a>
            </Button>
            <Button size="lg" variant="outline" className="text-red-600 border-red-600 hover:bg-red-50">
              Schedule Test Drive
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VehicleDetails;
