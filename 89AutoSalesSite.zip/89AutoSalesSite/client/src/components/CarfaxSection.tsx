import { ClipboardCheck, Info, Calendar, User, AlertCircle, Wrench } from "lucide-react";
import { Vehicle } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CarfaxSectionProps {
  vehicle: Vehicle;
}

const CarfaxSection = ({ vehicle }: CarfaxSectionProps) => {
  // If no CarFax data is available
  if (!vehicle.carfaxLink) {
    return null;
  }

  const formatReportDate = (date: Date | null) => {
    if (!date) return "Not available";
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <Card className="mb-8 overflow-hidden border-red-500 bg-black text-white">
      <CardHeader className="bg-gradient-to-r from-red-700 to-red-500 py-4">
        <div className="flex items-center gap-3">
          <ClipboardCheck className="h-6 w-6" />
          <CardTitle className="text-xl">CARFAX Vehicle History</CardTitle>
        </div>
        <CardDescription className="text-white/80">
          VIN: {vehicle.vin}
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col items-center rounded-lg bg-gray-900 p-4 text-center">
            <Calendar className="mb-2 h-8 w-8 text-red-500" />
            <h3 className="text-sm font-medium text-gray-400">Report Date</h3>
            <p className="mt-1 text-lg font-semibold">{formatReportDate(vehicle.carfaxReportDate)}</p>
          </div>
          
          <div className="flex flex-col items-center rounded-lg bg-gray-900 p-4 text-center">
            <User className="mb-2 h-8 w-8 text-red-500" />
            <h3 className="text-sm font-medium text-gray-400">Previous Owners</h3>
            <p className="mt-1 text-lg font-semibold">
              {vehicle.carfaxOwners !== null ? vehicle.carfaxOwners : "Not available"}
            </p>
          </div>
          
          <div className="flex flex-col items-center rounded-lg bg-gray-900 p-4 text-center">
            <AlertCircle className="mb-2 h-8 w-8 text-red-500" />
            <h3 className="text-sm font-medium text-gray-400">Reported Accidents</h3>
            <div className="mt-1">
              {vehicle.carfaxAccidents === 0 ? (
                <Badge variant="outline" className="bg-green-500/20 text-green-300 hover:bg-green-500/30 hover:text-green-200">
                  No Accidents
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-yellow-500/20 text-yellow-300 hover:bg-yellow-500/30 hover:text-yellow-200">
                  {vehicle.carfaxAccidents} {vehicle.carfaxAccidents === 1 ? "Accident" : "Accidents"}
                </Badge>
              )}
            </div>
          </div>
          
          <div className="flex flex-col items-center rounded-lg bg-gray-900 p-4 text-center">
            <Wrench className="mb-2 h-8 w-8 text-red-500" />
            <h3 className="text-sm font-medium text-gray-400">Service Records</h3>
            <p className="mt-1 text-lg font-semibold">
              {vehicle.carfaxServiceRecords !== null ? vehicle.carfaxServiceRecords : "Not available"}
            </p>
          </div>
        </div>
        
        <div className="mt-6 flex items-center justify-between">
          <div className="flex items-center">
            <Info className="mr-2 h-5 w-5 text-blue-400" />
            <span className="text-sm text-gray-300">Full vehicle history available in the complete report</span>
          </div>
          <Button 
            variant="default" 
            className="bg-red-600 hover:bg-red-700"
            onClick={() => window.open(vehicle.carfaxLink || "#", "_blank")}
          >
            View Full CARFAX Report
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CarfaxSection;