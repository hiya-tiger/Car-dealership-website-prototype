import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

type VehicleARViewerProps = {
  vehicleName: string;
  arModelUrl?: string;
  modelScale?: number;
};

/**
 * Simple AR/3D viewer component that provides a link to view 3D models
 * without the complexity of rendering them directly in the page
 */
export function VehicleARViewer({ vehicleName, arModelUrl }: VehicleARViewerProps) {
  // If no AR model URL is provided, display a placeholder
  if (!arModelUrl) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>AR Experience</CardTitle>
          <CardDescription>View this vehicle in 3D</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground mb-4">
            3D model not available for this vehicle.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>3D Vehicle Viewer</CardTitle>
        <CardDescription>View this {vehicleName} in 3D and AR</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center py-6 bg-secondary/10 rounded-md mb-4">
          <p className="mb-4">Experience this vehicle in 3D or Augmented Reality</p>
          <img 
            src="/images/ar-placeholder.svg" 
            alt="AR Preview" 
            className="w-3/4 mx-auto mb-4 rounded-md"
            loading="lazy"
            onError={(e) => {
              // Removed console.log to improve performance
              // Create a more reliable fallback with a data URL that works in all browsers
              e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgMzAwIDIwMCI+PHJlY3QgZmlsbD0iIzMzMyIgd2lkdGg9IjMwMCIgaGVpZ2h0PSIyMDAiLz48dGV4dCBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjI0IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiB4PSIxNTAiIHk9IjEwMCI+M0QgUHJldmlldzwvdGV4dD48L3N2Zz4=';
            }}
          />
          <p className="text-sm text-muted-foreground mb-6">
            View this vehicle from all angles and place it in your environment
          </p>
        </div>
        
        <div className="mt-4 text-center">
          <p className="text-sm text-muted-foreground mb-2">
            On supported mobile devices, you can view this vehicle in your environment.
          </p>
          <a 
            href={`https://app.8thwall.com/model-viewer?url=${encodeURIComponent(arModelUrl)}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block"
          >
            <Button className="bg-primary text-white hover:bg-primary/90 w-full">
              View in AR
            </Button>
          </a>
          <p className="text-xs text-muted-foreground mt-2">
            Opens in a new window using your device camera
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

export default VehicleARViewer;