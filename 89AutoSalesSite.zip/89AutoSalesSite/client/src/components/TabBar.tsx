import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

interface TabBarProps {
  className?: string;
}

const TabBar = ({ className }: TabBarProps) => {
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState("home");

  // Update active tab based on current location
  useEffect(() => {
    if (location === "/") {
      setActiveTab("home");
    } else if (location.startsWith("/inventory")) {
      setActiveTab("inventory");
    } else if (location.startsWith("/financing")) {
      setActiveTab("financing");
    } else if (location.startsWith("/service")) {
      setActiveTab("service");
    } else if (location.startsWith("/buyer-resources")) {
      setActiveTab("resources");
    } else if (location.startsWith("/about")) {
      setActiveTab("about");
    }
  }, [location]);

  return (
    <div className={cn("w-full bg-black border-b border-gray-800", className)}>
      <div className="container mx-auto px-4">
        <Tabs value={activeTab} className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-6 bg-transparent w-full h-auto">
            <TabsTrigger 
              value="home" 
              className={cn(
                "data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3",
                "data-[state=active]:text-red-600 data-[state=active]:border-b-2 data-[state=active]:border-red-600",
                "text-white hover:text-red-600 transition-colors rounded-none"
              )}
              asChild
            >
              <Link href="/">Home</Link>
            </TabsTrigger>
            
            <TabsTrigger 
              value="inventory" 
              className={cn(
                "data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3",
                "data-[state=active]:text-red-600 data-[state=active]:border-b-2 data-[state=active]:border-red-600",
                "text-white hover:text-red-600 transition-colors rounded-none"
              )}
              asChild
            >
              <Link href="/inventory">Inventory</Link>
            </TabsTrigger>
            
            <TabsTrigger 
              value="financing" 
              className={cn(
                "data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3",
                "data-[state=active]:text-red-600 data-[state=active]:border-b-2 data-[state=active]:border-red-600",
                "text-white hover:text-red-600 transition-colors rounded-none"
              )}
              asChild
            >
              <Link href="/financing">Financing</Link>
            </TabsTrigger>
            
            <TabsTrigger 
              value="service" 
              className={cn(
                "data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3",
                "data-[state=active]:text-red-600 data-[state=active]:border-b-2 data-[state=active]:border-red-600",
                "text-white hover:text-red-600 transition-colors rounded-none"
              )}
              asChild
            >
              <Link href="/service">Service</Link>
            </TabsTrigger>
            
            <TabsTrigger 
              value="resources" 
              className={cn(
                "data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3",
                "data-[state=active]:text-red-600 data-[state=active]:border-b-2 data-[state=active]:border-red-600",
                "text-white hover:text-red-600 transition-colors rounded-none"
              )}
              asChild
            >
              <Link href="/buyer-resources">Buyer Resources</Link>
            </TabsTrigger>
            
            <TabsTrigger 
              value="about" 
              className={cn(
                "data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3",
                "data-[state=active]:text-red-600 data-[state=active]:border-b-2 data-[state=active]:border-red-600",
                "text-white hover:text-red-600 transition-colors rounded-none"
              )}
              asChild
            >
              <Link href="/about">About Us</Link>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
    </div>
  );
};

export default TabBar;