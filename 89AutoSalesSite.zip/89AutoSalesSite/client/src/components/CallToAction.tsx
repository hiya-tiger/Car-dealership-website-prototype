import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const CallToAction = () => {
  return (
    <section className="bg-primary">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-bold text-white mb-4">Ready to find your perfect vehicle?</h2>
            <p className="text-gray-100 text-lg mb-8 lg:mb-0">
              Browse our extensive inventory of premium used vehicles or contact our team for personalized assistance.
            </p>
          </div>
          <div className="flex flex-wrap gap-4">
            <Link href="/inventory">
              <Button className="bg-white text-primary hover:bg-gray-100 font-medium py-3 px-6 rounded-md transition-colors">
                Browse Inventory
              </Button>
            </Link>
            <Link href="/contact">
              <Button className="bg-accent hover:bg-accent-hover text-white font-medium py-3 px-6 rounded-md transition-colors">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
