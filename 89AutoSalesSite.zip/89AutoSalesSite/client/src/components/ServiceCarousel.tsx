import { useCallback, useEffect, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Car, Calendar, Wrench, CreditCard, BadgeDollarSign, RefreshCcw } from 'lucide-react';
import { Link } from 'wouter';

type ServiceItem = {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
  linkText: string;
  color: string;
  image: string;
};

const services: ServiceItem[] = [
  {
    id: 'inventory',
    title: 'Pre-Owned Inventory',
    description: 'Browse our extensive selection of quality pre-owned vehicles',
    icon: <Car className="h-10 w-10" />,
    link: '/inventory',
    linkText: 'Browse Inventory',
    color: 'bg-blue-600',
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'special-offers',
    title: 'Special Offers',
    description: 'Limited-time deals and exclusive savings opportunities',
    icon: <BadgeDollarSign className="h-10 w-10" />,
    link: '/inventory?special=true',
    linkText: 'View Specials',
    color: 'bg-red-600',
    image: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'trade-in',
    title: 'Trade-In Your Vehicle',
    description: 'Get a fair market appraisal and trade up to a newer model',
    icon: <RefreshCcw className="h-10 w-10" />,
    link: '/trade-in',
    linkText: 'Start Appraisal',
    color: 'bg-teal-600',
    image: 'https://images.unsplash.com/photo-1560574188-6a6774965120?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'service',
    title: 'Service Appointment',
    description: 'Quality maintenance and repairs from certified technicians',
    icon: <Wrench className="h-10 w-10" />,
    link: '/service',
    linkText: 'Book Service',
    color: 'bg-green-600',
    image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'test-drive',
    title: 'Test Drive',
    description: 'Schedule a test drive of your preferred vehicle',
    icon: <Calendar className="h-10 w-10" />,
    link: '/contact',
    linkText: 'Schedule Now',
    color: 'bg-purple-600',
    image: 'https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'financing',
    title: 'Financing Options',
    description: 'Flexible payment plans tailored to your budget',
    icon: <CreditCard className="h-10 w-10" />,
    link: '/financing',
    linkText: 'Apply Now',
    color: 'bg-orange-600',
    image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
  },
];

export function ServiceCarousel() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: 'start', slidesToScroll: 1 });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [prevBtnEnabled, setPrevBtnEnabled] = useState(false);
  const [nextBtnEnabled, setNextBtnEnabled] = useState(false);

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
    setPrevBtnEnabled(emblaApi.canScrollPrev());
    setNextBtnEnabled(emblaApi.canScrollNext());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);
    
    return () => {
      emblaApi.off('select', onSelect);
      emblaApi.off('reInit', onSelect);
    };
  }, [emblaApi, onSelect]);

  return (
    <div className="relative">
      {/* Main Carousel */}
      <div className="overflow-hidden rounded-lg" ref={emblaRef}>
        <div className="flex">
          {services.map((service) => (
            <div 
              className="flex-[0_0_100%] sm:flex-[0_0_50%] md:flex-[0_0_33.333%] lg:flex-[0_0_25%] p-2" 
              key={service.id}
            >
              <div className="bg-black border border-zinc-800 rounded-xl overflow-hidden h-full">
                <div className="h-40 relative overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.onerror = null; // Prevent infinite loop
                      target.src = '/images/placeholder-car.svg';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
                  <div className={`${service.color} h-2 w-full absolute top-0 left-0`}></div>
                </div>
                <div className="p-6">
                  <div className="text-red-600 mb-2 -mt-2">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
                  <p className="text-zinc-400 mb-4 h-12">{service.description}</p>
                  <Link href={service.link}>
                    <Button variant="outline" className="w-full bg-black text-white border-red-800 hover:bg-zinc-900 hover:text-red-500">
                      {service.linkText}
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Carousel Navigation */}
      <div className="absolute inset-0 flex items-center justify-between pointer-events-none">
        <Button 
          variant="outline" 
          size="icon" 
          className={cn(
            "h-10 w-10 ml-2 rounded-full bg-black/50 hover:bg-black text-white border-red-800 pointer-events-auto",
            !prevBtnEnabled && "opacity-50 cursor-not-allowed"
          )}
          onClick={scrollPrev}
          disabled={!prevBtnEnabled}
        >
          <ChevronLeft className="h-5 w-5" />
          <span className="sr-only">Previous slide</span>
        </Button>
        <Button 
          variant="outline" 
          size="icon" 
          className={cn(
            "h-10 w-10 mr-2 rounded-full bg-black/50 hover:bg-black text-white border-red-800 pointer-events-auto",
            !nextBtnEnabled && "opacity-50 cursor-not-allowed"
          )}
          onClick={scrollNext}
          disabled={!nextBtnEnabled}
        >
          <ChevronRight className="h-5 w-5" />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>
      
      {/* Dots Navigation */}
      <div className="flex justify-center mt-4 gap-2">
        {services.map((_, index) => (
          <button
            key={index}
            className={cn(
              "h-2 rounded-full transition-all",
              selectedIndex === index ? "w-4 bg-red-600" : "w-2 bg-zinc-600"
            )}
            onClick={() => emblaApi?.scrollTo(index)}
            type="button"
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}