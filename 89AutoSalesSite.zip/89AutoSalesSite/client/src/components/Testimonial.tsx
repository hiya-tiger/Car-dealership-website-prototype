import { Testimonial as TestimonialType } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialProps {
  testimonial: TestimonialType;
}

const Testimonial = ({ testimonial }: TestimonialProps) => {
  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(testimonial.rating);
    const hasHalfStar = testimonial.rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <svg key={`star-${i}`} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
        </svg>
      );
    }
    
    if (hasHalfStar) {
      stars.push(
        <svg key="half-star" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 17.8 5.8 21 7 14.1 2 9.3l7-1 3-6.1 3 6.1 7 1-5 4.8 1.2 6.9-6.2-3.2z"></path>
          <path d="M12 2v16" fill="none" stroke="#fff" strokeWidth="1" opacity="0.5"></path>
        </svg>
      );
    }
    
    const emptyStars = 5 - Math.ceil(testimonial.rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <svg key={`empty-star-${i}`} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
        </svg>
      );
    }
    
    return stars;
  };

  return (
    <Card className="bg-zinc-900 border border-red-600/30 rounded-lg shadow-md p-6 relative">
      <CardContent className="p-0">
        <div className="text-red-600 text-4xl opacity-20 absolute top-4 left-4">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path>
            <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path>
          </svg>
        </div>
        <div className="relative z-10">
          <div className="flex items-center mb-4">
            <div className="text-yellow-400 flex">
              {renderStars()}
            </div>
            <span className="ml-2 text-gray-300">{testimonial.rating.toFixed(1)}</span>
          </div>
          <p className="text-gray-300 mb-6">{testimonial.review}</p>
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full overflow-hidden mr-4 border border-red-600/50">
              <img src={testimonial.imageUrl || 'https://randomuser.me/api/portraits/lego/1.jpg'} 
                alt={testimonial.name} 
                className="w-full h-full object-cover" />
            </div>
            <div>
              <h4 className="font-semibold text-white">{testimonial.name}</h4>
              <p className="text-sm text-gray-400">Purchased a {testimonial.vehicle}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Testimonial;
