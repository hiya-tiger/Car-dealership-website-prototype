import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck, Handshake, RotateCcw, Shield } from "lucide-react";

const WhyChooseUs = () => {
  const features = [
    {
      icon: <ShieldCheck className="text-blue-600 text-2xl" />,
      title: "Certified Vehicles",
      description: "Every vehicle undergoes a rigorous 150-point inspection before being listed."
    },
    {
      icon: <Handshake className="text-blue-600 text-2xl" />,
      title: "No-Haggle Pricing",
      description: "Fair, transparent pricing without the stress of negotiation."
    },
    {
      icon: <RotateCcw className="text-blue-600 text-2xl" />,
      title: "7-Day Returns",
      description: "Not happy? Return within 7 days or 250 miles for a full refund."
    },
    {
      icon: <Shield className="text-blue-600 text-2xl" />,
      title: "Warranty Options",
      description: "Vehicles are sold as-is with optional warranty packages available for purchase."
    }
  ];

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-4">Why Choose 89 Autosales</h2>
        <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">
          We're committed to providing the best car buying experience with quality vehicles and transparent pricing.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="bg-white shadow-md">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
