import { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, useGLTF, Environment, ContactShadows } from '@react-three/drei';
import { Suspense } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Expand, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';
import * as THREE from 'three';

// Sample car models that will be used for demonstration
const carModels = {
  1: '/models/sedan.glb',
  2: '/models/suv.glb', 
  3: '/models/truck.glb',
  4: '/models/sports.glb',
  5: '/models/luxury.glb',
  6: '/models/compact.glb'
};

// Fallback model for vehicles without a specific model
const defaultModel = '/models/sedan.glb';

interface ModelViewerProps {
  vehicleId: number;
  className?: string;
  fullWidth?: boolean;
}

// The car model component
function CarModel({ url }: { url: string }) {
  const groupRef = useRef<THREE.Group>(null);
  const { scene } = useGLTF(url);
  const { camera } = useThree();
  
  // Auto-rotation effect
  useFrame((_state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.2;
    }
  });

  // Position camera on load
  useEffect(() => {
    if (camera && groupRef.current) {
      camera.position.set(5, 3, 5);
      camera.lookAt(0, 0, 0);
    }
  }, [camera]);

  return (
    <group ref={groupRef}>
      <primitive object={scene} scale={1.5} position={[0, -1, 0]} />
    </group>
  );
}

// Loading fallback
function LoadingFallback() {
  return (
    <div className="h-full w-full flex items-center justify-center bg-black/5">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-sm text-muted-foreground">Loading 3D Model...</p>
      </div>
    </div>
  );
}

const ModelViewer = ({ vehicleId, className, fullWidth = false }: ModelViewerProps) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<any>(null);
  
  // Get the appropriate model URL based on vehicle ID
  const modelUrl = carModels[vehicleId as keyof typeof carModels] || defaultModel;

  const resetCamera = () => {
    if (controlsRef.current) {
      controlsRef.current.reset();
    }
  };

  // Handle fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  // Listen for fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  return (
    <Card className={cn("overflow-hidden", className, fullWidth ? "w-full" : "")}>
      <CardContent className="p-0 relative">
        <div 
          ref={containerRef}
          className={cn(
            "relative w-full", 
            isFullscreen ? "h-screen" : "h-[400px]"
          )}
        >
          <div className="absolute top-2 right-2 z-10 flex gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="bg-white/80 hover:bg-white"
              onClick={resetCamera}
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="bg-white/80 hover:bg-white"
              onClick={toggleFullscreen}
            >
              <Expand className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Placeholder until we have actual model files */}
          <div className="h-full w-full flex items-center justify-center bg-gradient-to-b from-gray-800 to-gray-900">
            <div className="text-center max-w-md p-6 bg-gray-900/80 rounded-lg backdrop-blur-sm border border-gray-700">
              <h3 className="text-lg font-semibold mb-2 text-white">3D Exterior View</h3>
              <p className="text-sm text-gray-300 mb-4">
                Explore the {vehicleId === 2 ? 'Honda Accord' : 'vehicle'} in 3D. In a production environment, 
                this would load a detailed 3D model of the vehicle's exterior that you can rotate and explore.
              </p>
              <div className="text-xs text-gray-400">
                Vehicle ID: {vehicleId}
              </div>
            </div>
          </div>
          
          {/* 3D Model viewer - commented out until model files are available */}
          {/* 
          <Suspense fallback={<LoadingFallback />}>
            <Canvas shadows>
              <ambientLight intensity={0.5} />
              <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
              <pointLight position={[-10, -10, -10]} intensity={0.5} />
              
              <PerspectiveCamera makeDefault position={[5, 3, 5]} fov={50} />
              
              <CarModel url={modelUrl} />
              
              <Environment preset="city" />
              <ContactShadows 
                position={[0, -1.5, 0]} 
                opacity={0.4} 
                scale={15} 
                blur={2.5} 
                far={5} 
              />
              
              <OrbitControls 
                ref={controlsRef}
                enablePan={false}
                minDistance={3}
                maxDistance={10}
                minPolarAngle={Math.PI / 6}
                maxPolarAngle={Math.PI / 2}
              />
            </Canvas>
          </Suspense>
          */}
          
          <div className="absolute bottom-2 left-0 right-0 text-center">
            <p className="text-xs text-white font-medium bg-black/70 py-1.5 rounded-full mx-auto w-fit px-5 shadow-md">
              Drag to rotate • Scroll to zoom • Double-click to reset
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ModelViewer;