import { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, useGLTF, Environment } from '@react-three/drei';
import { Suspense } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Expand, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';
import * as THREE from 'three';

// Sample car interior models for demonstration
const interiorModels = {
  1: '/models/sedan-interior.glb',
  2: '/models/suv-interior.glb',
  3: '/models/truck-interior.glb',
  4: '/models/sports-interior.glb',
  5: '/models/luxury-interior.glb',
  6: '/models/compact-interior.glb'
};

// Fallback model for vehicles without a specific interior model
const defaultInteriorModel = '/models/sedan-interior.glb';

interface InteriorViewerProps {
  vehicleId: number;
  className?: string;
  fullWidth?: boolean;
}

// The car interior model component
function CarInterior({ url }: { url: string }) {
  const { scene } = useGLTF(url);
  const { camera } = useThree();
  
  // Position camera on load to be inside the car
  useEffect(() => {
    if (camera) {
      // Position the camera in the driver's seat
      camera.position.set(0, 0.8, 0);
      camera.lookAt(0.5, 0.8, -1); // Looking toward the dashboard
    }
  }, [camera]);

  return (
    <group>
      <primitive object={scene} scale={1} position={[0, 0, 0]} />
    </group>
  );
}

// Loading fallback
function LoadingFallback() {
  return (
    <div className="h-full w-full flex items-center justify-center bg-black/5">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-sm text-muted-foreground">Loading Interior View...</p>
      </div>
    </div>
  );
}

const InteriorViewer = ({ vehicleId, className, fullWidth = false }: InteriorViewerProps) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<any>(null);
  
  // Get the appropriate model URL based on vehicle ID
  const modelUrl = interiorModels[vehicleId as keyof typeof interiorModels] || defaultInteriorModel;

  const resetCamera = () => {
    if (controlsRef.current) {
      controlsRef.current.reset();
    }
  };

  // Handle fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  // Listen for fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Simple placeholder for when we don't have actual interior models
  const renderPlaceholder = () => {
    return (
      <div className="h-full w-full flex items-center justify-center bg-gradient-to-b from-gray-800 to-gray-900">
        <div className="text-center max-w-md p-6 bg-gray-900/80 rounded-lg backdrop-blur-sm border border-gray-700">
          <h3 className="text-lg font-semibold mb-2 text-white">Interior View</h3>
          <p className="text-sm text-gray-300 mb-4">
            Explore the vehicle's interior in 360°. In a production implementation, 
            this would load a detailed 3D model of the vehicle's interior.
          </p>
          <div className="text-xs text-gray-400">
            Vehicle ID: {vehicleId}
          </div>
        </div>
      </div>
    );
  };

  return (
    <Card className={cn("overflow-hidden", className, fullWidth ? "w-full" : "")}>
      <CardContent className="p-0 relative">
        <div 
          ref={containerRef}
          className={cn(
            "relative w-full", 
            isFullscreen ? "h-screen" : "h-[400px]"
          )}
        >
          <div className="absolute top-2 right-2 z-10 flex gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="bg-white/80 hover:bg-white"
              onClick={resetCamera}
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="bg-white/80 hover:bg-white"
              onClick={toggleFullscreen}
            >
              <Expand className="h-4 w-4" />
            </Button>
          </div>
          
          {/* We're showing a placeholder until we have actual interior models */}
          {renderPlaceholder()}
          
          {/* When we have real models, we'd use this instead */}
          {/* 
          <Suspense fallback={<LoadingFallback />}>
            <Canvas shadows>
              <ambientLight intensity={0.3} />
              <pointLight position={[0, 1.5, 0]} intensity={0.5} />
              <pointLight position={[1, 0.5, 1]} intensity={0.3} />
              
              <PerspectiveCamera makeDefault position={[0, 0.8, 0]} fov={75} />
              
              <CarInterior url={modelUrl} />
              
              <Environment preset="sunset" />
              
              <OrbitControls 
                ref={controlsRef}
                enablePan={false}
                minDistance={0.5}
                maxDistance={2}
                minPolarAngle={Math.PI / 4}
                maxPolarAngle={Math.PI / 1.5}
              />
            </Canvas>
          </Suspense> 
          */}
          
          <div className="absolute bottom-2 left-0 right-0 text-center">
            <p className="text-xs text-white font-medium bg-black/70 py-1.5 rounded-full mx-auto w-fit px-5 shadow-md">
              Drag to look around • Pinch to zoom • Double-click to reset view
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InteriorViewer;