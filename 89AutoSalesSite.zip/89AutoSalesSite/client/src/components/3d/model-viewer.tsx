import { useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

// This component uses Three.js for 3D rendering
// You'll need to install @types/three and three packages
interface ModelViewerProps {
  modelUrl: string;
  alt?: string;
  className?: string;
  autoRotate?: boolean;
  controlsEnabled?: boolean;
}

const ModelViewer = ({
  modelUrl,
  alt = "3D model",
  className,
  autoRotate = true,
  controlsEnabled = true,
}: ModelViewerProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // When implementing with Three.js, you would initialize the scene here
    // For now, we'll display a placeholder message
    const container = containerRef.current;
    container.innerHTML = 
      `<div class="w-full h-full flex items-center justify-center bg-muted/20 rounded-md">
        <div class="text-center p-4">
          <h3 class="text-lg font-medium mb-2">3D Model Viewer</h3>
          <p class="text-sm text-muted-foreground">
            This is a placeholder for the 3D model viewer. In a production implementation, 
            this would render a 3D model of the vehicle using Three.js or a similar library.
          </p>
          <p class="mt-4 text-xs text-muted-foreground">
            Model URL: ${modelUrl}
          </p>
        </div>
      </div>`;

    return () => {
      // Clean up Three.js resources when component unmounts
      container.innerHTML = '';
    };
  }, [modelUrl, autoRotate, controlsEnabled]);

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-0">
        <div 
          ref={containerRef} 
          className="w-full h-[400px]" 
          aria-label={alt}
          role="img"
        />
      </CardContent>
    </Card>
  );
};

export default ModelViewer;