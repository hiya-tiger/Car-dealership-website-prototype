import { useState } from "react";
import { Link } from "wouter";
import { Vehicle } from "@shared/schema";

interface VehicleCardProps {
  vehicle: Vehicle;
  onCompareClick?: (vehicle: Vehicle) => void;
}

const VehicleCard = ({ vehicle, onCompareClick }: VehicleCardProps) => {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const handleCompareClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onCompareClick) {
      onCompareClick(vehicle);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const formatMileage = (mileage: number) => {
    return new Intl.NumberFormat('en-US').format(mileage);
  };

  const isSold = vehicle.status === "sold";

  return (
    <div className={`vehicle-card bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 ${isSold ? 'relative' : ''}`}>
      <div className="relative">
        <img 
          src={vehicle.images && vehicle.images.length > 0 ? vehicle.images[0] : '/images/placeholder-car.svg'} 
          alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`} 
          className={`w-full h-48 object-cover ${isSold ? 'opacity-70' : ''}`}
          loading="lazy"
          decoding="async"
          onError={(e) => {
            // Remove console.log to reduce overhead
            const target = e.target as HTMLImageElement;
            target.onerror = null; // Prevent infinite loop
            target.src = '/images/placeholder-car.svg';
            target.className = `w-full h-48 object-contain p-4 bg-gray-100 ${isSold ? 'opacity-70' : ''}`;
          }}
        />
        
        {/* Add sold overlay if vehicle is sold */}
        {isSold && (
          <div className="absolute inset-0 flex items-center justify-center z-10">
            <div className="bg-black bg-opacity-60 rounded-full px-12 py-3 transform rotate-[-20deg]">
              <span className="text-white text-2xl font-bold tracking-wider">SOLD</span>
            </div>
          </div>
        )}
        
        {/* Status badges */}
        {vehicle.status === "sold" && (
          <div className="absolute top-0 left-0 bg-black text-white px-3 py-1 rounded-br-md font-medium text-sm shadow-sm">
            Sold
          </div>
        )}
        
        {vehicle.status !== "sold" && vehicle.isFeatured && (
          <div className="absolute top-0 left-0 bg-red-600 text-white px-3 py-1 rounded-br-md font-medium text-sm shadow-sm">
            Featured
          </div>
        )}
        
        {vehicle.status !== "sold" && vehicle.isSpecialOffer && (
          <div className="absolute top-0 left-0 bg-blue-600 text-white px-3 py-1 rounded-br-md font-medium text-sm shadow-sm">
            Special Offer
          </div>
        )}
        
        <button 
          className={`absolute top-2 right-2 bg-white bg-opacity-90 shadow-sm ${isFavorite ? 'text-red-600' : 'text-neutral-700 hover:text-red-600'} p-2 rounded-full transition-colors`} 
          aria-label="Add to favorites"
          onClick={toggleFavorite}
        >
          {isFavorite ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
            </svg>
          )}
        </button>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-neutral-900 mb-1">
          {vehicle.year} {vehicle.make} {vehicle.model}
        </h3>
        <p className="text-neutral-700 text-sm mb-2 font-medium">
          {formatMileage(vehicle.mileage)} miles
        </p>
        
        <div className="flex justify-between items-center mb-3">
          <span className="text-xl font-bold text-neutral-900">{formatPrice(vehicle.price)}</span>
          {vehicle.monthlyPayment && (
            <span className="text-sm text-neutral-700 font-medium">${vehicle.monthlyPayment}/mo*</span>
          )}
        </div>
        
        <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
          <div className="flex items-center text-neutral-800 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-red-600">
              <path d="M6 10c0 1.1.9 2 2 2s2-.9 2-2-.9-2-2-2-2 .9-2 2Z"></path>
              <path d="M15 13a3 3 0 0 1 3-3h0a3 3 0 0 1 3 3v2"></path>
              <path d="M10 3.5a5.1 5.1 0 0 0-4 2 7.2 7.2 0 0 0-1 7 6 6 0 0 0 3 3l3 1 7 2 5-5c-3-3-3-10-10-10Z"></path>
              <path d="M15.8 20.2c-1.1 1.3-3.3 1.3-5.5.1-3.5-1.9-6.6-5-8.3-8.7a5.1 5.1 0 0 1 .4-4.8 4.5 4.5 0 0 1 3.6-2.3"></path>
            </svg>
            {vehicle.mpgCity}/{vehicle.mpgHighway} MPG
          </div>
          <div className="flex items-center text-neutral-800 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-red-600">
              <path d="m8 6 4-4 4 4"></path>
              <path d="M12 2v10.3a4 4 0 0 1-1.172 2.872L4 22"></path>
              <path d="m20 22-5-5"></path>
            </svg>
            {vehicle.horsepower} HP
          </div>
          <div className="flex items-center text-neutral-800 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-red-600">
              <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.6-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.5 2.8C1.4 11.3 1 12.1 1 13v3c0 .6.4 1 1 1h1"></path>
              <circle cx="6" cy="17" r="2"></circle>
              <path d="M9 17h6"></path>
              <circle cx="18" cy="17" r="2"></circle>
            </svg>
            {vehicle.bodyStyle}
          </div>
          <div className="flex items-center text-neutral-800 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-red-600">
              <circle cx="13.5" cy="6.5" r=".5"></circle>
              <circle cx="17.5" cy="10.5" r=".5"></circle>
              <circle cx="8.5" cy="7.5" r=".5"></circle>
              <circle cx="6.5" cy="12.5" r=".5"></circle>
              <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>
            </svg>
            {vehicle.exteriorColor}
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Link href={`/vehicles/${vehicle.id}`} className="flex-1 bg-red-600 hover:bg-red-700 text-white text-center py-2 rounded font-medium transition-colors">
            View Details
          </Link>
          <button 
            className="bg-gray-200 hover:bg-gray-300 text-neutral-800 px-3 py-2 rounded transition-colors" 
            aria-label="Compare"
            onClick={handleCompareClick}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 19h-8.2a3 3 0 0 0-2.2-2.2V4"></path>
              <path d="M13.8 19a3 3 0 0 1 2.2-2.2V4"></path>
              <path d="M4 19h8.2"></path>
              <path d="M4 15h8.2"></path>
              <path d="M4 11h8.2"></path>
              <path d="M4 7h8.2"></path>
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default VehicleCard;
