import { useEffect, useState } from "react";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger,
  SheetFooter,
  SheetClose
} from "@/components/ui/sheet";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, ChartBar } from "lucide-react";
import { useVehicleComparison } from "@/hooks/useVehicleComparison";
import { Link } from "wouter";
import { Vehicle } from "@shared/schema";

const CompareVehicles = () => {
  const { comparisonList, removeFromComparison, clearComparison } = useVehicleComparison();
  const [open, setOpen] = useState(false);
  
  // Close the sheet when the comparison list is empty
  useEffect(() => {
    if (comparisonList.length === 0 && open) {
      setOpen(false);
    }
  }, [comparisonList, open]);

  // Get all unique feature keys from all vehicles
  const getFeatureSets = () => {
    // Standard specs that are always displayed in this order
    const standardSpecs = ['make', 'model', 'year', 'trim', 'price', 'mileage', 'exteriorColor', 'interiorColor', 'fuelType', 'transmission', 'engine', 'driveType', 'bodyStyle'];
    
    // Initialize with standard specs
    const specSets = [
      { title: 'Make', key: 'make' },
      { title: 'Model', key: 'model' },
      { title: 'Year', key: 'year' },
      { title: 'Trim', key: 'trim' },
      { title: 'Price', key: 'price' },
      { title: 'Mileage', key: 'mileage' },
      { title: 'Exterior Color', key: 'exteriorColor' },
      { title: 'Interior Color', key: 'interiorColor' },
      { title: 'Fuel Type', key: 'fuelType' },
      { title: 'Transmission', key: 'transmission' },
      { title: 'Engine', key: 'engine' },
      { title: 'Drive Type', key: 'driveType' },
      { title: 'Body Style', key: 'bodyStyle' },
    ];
    
    return specSets;
  };
  
  // Format value for display
  const formatValue = (vehicle: Vehicle, key: string) => {
    if (!vehicle) return 'N/A';
    
    if (key === 'price') {
      return vehicle[key] ? `$${parseInt(vehicle[key].toString()).toLocaleString()}` : 'N/A';
    }
    
    if (key === 'mileage') {
      return vehicle[key] ? `${vehicle[key].toLocaleString()} miles` : 'N/A';
    }
    
    if (key === 'certified' || key === 'featured' || key === 'specialOffer') {
      return vehicle[key] ? 'Yes' : 'No';
    }
    
    return vehicle[key]?.toString() || 'N/A';
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button 
          variant="outline" 
          className="fixed bottom-4 right-4 z-50 shadow-lg flex items-center gap-2"
          onClick={() => setOpen(true)}
          disabled={comparisonList.length === 0}
        >
          <ChartBar className="h-4 w-4" />
          Compare
          {comparisonList.length > 0 && (
            <Badge variant="secondary" className="ml-1">{comparisonList.length}</Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="bottom" className="h-[80vh] sm:max-w-full">
        <SheetHeader>
          <SheetTitle className="text-xl">Compare Vehicles</SheetTitle>
        </SheetHeader>
        
        {comparisonList.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-lg text-gray-600 mb-4">No vehicles added to comparison</p>
            <Button asChild variant="default">
              <Link href="/inventory">Browse Inventory</Link>
            </Button>
          </div>
        ) : (
          <div className="mt-6 overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-48 sticky left-0 bg-white">Specifications</TableHead>
                  {comparisonList.map((vehicle) => (
                    <TableHead key={vehicle.id} className="min-w-[200px]">
                      <div className="flex flex-col items-center">
                        <div className="w-full h-24 mb-2 overflow-hidden rounded-md">
                          <img 
                            src={vehicle.images[0] || "https://placehold.co/600x400?text=No+Image"} 
                            alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="font-bold">{vehicle.year} {vehicle.make}</div>
                        <div>{vehicle.model} {vehicle.trim}</div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="mt-2"
                          onClick={() => removeFromComparison(vehicle.id)}
                        >
                          <X className="h-4 w-4 mr-1" /> Remove
                        </Button>
                      </div>
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {getFeatureSets().map((spec) => (
                  <TableRow key={spec.key}>
                    <TableCell className="font-medium sticky left-0 bg-white">{spec.title}</TableCell>
                    {comparisonList.map((vehicle) => (
                      <TableCell key={`${vehicle.id}-${spec.key}`}>
                        {formatValue(vehicle, spec.key)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
        
        <SheetFooter className="mt-6">
          <div className="flex justify-between w-full">
            <Button 
              variant="outline" 
              onClick={clearComparison}
              disabled={comparisonList.length === 0}
            >
              Clear All
            </Button>
            <SheetClose asChild>
              <Button>Close</Button>
            </SheetClose>
          </div>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
};

export default CompareVehicles;
