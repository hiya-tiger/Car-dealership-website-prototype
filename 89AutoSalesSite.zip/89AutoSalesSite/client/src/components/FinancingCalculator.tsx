import { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

const FinancingCalculator = () => {
  const [vehiclePrice, setVehiclePrice] = useState(25000);
  const [downPayment, setDownPayment] = useState(5000);
  const [loanTerm, setLoanTerm] = useState(60);
  const [interestRate, setInterestRate] = useState(4.5);
  const [monthlyPayment, setMonthlyPayment] = useState(0);

  useEffect(() => {
    calculatePayment();
  }, [vehiclePrice, downPayment, loanTerm, interestRate]);

  const calculatePayment = () => {
    const principal = vehiclePrice - downPayment;
    const monthlyRate = interestRate / 100 / 12;
    const termMonths = parseInt(loanTerm.toString());
    
    if (principal > 0 && monthlyRate > 0 && termMonths > 0) {
      const payment = principal * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
      setMonthlyPayment(Math.round(payment));
    } else {
      setMonthlyPayment(0);
    }
  };

  const handleVehiclePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setVehiclePrice(isNaN(value) ? 0 : value);
  };

  const handleDownPaymentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setDownPayment(isNaN(value) ? 0 : value);
  };

  const handleInterestRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setInterestRate(isNaN(value) ? 0 : value);
  };

  return (
    <div className="bg-gray-50 rounded-lg shadow-md p-6 lg:p-8">
      <h3 className="text-2xl font-semibold text-neutral-900 mb-6">Payment Calculator</h3>
      
      <div className="space-y-4 mb-6">
        <div>
          <Label htmlFor="vehicle-price" className="block text-sm font-medium text-neutral-700 mb-1">
            Vehicle Price
          </Label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-neutral-500">$</span>
            </div>
            <Input
              type="number"
              id="vehicle-price"
              value={vehiclePrice}
              onChange={handleVehiclePriceChange}
              className="pl-8 bg-white text-neutral-800 border-gray-300"
            />
          </div>
        </div>
        
        <div>
          <Label htmlFor="down-payment" className="block text-sm font-medium text-neutral-700 mb-1">
            Down Payment
          </Label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-neutral-500">$</span>
            </div>
            <Input
              type="number"
              id="down-payment"
              value={downPayment}
              onChange={handleDownPaymentChange}
              className="pl-8 bg-white text-neutral-800 border-gray-300"
            />
          </div>
        </div>
        
        <div>
          <Label htmlFor="loan-term" className="block text-sm font-medium text-neutral-700 mb-1">
            Loan Term (months)
          </Label>
          <Select value={loanTerm.toString()} onValueChange={(value) => setLoanTerm(parseInt(value))}>
            <SelectTrigger id="loan-term" className="bg-white text-neutral-800 border-gray-300">
              <SelectValue placeholder="Select term" />
            </SelectTrigger>
            <SelectContent className="bg-white text-neutral-800 border-gray-300">
              <SelectItem value="36" className="text-neutral-800 hover:bg-gray-100">36 months</SelectItem>
              <SelectItem value="48" className="text-neutral-800 hover:bg-gray-100">48 months</SelectItem>
              <SelectItem value="60" className="text-neutral-800 hover:bg-gray-100">60 months</SelectItem>
              <SelectItem value="72" className="text-neutral-800 hover:bg-gray-100">72 months</SelectItem>
              <SelectItem value="84" className="text-neutral-800 hover:bg-gray-100">84 months</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="interest-rate" className="block text-sm font-medium text-neutral-700 mb-1">
            Interest Rate (%)
          </Label>
          <Input
            type="number"
            id="interest-rate"
            value={interestRate}
            onChange={handleInterestRateChange}
            step="0.1"
            className="bg-white text-neutral-800 border-gray-300"
          />
        </div>
      </div>
      
      <Card className="bg-white rounded-md p-4 border border-gray-200 shadow-sm">
        <CardContent className="p-0">
          <div className="flex justify-between items-center">
            <span className="text-neutral-800 font-medium">Estimated Monthly Payment:</span>
            <span className="text-2xl font-bold text-red-600">
              ${monthlyPayment}
            </span>
          </div>
        </CardContent>
      </Card>
      
      <div className="mt-4 text-sm text-neutral-500 text-center">
        For estimation purposes only. Actual rates and terms may vary.
      </div>
    </div>
  );
};

export default FinancingCalculator;
