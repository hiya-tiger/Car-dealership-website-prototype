import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const QuickSearch = () => {
  const [make, setMake] = useState<string>("all");
  const [model, setModel] = useState<string>("all");
  const [price, setPrice] = useState<string>("no-limit");

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-primary text-xl font-semibold mb-4">Quick Search</h2>
      <form className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="make" className="block text-sm font-medium text-neutral-700 mb-1">Make</Label>
            <Select value={make} onValueChange={setMake}>
              <SelectTrigger id="make" className="w-full">
                <SelectValue placeholder="All Makes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Makes</SelectItem>
                <SelectItem value="Toyota">Toyota</SelectItem>
                <SelectItem value="Honda">Honda</SelectItem>
                <SelectItem value="Ford">Ford</SelectItem>
                <SelectItem value="BMW">BMW</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="model" className="block text-sm font-medium text-neutral-700 mb-1">Model</Label>
            <Select value={model} onValueChange={setModel} disabled={make === "all"}>
              <SelectTrigger id="model" className="w-full">
                <SelectValue placeholder={make !== "all" ? "Select Model" : "Select Make First"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Models</SelectItem>
                <SelectItem value="Camry">Camry</SelectItem>
                <SelectItem value="Corolla">Corolla</SelectItem>
                <SelectItem value="RAV4">RAV4</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="price" className="block text-sm font-medium text-neutral-700 mb-1">Max Price</Label>
            <Select value={price} onValueChange={setPrice}>
              <SelectTrigger id="price" className="w-full">
                <SelectValue placeholder="No Limit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no-limit">No Limit</SelectItem>
                <SelectItem value="10000">$10,000</SelectItem>
                <SelectItem value="20000">$20,000</SelectItem>
                <SelectItem value="30000">$30,000</SelectItem>
                <SelectItem value="40000">$40,000</SelectItem>
                <SelectItem value="50000">$50,000</SelectItem>
                <SelectItem value="75000">$75,000</SelectItem>
                <SelectItem value="100000">$100,000+</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Link href="/inventory">
            <Button type="submit" className="bg-accent hover:bg-accent-hover text-white font-medium py-2 px-6 rounded-md transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
              </svg>
              Search Inventory
            </Button>
          </Link>
        </div>
      </form>
    </div>
  );
};

export default QuickSearch;
