import { useState, useEffect, useCallback } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import type { EmblaCarouselType } from 'embla-carousel';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

type CarouselProps = {
  images: string[];
  className?: string;
  options?: Parameters<typeof useEmblaCarousel>[0];
  showThumbs?: boolean;
};

export function Carousel({ images, className, options, showThumbs = true }: CarouselProps) {
  const [emblaRef, emblaApi] = useEmblaCarousel(options);
  const [thumbsRef, thumbsApi] = useEmblaCarousel({ containScroll: 'keepSnaps', dragFree: true });
  
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [prevBtnEnabled, setPrevBtnEnabled] = useState(false);
  const [nextBtnEnabled, setNextBtnEnabled] = useState(false);

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);
  const scrollTo = useCallback((index: number) => emblaApi && emblaApi.scrollTo(index), [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
    setPrevBtnEnabled(emblaApi.canScrollPrev());
    setNextBtnEnabled(emblaApi.canScrollNext());
    
    // Sync thumbs with main carousel
    if (thumbsApi) {
      thumbsApi.scrollTo(emblaApi.selectedScrollSnap());
    }
  }, [emblaApi, thumbsApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);
    
    return () => {
      emblaApi.off('select', onSelect);
      emblaApi.off('reInit', onSelect);
    };
  }, [emblaApi, onSelect]);

  if (!images || images.length === 0) {
    return (
      <div className="w-full h-64 bg-gray-100 flex items-center justify-center rounded-lg">
        <p className="text-gray-500">No images available</p>
      </div>
    );
  }

  return (
    <div className={cn("relative", className)}>
      {/* Main Carousel */}
      <div className="overflow-hidden rounded-lg" ref={emblaRef}>
        <div className="flex">
          {images.map((image, index) => (
            <div className="flex-[0_0_100%]" key={index}>
              <div className="aspect-video relative overflow-hidden rounded-lg">
                <img 
                  src={image} 
                  alt={`Image ${index + 1}`} 
                  className="w-full h-full object-cover"
                  loading="lazy"
                  decoding="async"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.onerror = null; // Prevent infinite loop
                    target.src = '/images/placeholder-car.svg';
                    target.className = "w-full h-full object-contain p-6 bg-gray-100";
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Carousel Navigation */}
      <div className="absolute inset-0 flex items-center justify-between pointer-events-none">
        <Button 
          variant="outline" 
          size="icon" 
          className={cn(
            "h-8 w-8 ml-2 rounded-full bg-white/80 hover:bg-white pointer-events-auto",
            !prevBtnEnabled && "opacity-50 cursor-not-allowed"
          )}
          onClick={scrollPrev}
          disabled={!prevBtnEnabled}
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous slide</span>
        </Button>
        <Button 
          variant="outline" 
          size="icon" 
          className={cn(
            "h-8 w-8 mr-2 rounded-full bg-white/80 hover:bg-white pointer-events-auto",
            !nextBtnEnabled && "opacity-50 cursor-not-allowed"
          )}
          onClick={scrollNext}
          disabled={!nextBtnEnabled}
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>
      
      {/* Thumbnail Navigation */}
      {showThumbs && images.length > 1 && (
        <div className="mt-2">
          <div className="overflow-hidden" ref={thumbsRef}>
            <div className="flex gap-2 mt-2">
              {images.map((image, index) => (
                <button
                  key={index}
                  className={cn(
                    "relative flex-[0_0_20%] min-w-0 aspect-video rounded-md overflow-hidden transition-all",
                    selectedIndex === index ? "ring-2 ring-primary" : "ring-0 opacity-70"
                  )}
                  onClick={() => scrollTo(index)}
                  type="button"
                >
                  <img 
                    src={image} 
                    alt={`Thumbnail ${index + 1}`} 
                    className="w-full h-full object-cover"
                    loading="lazy"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.onerror = null; // Prevent infinite loop
                      target.src = '/images/placeholder-car.svg';
                      target.className = "w-full h-full object-contain p-1 bg-gray-100";
                    }}
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
      
      {/* Image Counter */}
      <div className="absolute bottom-2 right-2 bg-black/50 text-white text-xs px-2 py-1 rounded-full">
        {selectedIndex + 1} / {images.length}
      </div>
    </div>
  );
}