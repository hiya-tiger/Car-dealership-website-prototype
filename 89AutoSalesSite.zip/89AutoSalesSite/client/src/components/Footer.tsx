import { Link } from "wouter";
import { FaCertificate, FaShieldAlt, FaCarAlt, FaFileAlt } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-black text-gray-300">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h3 className="text-red-600 text-xl font-semibold mb-4">89 Autosales</h3>
            <p className="mb-4">Your trusted partner for quality pre-owned vehicles at competitive prices.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-red-600 transition-colors" aria-label="Facebook">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-red-600 transition-colors" aria-label="Twitter">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-twitter">
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-red-600 transition-colors" aria-label="Instagram">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-instagram">
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-red-600 transition-colors" aria-label="YouTube">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-youtube">
                  <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
                  <path d="m10 15 5-3-5-3z"></path>
                </svg>
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-red-600 text-lg font-semibold mb-4 uppercase">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/inventory" className="hover:text-red-600 transition-colors">Browse Inventory</Link></li>
              <li><Link href="/financing" className="hover:text-red-600 transition-colors">Financing Options</Link></li>
              <li><Link href="/service" className="hover:text-red-600 transition-colors">Service & Parts</Link></li>
              <li><Link href="/about" className="hover:text-red-600 transition-colors">About Us</Link></li>
              <li><Link href="/testimonials" className="hover:text-red-600 transition-colors">Customer Reviews</Link></li>
              <li><Link href="/contact" className="hover:text-red-600 transition-colors">Contact Us</Link></li>
              <li><Link href="/location" className="hover:text-red-600 transition-colors">Directions</Link></li>
            </ul>
          </div>
          
          {/* Contact Information */}
          <div>
            <h3 className="text-red-600 text-lg font-semibold mb-4 uppercase">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600 mt-1 mr-3">
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
                <span>506055 ON-89<br/>Mulmur, ON L9V 0N6</span>
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600 mr-3">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600 mr-3">
                  <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                </svg>
                <span>info@89autosales.ca</span>
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600 mr-3">
                  <circle cx="12" cy="12" r="10"></circle>
                  <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
                <span>Mon-Sat: 9AM-8PM<br/>Sunday: 10AM-6PM</span>
              </li>
            </ul>
          </div>
          
          {/* Get Approved */}
          <div>
            <h3 className="text-red-600 text-lg font-semibold mb-4 uppercase">Get Approved</h3>
            <p className="mb-4">Apply now for quick and easy auto financing.</p>
            <Link href="/contact" className="bg-red-600 hover:bg-red-700 text-white inline-block px-6 py-3 rounded text-center font-bold uppercase transition-colors">
              Contact Us
            </Link>
          </div>
        </div>
        
        {/* Certification Badges */}
        <div className="pt-6 border-t border-gray-800 mb-6">
          <h3 className="text-red-600 text-base font-semibold mb-4 text-center">Certifications</h3>
          <div className="flex flex-wrap justify-center gap-6">
            <a 
              href="https://www.omvic.on.ca/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center hover:text-red-600 transition-colors"
              aria-label="OMVIC - Ontario Motor Vehicle Industry Council"
            >
              <FaShieldAlt size={32} className="mb-2 text-blue-500" />
              <span className="font-semibold text-sm">OMVIC</span>
              <span className="text-xs text-gray-400">Registered Dealer</span>
            </a>
            
            <a 
              href="https://www.ucda.ca/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center hover:text-red-600 transition-colors"
              aria-label="UCDA - Used Car Dealers Association"
            >
              <FaCertificate size={32} className="mb-2 text-yellow-500" />
              <span className="font-semibold text-sm">UCDA</span>
              <span className="text-xs text-gray-400">Certified Member</span>
            </a>
            
            <a 
              href="https://www.carfax.ca/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center hover:text-red-600 transition-colors"
              aria-label="CARFAX Canada"
            >
              <FaFileAlt size={32} className="mb-2 text-red-500" />
              <span className="font-semibold text-sm">CARFAX</span>
              <span className="text-xs text-gray-400">Vehicle History Reports</span>
            </a>
          </div>
        </div>
        
        {/* Bottom Footer */}
        <div className="pt-6 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <p>© {new Date().getFullYear()} 89 Autosales. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy-policy" className="hover:text-red-600 transition-colors">Privacy Policy</Link>
            <Link href="/terms-of-service" className="hover:text-red-600 transition-colors">Terms of Service</Link>
            <Link href="/sitemap" className="hover:text-red-600 transition-colors">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
