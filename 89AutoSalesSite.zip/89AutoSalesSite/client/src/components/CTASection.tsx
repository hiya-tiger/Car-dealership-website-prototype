import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="bg-blue-600 text-white py-12">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to Find Your Next Car?</h2>
        <p className="text-xl mb-8 max-w-3xl mx-auto">
          Browse our extensive inventory of quality pre-owned vehicles and drive home happy today.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Button asChild variant="secondary" size="lg">
            <Link href="/inventory">View Inventory</Link>
          </Button>
          <Button asChild 
            variant="outline" 
            className="bg-transparent hover:bg-blue-700 text-white border-2 border-white"
            size="lg"
          >
            <Link href="/contact">Contact Us</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
