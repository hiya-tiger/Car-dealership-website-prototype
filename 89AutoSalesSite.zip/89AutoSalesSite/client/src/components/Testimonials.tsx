import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Testimonial } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Star, StarHalf, UserRound } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  // Generate star rating display
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-yellow-400 text-yellow-400" />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-gray-300" />);
    }

    return stars;
  };

  // Extract initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <Card className="bg-white shadow-md">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className="text-yellow-400 flex">
            {renderStars(testimonial.rating)}
          </div>
          <span className="ml-2 text-gray-600">{testimonial.rating.toFixed(1)}</span>
        </div>
        
        <blockquote className="text-gray-600 mb-6">
          "{testimonial.testimonial}"
        </blockquote>
        
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center mr-3">
            <span className="text-lg font-bold text-gray-700">{getInitials(testimonial.name)}</span>
          </div>
          <div>
            <p className="font-bold">{testimonial.name}</p>
            {testimonial.vehiclePurchased && (
              <p className="text-sm text-gray-500">Purchased a {testimonial.vehiclePurchased}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const Testimonials = () => {
  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ['/api/testimonials'],
  });

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-2">Customer Testimonials</h2>
        <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">
          Hear what our satisfied customers have to say about their car buying experience.
        </p>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[...Array(3)].map((_, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-24 mb-4" />
                  <Skeleton className="h-24 w-full mb-6" />
                  <div className="flex items-center">
                    <Skeleton className="h-12 w-12 rounded-full mr-3" />
                    <div>
                      <Skeleton className="h-4 w-24 mb-2" />
                      <Skeleton className="h-3 w-40" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials?.map(testimonial => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        )}
        
        <div className="text-center mt-10">
          <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">
            Read More Reviews <span className="ml-1">→</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
