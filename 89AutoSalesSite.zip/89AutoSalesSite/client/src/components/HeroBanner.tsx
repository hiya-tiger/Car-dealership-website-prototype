import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const HeroBanner = () => {
  return (
    <section className="relative bg-gray-900 text-white">
      {/* Hero Image Background */}
      <div className="absolute inset-0 overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fGNhcnN8ZW58MHwwfDB8fA%3D%3D&auto=format&fit=crop&w=1600&q=80" 
          alt="Luxury cars on display" 
          className="w-full h-full object-cover object-center opacity-50"
        />
      </div>
      
      {/* Hero Content */}
      <div className="container mx-auto px-4 py-24 md:py-32 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">Find Your Perfect Pre-Owned Vehicle</h1>
          <p className="text-xl mb-8">Quality certified vehicles with warranties you can trust. Experience hassle-free car buying at 89 Autosales.</p>
          
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link href="/inventory">Browse Inventory</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-gray-900">
              <Link href="/financing">Finance Options</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
