import { useState } from "react";
import { Link, useLocation } from "wouter";
import logo from "@assets/IMG_8538.jpeg";
import TabBar from "./TabBar";
import { 
  Phone,
  Mail,
  MapPin,
  Clock,
  Menu,
  X
} from "lucide-react";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  const isActiveLink = (path: string) => {
    return location === path;
  };

  return (
    <header className="bg-black text-white sticky top-0 z-50">
      <div className="container mx-auto px-4">
        {/* Top Bar with contact info and address */}
        <div className="hidden lg:flex justify-between items-center py-2 text-sm border-b border-gray-800">
          <div className="flex space-x-6">
            <a href="tel:5551234567" className="hover:text-red-600 flex items-center group transition-colors duration-200">
              <Phone className="w-4 h-4 mr-1 group-hover:animate-pulse text-red-600" /> (555) 123-4567
            </a>
            <a href="mailto:info@89autosales.com" className="hover:text-red-600 flex items-center group transition-colors duration-200">
              <Mail className="w-4 h-4 mr-1 group-hover:animate-pulse text-red-600" /> info@89autosales.com
            </a>
            <div className="flex items-center group">
              <Clock className="w-4 h-4 mr-1 text-red-600" /> 
              <span>Mon-Sat: 9AM-7PM | Sun: Closed</span>
            </div>
          </div>
          
          <div className="flex space-x-6">
            <Link href="/location" className="hover:text-red-600 flex items-center group transition-colors duration-200">
              <MapPin className="w-4 h-4 mr-1 group-hover:animate-pulse text-red-600" /> 506055 ON-89, Mulmur, ON L9V 0N6
            </Link>
          </div>
        </div>
        
        {/* Main Navigation Bar */}
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <img 
              src={logo} 
              alt="89 Autosales" 
              className="h-12 w-auto"
            />
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className={`font-medium uppercase ${isActiveLink('/') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Home
            </Link>
            <Link href="/inventory" className={`font-medium uppercase ${isActiveLink('/inventory') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Our Inventory
            </Link>
            <Link href="/financing" className={`font-medium uppercase ${isActiveLink('/financing') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Financing
            </Link>
            <Link href="/service" className={`font-medium uppercase ${isActiveLink('/service') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Service
            </Link>
            <Link href="/trade-in" className={`font-medium uppercase ${isActiveLink('/trade-in') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Trade-In
            </Link>
            <Link href="/about" className={`font-medium uppercase ${isActiveLink('/about') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Dealership
            </Link>
            <Link href="/buyer-resources?guide=faq" className={`font-medium uppercase ${location.includes('buyer-resources?guide=faq') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              FAQ
            </Link>
            <Link href="/contact" className={`font-medium uppercase ${isActiveLink('/contact') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Contact Us
            </Link>
            <Link href="/location" className={`font-medium uppercase ${isActiveLink('/location') ? 'text-red-600' : 'text-white hover:text-red-600'} transition-colors`}>
              Directions
            </Link>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden focus:outline-none" 
            aria-label="Toggle menu"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? (
              <X className="w-6 h-6 text-white" />
            ) : (
              <Menu className="w-6 h-6 text-white" />
            )}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className={`font-medium uppercase ${isActiveLink('/') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Home
              </Link>
              <Link href="/inventory" className={`font-medium uppercase ${isActiveLink('/inventory') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Our Inventory
              </Link>
              <Link href="/financing" className={`font-medium uppercase ${isActiveLink('/financing') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Financing
              </Link>
              <Link href="/service" className={`font-medium uppercase ${isActiveLink('/service') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Service
              </Link>
              <Link href="/trade-in" className={`font-medium uppercase ${isActiveLink('/trade-in') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Trade-In
              </Link>
              <Link href="/about" className={`font-medium uppercase ${isActiveLink('/about') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Dealership
              </Link>
              <Link href="/buyer-resources?guide=faq" className={`font-medium uppercase ${location.includes('buyer-resources?guide=faq') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                FAQ
              </Link>
              <Link href="/contact" className={`font-medium uppercase ${isActiveLink('/contact') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2 border-b border-gray-800`}>
                Contact Us
              </Link>
              <Link href="/location" className={`font-medium uppercase ${isActiveLink('/location') ? 'text-red-600' : 'text-white hover:text-red-600'} py-2`}>
                Directions
              </Link>
              <Link href="tel:5551234567" className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 font-medium text-center transition-colors mt-2">
                Call Us: (555) 123-4567
              </Link>
            </nav>
          </div>
        )}
      </div>
      
      {/* Tab Bar - visible on desktop only */}
      <div className="hidden md:block">
        <TabBar />
      </div>
    </header>
  );
};

export default Header;
