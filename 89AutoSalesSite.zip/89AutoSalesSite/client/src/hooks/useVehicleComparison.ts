import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Vehicle } from '@shared/schema';
import { useToast } from "@/hooks/use-toast";

interface VehicleComparisonStore {
  comparisonList: Vehicle[];
  addToComparison: (vehicle: Vehicle) => void;
  removeFromComparison: (id: number) => void;
  clearComparison: () => void;
  isInComparison: (id: number) => boolean;
}

const useVehicleComparisonStore = create<VehicleComparisonStore>()(
  persist(
    (set, get) => ({
      comparisonList: [],
      addToComparison: (vehicle) => set((state) => {
        // Check if already in the list
        if (state.comparisonList.some(v => v.id === vehicle.id)) {
          return state;
        }
        
        // Limit to 4 vehicles maximum
        if (state.comparisonList.length >= 4) {
          return state;
        }
        
        return { 
          comparisonList: [...state.comparisonList, vehicle] 
        };
      }),
      removeFromComparison: (id) => set((state) => ({
        comparisonList: state.comparisonList.filter(vehicle => vehicle.id !== id)
      })),
      clearComparison: () => set({ comparisonList: [] }),
      isInComparison: (id) => get().comparisonList.some(vehicle => vehicle.id === id)
    }),
    {
      name: 'vehicle-comparison-storage',
    }
  )
);

export const useVehicleComparison = () => {
  const { toast } = useToast();
  const store = useVehicleComparisonStore();
  
  const addToComparison = (vehicle: Vehicle) => {
    if (store.isInComparison(vehicle.id)) {
      toast({
        title: "Already in comparison",
        description: `${vehicle.year} ${vehicle.make} ${vehicle.model} is already in your comparison list.`,
      });
      return;
    }
    
    if (store.comparisonList.length >= 4) {
      toast({
        title: "Comparison limit reached",
        description: "You can compare up to 4 vehicles at a time. Remove a vehicle to add a new one.",
        variant: "destructive",
      });
      return;
    }
    
    store.addToComparison(vehicle);
    toast({
      title: "Added to comparison",
      description: `${vehicle.year} ${vehicle.make} ${vehicle.model} added to your comparison list.`,
    });
  };
  
  return {
    ...store,
    addToComparison,
  };
};
