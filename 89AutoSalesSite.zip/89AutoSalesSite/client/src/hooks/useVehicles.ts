import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Vehicle, VehicleSearchParams } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export const useVehicles = () => {
  const queryClient = useQueryClient();

  const { data: vehicles, isLoading } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  const { data: featuredVehicles, isLoading: isFeaturedLoading } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles/featured'],
  });

  const getVehicleById = (id: number) => {
    return useQuery<Vehicle>({
      queryKey: [`/api/vehicles/${id}`],
      enabled: !!id
    });
  };

  const searchVehicles = (params: Partial<VehicleSearchParams>) => {
    return useQuery<Vehicle[]>({
      queryKey: ['search-vehicles', params],
      queryFn: async () => {
        const response = await apiRequest('POST', '/api/vehicles/search', params);
        return response.json();
      },
      enabled: Object.keys(params).length > 0
    });
  };

  return {
    vehicles,
    isLoading,
    featuredVehicles,
    isFeaturedLoading,
    getVehicleById,
    searchVehicles
  };
};
