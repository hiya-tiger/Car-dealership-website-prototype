import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const TermsOfServicePage = () => {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-2">Terms of Service</h1>
      <p className="text-muted-foreground mb-2">Last Updated: April 1, 2025</p>
      <p className="text-muted-foreground mb-8">
        Please read these Terms of Service carefully before using our website or services.
      </p>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Acceptance of Terms</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            By accessing or using our website at <strong>www.89autosales.com</strong> (the "Website"), you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this Website.
          </p>
        </CardContent>
      </Card>

      <Accordion type="single" collapsible className="mb-8">
        <AccordionItem value="use">
          <AccordionTrigger>Use License</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              Permission is granted to temporarily view the materials (information or software) on our Website for personal, non-commercial use only. This is the grant of a license, not a transfer of title, and under this license you may not:
            </p>

            <ul className="list-disc pl-6 space-y-1">
              <li>Modify or copy the materials;</li>
              <li>Use the materials for any commercial purpose or for any public display;</li>
              <li>Attempt to reverse engineer any software contained on the Website;</li>
              <li>Remove any copyright or other proprietary notations from the materials; or</li>
              <li>Transfer the materials to another person or "mirror" the materials on any other server.</li>
            </ul>

            <p>
              This license shall automatically terminate if you violate any of these restrictions and may be terminated by us at any time. Upon terminating your viewing of these materials or upon the termination of this license, you must destroy any downloaded materials in your possession whether in electronic or printed format.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="disclaimer">
          <AccordionTrigger>Disclaimer</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              The materials on our Website are provided on an 'as is' basis. We make no warranties, expressed or implied, and hereby disclaim and negate all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
            </p>

            <p>
              Further, we do not warrant or make any representations concerning the accuracy, likely results, or reliability of the use of the materials on our Website or otherwise relating to such materials or on any sites linked to this Website.
            </p>

            <p>
              The vehicles displayed on our Website are subject to prior sale. Prices and special offers are subject to change without notice. All vehicle prices exclude government fees and taxes, any finance charges, any dealer document processing charge, any electronic filing charge, and any emission testing charge.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="limitations">
          <AccordionTrigger>Limitations</AccordionTrigger>
          <AccordionContent>
            <p>
              In no event shall we or our suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on our Website, even if we or a authorized representative has been notified orally or in writing of the possibility of such damage. Because some jurisdictions do not allow limitations on implied warranties, or limitations of liability for consequential or incidental damages, these limitations may not apply to you.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="accuracy">
          <AccordionTrigger>Accuracy of Materials</AccordionTrigger>
          <AccordionContent>
            <p>
              The materials appearing on our Website could include technical, typographical, or photographic errors. We do not warrant that any of the materials on the Website are accurate, complete, or current. We may make changes to the materials contained on the Website at any time without notice. However, we do not make any commitment to update the materials.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="links">
          <AccordionTrigger>Links</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              We have not reviewed all of the sites linked to our Website and are not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by us of the site. Use of any such linked website is at the user's own risk.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="modifications">
          <AccordionTrigger>Modifications</AccordionTrigger>
          <AccordionContent>
            <p>
              We may revise these Terms of Service for the Website at any time without notice. By using this Website, you are agreeing to be bound by the then current version of these Terms of Service.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="transactions">
          <AccordionTrigger>Online Transactions</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              The Website may allow you to schedule appointments, apply for financing, or make deposits on vehicles. By using these features, you agree to the following:
            </p>

            <div className="space-y-2">
              <h3 className="font-semibold">Appointments</h3>
              <p>
                While we make every effort to honor scheduled appointments, we reserve the right to reschedule if necessary. We will attempt to notify you of any changes in advance.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Financing Applications</h3>
              <p>
                Submitting a financing application through our Website does not guarantee approval. All financing applications are subject to credit approval and may require additional information.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Deposits</h3>
              <p>
                Any deposits made through our Website to hold a vehicle are generally refundable if you decide not to proceed with the purchase. However, we reserve the right to retain all or a portion of the deposit in certain circumstances, which will be clearly communicated to you at the time of the deposit.
              </p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="user">
          <AccordionTrigger>User Accounts</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              If you create an account on our Website, you are responsible for maintaining the security of your account and for all activities that occur under your account. You must immediately notify us of any unauthorized uses of your account or any other breaches of security.
            </p>

            <p>
              We will not be liable for any acts or omissions by you, including any damages of any kind incurred as a result of such acts or omissions.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="governing">
          <AccordionTrigger>Governing Law</AccordionTrigger>
          <AccordionContent>
            <p>
              These Terms shall be governed and construed in accordance with the laws of the State of California, without regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="dispute">
          <AccordionTrigger>Dispute Resolution</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              Any dispute, controversy, or claim arising out of or relating to these Terms, or the breach, termination, or validity thereof, shall be settled by arbitration in accordance with the rules of the American Arbitration Association. The place of arbitration shall be Los Angeles, California.
            </p>

            <p>
              You agree that any dispute resolution proceedings will be conducted only on an individual basis and not in a class, consolidated, or representative action. If for any reason a claim proceeds in court rather than in arbitration, both you and we waive any right to a jury trial.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="severability">
          <AccordionTrigger>Severability</AccordionTrigger>
          <AccordionContent>
            <p>
              If any provision of these Terms is found to be invalid or unenforceable, the remaining provisions will remain in full force and the invalid or unenforceable provision will be limited or eliminated to the minimum extent necessary so that the Terms shall otherwise remain in full force and effect.
            </p>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Card>
        <CardHeader>
          <CardTitle>Contact Us</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            If you have any questions about these Terms of Service, please contact us at:
          </p>

          <address className="not-italic space-y-2 mb-4">
            <div>89 Autosales</div>
            <div>506055 ON-89</div>
            <div>Mulmur, ON L9V 0N6, Canada</div>
            <div>Email: legal@89autosales.com</div>
            <div>Phone: (705) 555-8989</div>
          </address>
        </CardContent>
      </Card>

      <Separator className="my-8" />

      <div className="text-center text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} 89 Autosales. All rights reserved.</p>
      </div>
    </div>
  );
};

export default TermsOfServicePage;