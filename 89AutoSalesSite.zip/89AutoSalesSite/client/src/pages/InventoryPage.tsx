import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Vehicle } from "@shared/schema";
import VehicleCard from "@/components/VehicleCard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";

const InventoryPage = () => {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  
  const [filters, setFilters] = useState({
    make: searchParams.get('make') || "all",
    model: searchParams.get('model') || "all",
    maxPrice: searchParams.get('price') ? parseInt(searchParams.get('price')!) : 100000,
    minYear: 2000,
    bodyStyle: "all",
    status: searchParams.get('status') || "available", // Default to showing only available vehicles
  });
  
  const [compareVehicles, setCompareVehicles] = useState<Vehicle[]>([]);
  const [isComparing, setIsComparing] = useState(false);
  const { toast } = useToast();
  
  const { data: vehicles, isLoading } = useQuery<Vehicle[]>({
    queryKey: ["/api/vehicles"],
  });
  
  // Get unique values for filter dropdowns
  const makes = vehicles ? Array.from(new Set(vehicles.map(v => v.make))).sort() : [];
  const models = vehicles && filters.make && filters.make !== "all"
    ? Array.from(new Set(vehicles
        .filter(v => v.make === filters.make)
        .map(v => v.model))).sort()
    : [];
  const bodyStyles = vehicles
    ? Array.from(new Set(vehicles.map(v => v.bodyStyle))).sort()
    : [];
  const years = vehicles
    ? Array.from(new Set(vehicles.map(v => v.year))).sort((a, b) => b - a)
    : [];
  
  // Apply filters to vehicles
  const filteredVehicles = vehicles 
    ? vehicles.filter(vehicle => {
        if (filters.make && filters.make !== "all" && vehicle.make !== filters.make) return false;
        if (filters.model && filters.model !== "all" && vehicle.model !== filters.model) return false;
        if (filters.maxPrice && vehicle.price > filters.maxPrice) return false;
        if (filters.minYear && vehicle.year < filters.minYear) return false;
        if (filters.bodyStyle && filters.bodyStyle !== "all" && vehicle.bodyStyle !== filters.bodyStyle) return false;
        
        // Filter by vehicle status
        if (filters.status === "available" && vehicle.status === "sold") return false;
        if (filters.status === "sold" && vehicle.status !== "sold") return false;
        
        return true;
      })
    : [];
  
  // Handle comparing vehicles
  const handleCompareClick = (vehicle: Vehicle) => {
    if (compareVehicles.find(v => v.id === vehicle.id)) {
      setCompareVehicles(compareVehicles.filter(v => v.id !== vehicle.id));
      toast({
        title: "Vehicle removed from comparison",
        description: `${vehicle.year} ${vehicle.make} ${vehicle.model} removed from comparison`,
      });
    } else {
      if (compareVehicles.length >= 3) {
        toast({
          title: "Compare limit reached",
          description: "You can compare up to 3 vehicles at a time",
          variant: "destructive",
        });
        return;
      }
      setCompareVehicles([...compareVehicles, vehicle]);
      toast({
        title: "Vehicle added to comparison",
        description: `${vehicle.year} ${vehicle.make} ${vehicle.model} added to comparison`,
      });
    }
  };
  
  const clearCompare = () => {
    setCompareVehicles([]);
    setIsComparing(false);
  };

  return (
    <>
      <section className="py-12 bg-primary text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Vehicle Inventory</h1>
          <p className="text-lg">Browse our selection of quality pre-owned vehicles</p>
        </div>
      </section>
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-6">Filters</h2>
                  
                  <div className="space-y-6">
                    {/* Make Filter */}
                    <div>
                      <Label htmlFor="make" className="text-sm font-medium">Make</Label>
                      <Select 
                        value={filters.make} 
                        onValueChange={(value) => setFilters({...filters, make: value, model: "all"})}
                      >
                        <SelectTrigger id="make">
                          <SelectValue placeholder="All Makes" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Makes</SelectItem>
                          {makes.map((make) => (
                            <SelectItem key={make} value={make}>{make}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Model Filter */}
                    <div>
                      <Label htmlFor="model" className="text-sm font-medium">Model</Label>
                      <Select 
                        value={filters.model} 
                        onValueChange={(value) => setFilters({...filters, model: value})}
                        disabled={!filters.make || filters.make === "all"}
                      >
                        <SelectTrigger id="model">
                          <SelectValue placeholder={filters.make && filters.make !== "all" ? "All Models" : "Select a Make first"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Models</SelectItem>
                          {models.map((model) => (
                            <SelectItem key={model} value={model}>{model}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Price Range Filter */}
                    <div>
                      <div className="flex justify-between mb-2">
                        <Label htmlFor="price-range" className="text-sm font-medium">Max Price</Label>
                        <span className="text-sm text-neutral-500">{filters.maxPrice ? `$${filters.maxPrice.toLocaleString()}` : "No Limit"}</span>
                      </div>
                      <Slider
                        id="price-range"
                        defaultValue={[filters.maxPrice]}
                        max={100000}
                        step={5000}
                        onValueChange={(value) => setFilters({...filters, maxPrice: value[0]})}
                      />
                      <div className="flex justify-between mt-1 text-xs text-neutral-500">
                        <span>$0</span>
                        <span>$100,000+</span>
                      </div>
                    </div>
                    
                    {/* Year Filter */}
                    <div>
                      <Label htmlFor="year" className="text-sm font-medium">Minimum Year</Label>
                      <Select 
                        value={filters.minYear.toString()} 
                        onValueChange={(value) => setFilters({...filters, minYear: parseInt(value)})}
                      >
                        <SelectTrigger id="year">
                          <SelectValue placeholder="All Years" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">All Years</SelectItem>
                          {years.map((year) => (
                            <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Body Style Filter */}
                    <div>
                      <Label htmlFor="body-style" className="text-sm font-medium">Body Style</Label>
                      <Select 
                        value={filters.bodyStyle} 
                        onValueChange={(value) => setFilters({...filters, bodyStyle: value})}
                      >
                        <SelectTrigger id="body-style">
                          <SelectValue placeholder="All Body Styles" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Body Styles</SelectItem>
                          {bodyStyles.map((style) => (
                            <SelectItem key={style} value={style}>{style}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Status Filter */}
                    <div>
                      <Label htmlFor="status" className="text-sm font-medium">Vehicle Status</Label>
                      <Select 
                        value={filters.status} 
                        onValueChange={(value) => setFilters({...filters, status: value})}
                      >
                        <SelectTrigger id="status">
                          <SelectValue placeholder="Vehicle Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Vehicles</SelectItem>
                          <SelectItem value="available">Available Only</SelectItem>
                          <SelectItem value="sold">Sold Vehicles Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Reset Filters Button */}
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setFilters({
                        make: "all",
                        model: "all",
                        maxPrice: 100000,
                        minYear: 0,
                        bodyStyle: "all",
                        status: "available",
                      })}
                    >
                      Reset Filters
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Vehicle Listings */}
            <div className="lg:col-span-3">
              {/* Compare Bar */}
              {compareVehicles.length > 0 && (
                <div className="bg-white shadow-md rounded-lg p-4 mb-6 sticky top-20 z-10 border border-gray-200">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-semibold">Compare Vehicles ({compareVehicles.length}/3)</h3>
                      <p className="text-sm text-neutral-500">
                        {compareVehicles.map(v => `${v.year} ${v.make} ${v.model}`).join(', ')}
                      </p>
                    </div>
                    <div className="flex space-x-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={clearCompare}
                      >
                        Clear
                      </Button>
                      <Button
                        size="sm"
                        className="bg-primary"
                        onClick={() => setIsComparing(true)}
                        disabled={compareVehicles.length < 2}
                      >
                        Compare Now
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Comparison Modal */}
              {isComparing && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                  <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-auto">
                    <div className="p-4 border-b sticky top-0 bg-white">
                      <div className="flex justify-between items-center">
                        <h2 className="text-xl font-semibold">Vehicle Comparison</h2>
                        <button 
                          className="text-neutral-500 hover:text-neutral-800" 
                          onClick={() => setIsComparing(false)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M18 6 6 18"></path>
                            <path d="m6 6 12 12"></path>
                          </svg>
                        </button>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <div className="grid grid-cols-4 gap-4">
                        {/* Specs row headers */}
                        <div className="space-y-4">
                          <div className="font-semibold">Vehicle</div>
                          <div className="font-semibold">Price</div>
                          <div className="font-semibold">Year</div>
                          <div className="font-semibold">Mileage</div>
                          <div className="font-semibold">Exterior Color</div>
                          <div className="font-semibold">Interior Color</div>
                          <div className="font-semibold">Body Style</div>
                          <div className="font-semibold">MPG</div>
                          <div className="font-semibold">Engine</div>
                          <div className="font-semibold">Transmission</div>
                          <div className="font-semibold">Horsepower</div>
                        </div>
                        
                        {/* Vehicle columns */}
                        {compareVehicles.map(vehicle => (
                          <div key={vehicle.id} className="space-y-4">
                            <div>{vehicle.year} {vehicle.make} {vehicle.model}</div>
                            <div>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(vehicle.price)}</div>
                            <div>{vehicle.year}</div>
                            <div>{new Intl.NumberFormat('en-US').format(vehicle.mileage)} miles</div>
                            <div>{vehicle.exteriorColor}</div>
                            <div>{vehicle.interiorColor}</div>
                            <div>{vehicle.bodyStyle}</div>
                            <div>{vehicle.mpgCity}/{vehicle.mpgHighway}</div>
                            <div>{vehicle.engineDescription}</div>
                            <div>{vehicle.transmission}</div>
                            <div>{vehicle.horsepower} HP</div>
                          </div>
                        ))}
                        
                        {/* Empty columns if fewer than 3 vehicles */}
                        {[...Array(3 - compareVehicles.length)].map((_, index) => (
                          <div key={index} className="space-y-4">
                            <div className="italic text-neutral-400">Add a vehicle</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                            <div>-</div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="p-4 border-t">
                      <Button onClick={() => setIsComparing(false)}>Close</Button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Results Count and Sort */}
              <div className="flex justify-between items-center mb-6">
                <p className="text-neutral-600">
                  {isLoading ? (
                    "Loading vehicles..."
                  ) : (
                    `Showing ${filteredVehicles.length} vehicles`
                  )}
                </p>
                
                <Select defaultValue="newest">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="mileage-low">Mileage: Low to High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {isLoading ? (
                // Skeleton loading
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, index) => (
                    <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden h-96 animate-pulse">
                      <div className="h-48 bg-gray-200"></div>
                      <div className="p-4 space-y-4">
                        <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                        <div className="flex justify-between">
                          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                          <div className="h-6 bg-gray-200 rounded w-1/4"></div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded"></div>
                        </div>
                        <div className="flex space-x-2">
                          <div className="h-10 bg-gray-200 rounded flex-1"></div>
                          <div className="h-10 bg-gray-200 rounded w-10"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredVehicles.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredVehicles.map(vehicle => (
                    <VehicleCard 
                      key={vehicle.id} 
                      vehicle={vehicle}
                      onCompareClick={handleCompareClick}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-4xl text-neutral-300 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto">
                      <circle cx="11" cy="11" r="8"></circle>
                      <path d="m21 21-4.3-4.3"></path>
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-neutral-700 mb-2">No vehicles found</h3>
                  <p className="text-neutral-600 mb-6">Try adjusting your filters to find vehicles that match your criteria.</p>
                  <Button 
                    onClick={() => setFilters({
                      make: "all",
                      model: "all",
                      maxPrice: 100000,
                      minYear: 0,
                      bodyStyle: "all",
                      status: "available",
                    })}
                  >
                    Reset Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default InventoryPage;
