import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { insertInquirySchema } from "@shared/schema";
import FinancingCalculator from "@/components/FinancingCalculator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";

const FinancingPage = () => {
  const queryClient = useQueryClient();
  
  // Form schema
  const formSchema = insertInquirySchema.extend({
    name: z.string().min(2, { message: "Name must be at least 2 characters" }),
    email: z.string().email({ message: "Please enter a valid email address" }),
    phone: z.string().min(10, { message: "Please enter a valid phone number" }),
    message: z.string().min(10, { message: "Message must be at least 10 characters" }),
  });

  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "I'm interested in learning more about your financing options. Please contact me.",
      vehicleId: undefined
    },
  });

  // Submit inquiry mutation
  const submitInquiry = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      return apiRequest("POST", "/api/inquiries", values);
    },
    onSuccess: () => {
      toast({
        title: "Inquiry Submitted",
        description: "We've received your financing inquiry and will contact you soon!",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/inquiries"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "There was a problem submitting your inquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    submitInquiry.mutate(values);
  };

  return (
    <>
      {/* Hero Section */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl font-bold mb-4">Flexible Financing Solutions</h1>
            <p className="text-xl mb-6">
              We work with multiple lenders to find the best rates and terms for your financial situation.
            </p>
            <div className="flex gap-4">
              <Button 
                className="bg-white text-primary hover:bg-gray-100" 
                size="lg"
                onClick={() => document.getElementById('financing-form')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Apply for Financing
              </Button>
              <Button className="bg-accent hover:bg-accent-hover" size="lg">
                Contact Us
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Calculator & Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-neutral-900 mb-4">Calculate Your Payment</h2>
              <p className="text-lg text-neutral-700 mb-6">
                Use our payment calculator to estimate your monthly payments based on vehicle price, down payment, interest rate, and loan term.
              </p>
              
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Competitive Interest Rates</h3>
                    <p className="text-neutral-600">Access to special rates through our lending partners</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Flexible Term Options</h3>
                    <p className="text-neutral-600">Choose from 36-84 month terms to fit your budget</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Quick Pre-Approval</h3>
                    <p className="text-neutral-600">Get pre-approved in minutes without affecting your credit score</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Trade-In Assistance</h3>
                    <p className="text-neutral-600">Get maximum value for your current vehicle with our trade-in program</p>
                  </div>
                </li>
              </ul>
            </div>
            
            {/* Calculator */}
            <FinancingCalculator />
          </div>
        </div>
      </section>

      {/* Financing Process Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Financing Process</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Step 1 */}
            <div className="text-center relative">
              <div className="inline-flex items-center justify-center bg-primary w-16 h-16 rounded-full mb-4 text-white text-xl font-bold">1</div>
              <h3 className="text-xl font-semibold mb-2">Apply Online</h3>
              <p className="text-neutral-600">Fill out our secure online application form in just a few minutes.</p>
              
              {/* Connector line */}
              <div className="hidden md:block absolute top-8 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-gray-300"></div>
            </div>
            
            {/* Step 2 */}
            <div className="text-center relative">
              <div className="inline-flex items-center justify-center bg-primary w-16 h-16 rounded-full mb-4 text-white text-xl font-bold">2</div>
              <h3 className="text-xl font-semibold mb-2">Get Pre-Approved</h3>
              <p className="text-neutral-600">Receive a quick response with your pre-approved financing options.</p>
              
              {/* Connector line */}
              <div className="hidden md:block absolute top-8 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-gray-300"></div>
            </div>
            
            {/* Step 3 */}
            <div className="text-center relative">
              <div className="inline-flex items-center justify-center bg-primary w-16 h-16 rounded-full mb-4 text-white text-xl font-bold">3</div>
              <h3 className="text-xl font-semibold mb-2">Choose Your Vehicle</h3>
              <p className="text-neutral-600">Browse our inventory with the confidence of knowing your budget.</p>
              
              {/* Connector line */}
              <div className="hidden md:block absolute top-8 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-gray-300"></div>
            </div>
            
            {/* Step 4 */}
            <div className="text-center">
              <div className="inline-flex items-center justify-center bg-primary w-16 h-16 rounded-full mb-4 text-white text-xl font-bold">4</div>
              <h3 className="text-xl font-semibold mb-2">Drive Home Happy</h3>
              <p className="text-neutral-600">Complete your paperwork and drive away in your new vehicle!</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="border rounded-lg px-6 bg-gray-100">
                <AccordionTrigger className="text-lg font-medium text-neutral-800">What documents do I need to apply for financing?</AccordionTrigger>
                <AccordionContent className="text-neutral-600 bg-white p-4 rounded-lg mt-2">
                  To apply for financing, you'll typically need a valid driver's license, proof of income (pay stubs or tax returns), proof of residence (utility bill or lease agreement), and proof of insurance. If you're trading in a vehicle, you'll also need the current registration and title.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2" className="border rounded-lg px-6 bg-gray-100">
                <AccordionTrigger className="text-lg font-medium text-neutral-800">Can I get financing with bad credit?</AccordionTrigger>
                <AccordionContent className="text-neutral-600 bg-white p-4 rounded-lg mt-2">
                  Yes, we work with a variety of lenders who specialize in helping customers with less-than-perfect credit. While interest rates may be higher, we have helped many customers with challenged credit get into a reliable vehicle with payments that fit their budget.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3" className="border rounded-lg px-6 bg-gray-100">
                <AccordionTrigger className="text-lg font-medium text-neutral-800">How much should my down payment be?</AccordionTrigger>
                <AccordionContent className="text-neutral-600 bg-white p-4 rounded-lg mt-2">
                  Down payment requirements vary based on your credit and the vehicle you choose. Generally, a down payment of 10-20% of the vehicle price is recommended. A larger down payment can help secure better loan terms and lower monthly payments.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-4" className="border rounded-lg px-6 bg-gray-100">
                <AccordionTrigger className="text-lg font-medium text-neutral-800">How long does the financing approval process take?</AccordionTrigger>
                <AccordionContent className="text-neutral-600 bg-white p-4 rounded-lg mt-2">
                  Many customers receive a financing decision within minutes of completing our online application. In some cases, it may take 24-48 hours if additional information is needed or for special financing situations.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-5" className="border rounded-lg px-6 bg-gray-100">
                <AccordionTrigger className="text-lg font-medium text-neutral-800">Can I refinance my auto loan later?</AccordionTrigger>
                <AccordionContent className="text-neutral-600 bg-white p-4 rounded-lg mt-2">
                  Yes, you can typically refinance your auto loan after 6-12 months of consistent payments. Refinancing may be a good option if your credit score has improved or if interest rates have decreased since your original loan.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="financing-form" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold mb-4 text-neutral-800">Have Questions About Financing?</h2>
              <p className="text-lg text-neutral-600">
                Fill out the form below and our financing specialist will contact you to discuss your options.
              </p>
            </div>
            
            <Card>
              <CardContent className="p-6">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-neutral-800">Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your full name" className="bg-white text-neutral-800 border-gray-300" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-800">Email</FormLabel>
                            <FormControl>
                              <Input placeholder="Your email address" className="bg-white text-neutral-800 border-gray-300" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-800">Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="Your phone number" className="bg-white text-neutral-800 border-gray-300" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-neutral-800">Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your financing needs" 
                              className="min-h-[100px] bg-white text-neutral-800 border-gray-300" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="text-center">
                      <Button 
                        type="submit" 
                        className="px-8"
                        disabled={submitInquiry.isPending}
                      >
                        {submitInquiry.isPending ? (
                          <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Submitting...
                          </>
                        ) : (
                          "Submit Inquiry"
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
};

export default FinancingPage;
