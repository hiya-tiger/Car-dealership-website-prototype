import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { Vehicle, insertInquirySchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Carousel } from "@/components/ui/carousel";
import { Eye, Car, RotateCw, ArrowUpRight } from "lucide-react";
import VehicleARViewer from "@/components/VehicleARViewer";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

const VehicleDetailPage = () => {
  const params = useParams<{ id: string }>();
  const vehicleId = params?.id ? parseInt(params.id) : 0;
  const queryClient = useQueryClient();
  
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [loanTerm, setLoanTerm] = useState(60);
  const [downPayment, setDownPayment] = useState(5000);
  const [interestRate, setInterestRate] = useState(4.5);

  // Fetch vehicle details
  const { data: vehicle, isLoading, error } = useQuery<Vehicle>({
    queryKey: [`/api/vehicles/${vehicleId}`],
    enabled: !isNaN(vehicleId),
  });

  // Form schema for inquiries
  const formSchema = insertInquirySchema.extend({
    name: z.string().min(2, { message: "Name must be at least 2 characters" }),
    email: z.string().email({ message: "Please enter a valid email address" }),
    phone: z.string().min(10, { message: "Please enter a valid phone number" }),
    message: z.string().min(10, { message: "Message must be at least 10 characters" }),
  });

  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: `I'm interested in the ${vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : "vehicle"}. Please contact me with more information.`,
      vehicleId: vehicleId
    },
  });

  // Submit inquiry mutation
  const submitInquiry = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      return apiRequest("POST", "/api/inquiries", { body: values });
    },
    onSuccess: () => {
      toast({
        title: "Inquiry Submitted",
        description: "We've received your inquiry and will contact you soon!",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/inquiries"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "There was a problem submitting your inquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    submitInquiry.mutate(values);
  };

  // Calculate monthly payment
  const calculateMonthlyPayment = () => {
    if (!vehicle) return 0;
    
    const principal = vehicle.price - downPayment;
    const monthlyRate = interestRate / 100 / 12;
    const termMonths = loanTerm;
    
    if (principal <= 0 || monthlyRate <= 0 || termMonths <= 0) return 0;
    
    const payment = principal * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
    return Math.round(payment);
  };

  // Format price with commas
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(price);
  };

  // Format mileage with commas
  const formatMileage = (mileage: number) => {
    return new Intl.NumberFormat('en-US').format(mileage);
  };

  // Use a more efficient loading state with reduced DOM elements
  if (isLoading) {
    return (
      <div className="container mx-auto py-12 px-4">
        <div className="flex flex-col items-center justify-center py-12">
          <div className="w-12 h-12 border-3 border-t-primary border-r-gray-200 border-b-gray-200 border-l-gray-200 rounded-full animate-spin"></div>
          <p className="mt-3 text-base">Loading vehicle...</p>
        </div>
      </div>
    );
  }

  if (error || !vehicle) {
    return (
      <div className="container mx-auto py-16 px-4">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-red-500 mb-4">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          <h2 className="text-2xl font-bold mb-2">Vehicle Not Found</h2>
          <p className="text-gray-600 mb-6">The vehicle you're looking for doesn't exist or has been removed.</p>
          <Link href="/inventory">
            <Button>Browse Our Inventory</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Breadcrumb Navigation */}
      <div className="bg-gray-100 py-3">
        <div className="container mx-auto px-4">
          <div className="text-sm text-neutral-600">
            <Link href="/" className="hover:text-primary">Home</Link>
            <span className="mx-2">/</span>
            <Link href="/inventory" className="hover:text-primary">Inventory</Link>
            <span className="mx-2">/</span>
            <span className="text-neutral-400">{vehicle.year} {vehicle.make} {vehicle.model}</span>
          </div>
        </div>
      </div>

      {/* Vehicle Details Main Section */}
      <section className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Vehicle Images & Details */}
          <div className="lg:col-span-2">
            {/* Vehicle Image Gallery */}
            <div className="mb-8">
              <div className="relative">
                {/* Enhanced Image Carousel */}
                <Carousel 
                  images={vehicle.images || []} 
                  className="aspect-video rounded-lg overflow-hidden"
                  options={{ loop: true }}
                />
                
                {/* Feature Badges */}
                {vehicle.isFeatured && (
                  <div className="absolute top-4 left-4 z-10 bg-primary text-white px-3 py-1 rounded-md font-medium text-sm">
                    Featured
                  </div>
                )}
                {vehicle.isSpecialOffer && (
                  <div className="absolute top-4 left-4 z-10 bg-accent text-white px-3 py-1 rounded-md font-medium text-sm">
                    Special Offer
                  </div>
                )}
              </div>
              
              {/* Virtual Showroom Button */}
              <div className="mt-4">
                <Link href={`/virtual-showroom/${vehicle.id}`}>
                  <Button className="w-full flex items-center justify-center gap-2" variant="outline">
                    <RotateCw className="w-4 h-4" />
                    <span>View in Virtual Showroom</span>
                  </Button>
                </Link>
                <div className="text-xs text-center text-gray-500 mt-1">
                  Experience this vehicle in immersive 3D with our virtual showroom
                </div>
              </div>
            </div>

            {/* Vehicle Details Tabs */}
            <Tabs defaultValue="overview" className="bg-white rounded-lg shadow-md p-6">
              {/* Optimized TabsList with simplified structure */}
              <TabsList className="flex flex-wrap gap-1 mb-6 justify-between sm:justify-start">
                <TabsTrigger value="overview" className="flex-grow sm:flex-grow-0 text-sm px-2 sm:px-3">Overview</TabsTrigger>
                <TabsTrigger value="features" className="flex-grow sm:flex-grow-0 text-sm px-2 sm:px-3">Features</TabsTrigger>
                <TabsTrigger value="specs" className="flex-grow sm:flex-grow-0 text-sm px-2 sm:px-3">Specs</TabsTrigger>
                <TabsTrigger value="carfax" className="flex-grow sm:flex-grow-0 text-sm px-2 sm:px-3">CarFax</TabsTrigger>
                <TabsTrigger value="ar" className="flex-grow sm:flex-grow-0 text-sm px-2 sm:px-3 flex items-center justify-center gap-1">
                  <ArrowUpRight className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span>3D/AR</span>
                </TabsTrigger>
              </TabsList>
              
              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-4">
                <div>
                  <h2 className="text-2xl font-bold mb-1">{vehicle.year} {vehicle.make} {vehicle.model}</h2>
                  <p className="text-neutral-500">VIN: {vehicle.vin}</p>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                    <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Mileage</div>
                    <div style={{fontWeight: 600, color: '#111827'}}>{formatMileage(vehicle.mileage)} mi</div>
                  </div>
                  <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                    <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Body</div>
                    <div style={{fontWeight: 600, color: '#111827'}}>{vehicle.bodyStyle}</div>
                  </div>
                  <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                    <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Fuel</div>
                    <div style={{fontWeight: 600, color: '#111827'}}>{vehicle.fuelType}</div>
                  </div>
                  <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                    <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Transmission</div>
                    <div style={{fontWeight: 600, color: '#111827'}}>{vehicle.transmission}</div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2" style={{color: 'black'}}>Description</h3>
                  <p style={{color: '#1f2937'}}>{vehicle.description}</p>
                </div>
              </TabsContent>
              
              {/* Features Tab */}
              <TabsContent value="features">
                <h3 className="text-lg font-semibold mb-4" style={{color: 'black'}}>Vehicle Features</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {(vehicle.features || []).map((feature, index) => (
                    <div key={index} style={{
                      display: 'flex',
                      alignItems: 'center',
                      padding: '8px',
                      backgroundColor: '#f9fafb',
                      borderRadius: '6px',
                      border: '1px solid #e5e7eb',
                      marginBottom: '4px'
                    }}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{marginRight: '8px'}}>
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                      </svg>
                      <span style={{color: 'black'}}>{feature}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              {/* Specifications Tab */}
              <TabsContent value="specs">
                <h3 className="text-lg font-semibold mb-4" style={{color: 'black'}}>Technical Specifications</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Year</div>
                      <div style={{color: '#111827'}}>{vehicle.year}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Make</div>
                      <div style={{color: '#111827'}}>{vehicle.make}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Model</div>
                      <div style={{color: '#111827'}}>{vehicle.model}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Mileage</div>
                      <div style={{color: '#111827'}}>{formatMileage(vehicle.mileage)} miles</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Body Style</div>
                      <div style={{color: '#111827'}}>{vehicle.bodyStyle}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Exterior Color</div>
                      <div style={{color: '#111827'}}>{vehicle.exteriorColor}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Interior Color</div>
                      <div style={{color: '#111827'}}>{vehicle.interiorColor}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Fuel Type</div>
                      <div style={{color: '#111827'}}>{vehicle.fuelType}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Transmission</div>
                      <div style={{color: '#111827'}}>{vehicle.transmission}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>MPG</div>
                      <div style={{color: '#111827'}}>{vehicle.mpgCity} city / {vehicle.mpgHighway} highway</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Engine</div>
                      <div style={{color: '#111827'}}>{vehicle.engineDescription}</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>Horsepower</div>
                      <div style={{color: '#111827'}}>{vehicle.horsepower} HP</div>
                    </div>
                    <div className="border-b pb-2">
                      <div style={{fontSize: '0.875rem', color: '#6b7280'}}>VIN</div>
                      <div style={{color: '#111827'}}>{vehicle.vin}</div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              {/* CarFax Report Tab */}
              <TabsContent value="carfax">
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold" style={{color: 'black'}}>CarFax Vehicle History Report</h3>
                    <img src="/images/carfax-logo.svg" alt="CarFax Logo" className="h-8"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.onerror = null; // Prevent infinite loop
                        target.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 width%3D%22100%22 height%3D%2230%22 viewBox%3D%220 0 100 30%22%3E%3Crect fill%3D%22%23dc2626%22 width%3D%22100%22 height%3D%2230%22%2F%3E%3Ctext fill%3D%22%23fff%22 font-family%3D%22Arial%2C sans-serif%22 font-size%3D%2212%22 font-weight%3D%22bold%22 x%3D%2210%22 y%3D%2220%22%3ECARFAX%3C%2Ftext%3E%3C%2Fsvg%3E';
                      }}
                    />
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <p className="text-blue-800">
                      CarFax reports provide detailed vehicle history information, helping you make informed decisions about used vehicles.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                      <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Report Date</div>
                      <div style={{fontWeight: 600, color: '#111827'}}>
                        {vehicle.carfaxReportDate 
                          ? new Date(vehicle.carfaxReportDate).toLocaleDateString() 
                          : 'Not available'}
                      </div>
                    </div>
                    <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                      <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Number of Owners</div>
                      <div style={{fontWeight: 600, color: '#111827'}}>{vehicle.carfaxOwners || 'Not reported'}</div>
                    </div>
                    <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                      <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Accidents Reported</div>
                      <div style={{fontWeight: 600, color: '#111827'}}>{vehicle.carfaxAccidents || 'None reported'}</div>
                    </div>
                    <div style={{backgroundColor: '#f9fafb', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                      <div style={{color: '#6b7280', fontSize: '0.875rem', marginBottom: '0.25rem'}}>Service Records</div>
                      <div style={{fontWeight: 600, color: '#111827'}}>{vehicle.carfaxServiceRecords || 'Not available'}</div>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    {vehicle.carfaxLink ? (
                      <a 
                        href={vehicle.carfaxLink} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                          <polyline points="15 3 21 3 21 9"></polyline>
                          <line x1="10" y1="14" x2="21" y2="3"></line>
                        </svg>
                        View Full CarFax Report
                      </a>
                    ) : (
                      <div className="bg-gray-100 rounded-md p-4 text-center">
                        <p className="text-gray-600">Full CarFax report available upon request.</p>
                        <p className="text-sm text-gray-500 mt-1">Contact our sales team for more information.</p>
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              {/* 3D/AR Viewer Tab - Optimized to load content only when selected */}
              <TabsContent value="ar">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold mb-4" style={{color: 'black'}}>Interactive 3D Experience</h3>
                  {/* Only load the AR component when this tab is active to save resources */}
                  <VehicleARViewer 
                    vehicleName={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                    arModelUrl={vehicle.arModelUrl || undefined}
                    modelScale={vehicle.arModelScale || 1}
                  />
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Sidebar - Price, Calculator & Inquiry Form */}
          <div className="lg:col-span-1 space-y-6">
            {/* Price Card */}
            <Card className="overflow-hidden">
              <div className="bg-primary text-white p-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold">{formatPrice(vehicle.price)}</h2>
                  {vehicle.status === "sold" && (
                    <span className="bg-black text-white text-sm font-semibold px-3 py-1 rounded">SOLD</span>
                  )}
                </div>
                {vehicle.monthlyPayment && vehicle.status !== "sold" && (
                  <p className="text-sm text-gray-100">Est. {formatPrice(vehicle.monthlyPayment)}/mo with financing*</p>
                )}
                {vehicle.status === "pending" && (
                  <p className="text-sm text-yellow-200 font-semibold mt-1">Sale Pending</p>
                )}
              </div>
              <CardContent className="grid grid-cols-2 gap-2 text-sm p-4">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-neutral-500">
                    <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.6-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.5 2.8C1.4 11.3 1 12.1 1 13v3c0 .6.4 1 1 1h1"></path>
                    <circle cx="6" cy="17" r="2"></circle>
                    <path d="M9 17h6"></path>
                    <circle cx="18" cy="17" r="2"></circle>
                  </svg>
                  {vehicle.year}
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-neutral-500">
                    <path d="M2 12a5 5 0 0 0 5 5 8 8 0 0 1 5 2 8 8 0 0 1 5-2 5 5 0 0 0 5-5V7H2Z"></path>
                    <path d="M6 11V7"></path>
                    <path d="M10 11V7"></path>
                    <path d="M14 11V7"></path>
                    <path d="M18 11V7"></path>
                  </svg>
                  {formatMileage(vehicle.mileage)} mi
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-neutral-500">
                    <path d="m8 6 4-4 4 4"></path>
                    <path d="M12 2v10.3a4 4 0 0 1-1.172 2.872L4 22"></path>
                    <path d="m20 22-5-5"></path>
                  </svg>
                  {vehicle.horsepower} HP
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-neutral-500">
                    <path d="M6 10c0 1.1.9 2 2 2s2-.9 2-2-.9-2-2-2-2 .9-2 2Z"></path>
                    <path d="M15 13a3 3 0 0 1 3-3h0a3 3 0 0 1 3 3v2"></path>
                    <path d="M10 3.5a5.1 5.1 0 0 0-4 2 7.2 7.2 0 0 0-1 7 6 6 0 0 0 3 3l3 1 7 2 5-5c-3-3-3-10-10-10Z"></path>
                    <path d="M15.8 20.2c-1.1 1.3-3.3 1.3-5.5.1-3.5-1.9-6.6-5-8.3-8.7a5.1 5.1 0 0 1 .4-4.8 4.5 4.5 0 0 1 3.6-2.3"></path>
                  </svg>
                  {vehicle.mpgCity}/{vehicle.mpgHighway} MPG
                </div>
              </CardContent>
              <div className="p-4 border-t flex justify-between">
                <Link href="/financing">
                  <Button variant="outline" className="text-primary border-primary">Financing Options</Button>
                </Link>
                <a href={`tel:5551234567`}>
                  <Button className="bg-accent hover:bg-accent-hover">Call Now</Button>
                </a>
              </div>
            </Card>
            
            {/* Payment Calculator */}
            {vehicle.status !== "sold" ? (
              <Card>
                <CardContent className="p-5">
                  <h3 className="text-lg font-semibold mb-4" style={{color: 'black'}}>Payment Calculator</h3>
                  
                  <div className="space-y-4 mb-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label style={{fontSize: '0.875rem', fontWeight: 500, color: '#374151'}}>Down Payment: ${downPayment}</label>
                      </div>
                      <Slider
                        value={[downPayment]}
                        min={0}
                        max={vehicle.price / 2}
                        step={500}
                        onValueChange={(value) => setDownPayment(value[0])}
                      />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <label style={{fontSize: '0.875rem', fontWeight: 500, color: '#374151'}}>Loan Term: {loanTerm} months</label>
                      </div>
                      <Slider
                        value={[loanTerm]}
                        min={36}
                        max={84}
                        step={12}
                        onValueChange={(value) => setLoanTerm(value[0])}
                      />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <label style={{fontSize: '0.875rem', fontWeight: 500, color: '#374151'}}>Interest Rate: {interestRate}%</label>
                      </div>
                      <Slider
                        value={[interestRate]}
                        min={1}
                        max={10}
                        step={0.1}
                        onValueChange={(value) => setInterestRate(value[0])}
                      />
                    </div>
                  </div>
                  
                  <div style={{backgroundColor: '#f9fafb', padding: '1rem', borderRadius: '0.375rem', border: '1px solid #e5e7eb'}}>
                    <div className="flex justify-between items-center">
                      <span style={{fontSize: '0.875rem', color: '#4b5563'}}>Estimated Payment:</span>
                      <span className="text-2xl font-bold text-primary">${calculateMonthlyPayment()}/mo</span>
                    </div>
                  </div>
                  
                  <p className="text-xs text-neutral-500 mt-3 text-center">
                    *Estimated payment. Actual terms may vary. Not an offer of financing.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-5 text-center">
                  <h3 className="text-lg font-semibold mb-2" style={{color: 'black'}}>Vehicle Sold</h3>
                  <p className="text-neutral-600 mb-4">This vehicle has been sold, but we have many similar options available.</p>
                  <Link href="/inventory">
                    <Button className="bg-primary hover:bg-primary/90">Browse Similar Vehicles</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
            
            {/* Inquiry Form */}
            {vehicle.status !== "sold" ? (
              <Card>
                <CardContent className="p-5">
                  <h3 className="text-lg font-semibold mb-4" style={{color: 'black'}}>Interested? Contact Us</h3>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Email</FormLabel>
                            <FormControl>
                              <Input placeholder="Your email address" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="Your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Message</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Your message" 
                                className="min-h-[100px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={submitInquiry.isPending}
                      >
                        {submitInquiry.isPending ? (
                          <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Submitting...
                          </>
                        ) : (
                          "Send Inquiry"
                        )}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-5">
                  <h3 className="text-lg font-semibold mb-3" style={{color: 'black'}}>Looking for something similar?</h3>
                  <p className="text-neutral-600 mb-4">This vehicle has been sold, but we'd be happy to help you find a similar one that fits your needs.</p>
                  
                  <div className="flex space-x-3">
                    <a href="tel:5551234567" className="flex-1">
                      <Button variant="secondary" className="w-full">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        Call Us
                      </Button>
                    </a>
                    <Link href="/inventory" className="flex-1">
                      <Button className="w-full">Browse Inventory</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>
      
      {/* Similar Vehicles Section - would be added here */}
    </>
  );
};

export default VehicleDetailPage;
