import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Testimonial as TestimonialType } from "@shared/schema";
import Testimonial from "@/components/Testimonial";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const AboutPage = () => {
  const { data: testimonials, isLoading: isLoadingTestimonials } = useQuery<TestimonialType[]>({
    queryKey: ["/api/testimonials"],
  });

  return (
    <>
      {/* Hero Section */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl font-bold mb-4">About 89 Autosales</h1>
            <p className="text-xl mb-6">
              Your trusted partner for quality pre-owned vehicles at competitive prices since 2005.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-neutral-900 mb-4">Our Story</h2>
              <p className="text-lg text-neutral-700 mb-6">
                Founded in 2005, 89 Autosales began with a simple mission: to provide high-quality used vehicles with transparent pricing and exceptional customer service. What started as a small lot with just 20 vehicles has grown into one of the region's most trusted dealerships.
              </p>
              <p className="text-lg text-neutral-700 mb-6">
                Our founder, Michael Reynolds, believed that buying a pre-owned vehicle shouldn't be a stressful experience. He established a no-pressure, customer-first approach that continues to guide our business today.
              </p>
              <p className="text-lg text-neutral-700">
                Today, we maintain an inventory of over 200 premium pre-owned vehicles from top manufacturers. While we've grown significantly, our commitment to transparency, quality, and customer satisfaction remains unchanged.
              </p>
            </div>
            
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1560239326-8b82aa108b7d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="89 Autosales Showroom" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose 89 Autosales</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Reason 1 */}
            <Card className="border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12 l5 5 l10 -10"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Quality Assurance</h3>
                <p className="text-neutral-600">
                  Every vehicle undergoes a rigorous 125-point inspection before being offered for sale. We only sell vehicles that meet our high quality standards.
                </p>
              </CardContent>
            </Card>
            
            {/* Reason 2 */}
            <Card className="border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Warranty Options</h3>
                <p className="text-neutral-600">
                  All vehicles are sold as-is with optional warranty packages available for purchase to protect your investment.
                </p>
              </CardContent>
            </Card>
            
            {/* Reason 3 */}
            <Card className="border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="20" height="14" x="2" y="5" rx="2"></rect>
                    <line x1="2" x2="22" y1="10" y2="10"></line>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Flexible Financing</h3>
                <p className="text-neutral-600">
                  We work with multiple lenders to secure the best rates and terms, regardless of your credit situation.
                </p>
              </CardContent>
            </Card>
            
            {/* Reason 4 */}
            <Card className="border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Transparent Pricing</h3>
                <p className="text-neutral-600">
                  No hidden fees or surprises. The price you see is the price you pay, with all costs clearly explained.
                </p>
              </CardContent>
            </Card>
            
            {/* Reason 5 */}
            <Card className="border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Expert Team</h3>
                <p className="text-neutral-600">
                  Our team of automotive experts is here to help you find the perfect vehicle for your needs and budget.
                </p>
              </CardContent>
            </Card>
            
            {/* Reason 6 */}
            <Card className="border-t-4 border-t-primary">
              <CardContent className="p-6">
                <div className="mb-4 text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Full-Service Center</h3>
                <p className="text-neutral-600">
                  Our certified technicians provide expert maintenance and repair services to keep your vehicle running smoothly.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Meet Our Leadership Team</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Team Member 1 */}
            <div className="text-center">
              <div className="mb-4 w-32 h-32 rounded-full overflow-hidden mx-auto">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" 
                  alt="Michael Reynolds" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Michael Reynolds</h3>
              <p className="text-primary mb-3">Founder & CEO</p>
              <p className="text-neutral-600">
                With over 25 years in the automotive industry, Michael founded 89 Autosales with a vision to transform the used car buying experience.
              </p>
            </div>
            
            {/* Team Member 2 */}
            <div className="text-center">
              <div className="mb-4 w-32 h-32 rounded-full overflow-hidden mx-auto">
                <img 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" 
                  alt="Sarah Johnson" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">Sarah Johnson</h3>
              <p className="text-primary mb-3">General Manager</p>
              <p className="text-neutral-600">
                Sarah oversees daily operations and ensures that every customer receives the exceptional service that defines our dealership.
              </p>
            </div>
            
            {/* Team Member 3 */}
            <div className="text-center">
              <div className="mb-4 w-32 h-32 rounded-full overflow-hidden mx-auto">
                <img 
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80" 
                  alt="David Chen" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">David Chen</h3>
              <p className="text-primary mb-3">Finance Director</p>
              <p className="text-neutral-600">
                David works with our network of lenders to secure competitive financing options for customers of all credit backgrounds.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-neutral-900 mb-2">What Our Customers Say</h2>
          <p className="text-center text-neutral-600 mb-12 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our valued customers have to say about their experience with 89 Autosales.
          </p>
          
          {isLoadingTestimonials ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-md p-6 animate-pulse">
                  <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-6"></div>
                  <div className="flex items-center">
                    <div className="h-12 w-12 rounded-full bg-gray-200 mr-4"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-32"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials && testimonials.length > 0 ? (
                testimonials.map((testimonial) => (
                  <Testimonial key={testimonial.id} testimonial={testimonial} />
                ))
              ) : (
                <p className="col-span-full text-center text-neutral-600">No testimonials available</p>
              )}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary">
        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-2">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to experience the 89 Autosales difference?</h2>
              <p className="text-gray-100 text-lg mb-8 lg:mb-0">
                Visit our dealership today or browse our extensive inventory online to find your perfect vehicle.
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <Link href="/inventory">
                <Button className="bg-white text-primary hover:bg-gray-100 font-medium py-3 px-6 rounded-md transition-colors">
                  Browse Inventory
                </Button>
              </Link>
              <Link href="/contact">
                <Button className="bg-accent hover:bg-accent-hover text-white font-medium py-3 px-6 rounded-md transition-colors">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;
