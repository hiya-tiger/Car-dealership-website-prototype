import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { Helmet } from "react-helmet";
import MainLayout from "@/layouts/MainLayout";
import VehicleDetails from "@/components/VehicleDetails";
import ContactForm from "@/components/ContactForm";
import { useQuery } from "@tanstack/react-query";
import { Vehicle } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeftIcon } from "lucide-react";

const VehicleDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const [_, setLocation] = useLocation();

  const { data: vehicle, isLoading, error } = useQuery<Vehicle>({
    queryKey: [`/api/vehicles/${id}`],
    enabled: !!id
  });

  // Redirect to inventory page if vehicle not found
  useEffect(() => {
    if (error) {
      setLocation("/inventory");
    }
  }, [error, setLocation]);

  return (
    <MainLayout>
      <Helmet>
        <title>{vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model} | 89 Autosales` : "Vehicle Details | 89 Autosales"}</title>
        <meta 
          name="description" 
          content={vehicle ? `Explore the ${vehicle.year} ${vehicle.make} ${vehicle.model} with ${vehicle.mileage.toLocaleString()} miles. Available now at 89 Autosales.` : "View detailed information about this pre-owned vehicle at 89 Autosales."} 
        />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <Button 
          variant="ghost" 
          className="mb-6 flex items-center gap-2"
          onClick={() => setLocation("/inventory")}
        >
          <ArrowLeftIcon size={16} />
          Back to Inventory
        </Button>
        
        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Skeleton className="w-full h-[400px] mb-4" />
              <div className="grid grid-cols-4 gap-2 mb-6">
                {[...Array(4)].map((_, index) => (
                  <Skeleton key={index} className="w-full h-20" />
                ))}
              </div>
              <Skeleton className="w-full h-10 mb-3" />
              <Skeleton className="w-3/4 h-6 mb-6" />
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                {[...Array(9)].map((_, index) => (
                  <Skeleton key={index} className="w-full h-8" />
                ))}
              </div>
              <Skeleton className="w-full h-24" />
            </div>
            <div>
              <Skeleton className="w-full h-[500px]" />
            </div>
          </div>
        ) : vehicle ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <VehicleDetails vehicle={vehicle} />
            </div>
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 sticky top-8">
                <h2 className="text-2xl font-bold mb-4">Interested in this vehicle?</h2>
                <p className="text-gray-600 mb-6">Fill out the form below and our team will get back to you promptly with more information.</p>
                <ContactForm vehicleId={vehicle.id} vehicleName={`${vehicle.year} ${vehicle.make} ${vehicle.model}`} />
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold mb-4">Vehicle Not Found</h2>
            <p className="text-gray-600 mb-6">The vehicle you're looking for couldn't be found or may have been sold.</p>
            <Button onClick={() => setLocation("/inventory")}>Browse Inventory</Button>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default VehicleDetailsPage;
