import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { ChevronRight, Download, Clock, DollarSign, FileClock, FileCheck, FileText, Shield } from "lucide-react";

const BuyerResourcesPage = () => {
  const [activeGuide, setActiveGuide] = useState("financing");
  
  const buyingGuides = [
    {
      id: "financing",
      title: "Auto Financing Guide",
      description: "Understanding your financing options and getting the best rates",
      icon: <DollarSign className="h-10 w-10 text-primary" />,
      content: (
        <div className="space-y-6">
          <p>
            Financing a vehicle is a significant decision that requires careful consideration of your budget, credit score, 
            and various financing options. This guide will help you navigate the process with confidence.
          </p>
          
          <h3 className="text-lg font-semibold">Understanding Your Budget</h3>
          <p>
            Before shopping for a vehicle, determine how much you can realistically afford for a monthly payment. 
            Financial experts recommend that your car payment should not exceed 15-20% of your monthly take-home pay.
          </p>
          
          <div className="bg-muted/20 p-4 rounded-md mb-6">
            <h4 className="font-medium mb-2">Monthly Budget Calculator</h4>
            <p className="text-sm mb-4">A simple way to calculate your affordable payment:</p>
            <ol className="text-sm space-y-2 list-decimal list-inside">
              <li>Take your monthly after-tax income</li>
              <li>Multiply by 0.15 (15% rule)</li>
              <li>The result is a reasonable monthly car payment</li>
            </ol>
          </div>
          
          <h3 className="text-lg font-semibold">Credit Scores and Interest Rates</h3>
          <p className="mb-4">
            Your credit score plays a crucial role in determining the interest rate you'll be offered. 
            Generally, the higher your credit score, the lower your interest rate.
          </p>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Good Credit Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">For scores 700+, expect rates from:</p>
                <p className="text-2xl font-bold text-primary">2.9% - 5.9%</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Average Credit Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">For scores 600-699, expect rates from:</p>
                <p className="text-2xl font-bold text-primary">6.0% - 11.9%</p>
              </CardContent>
            </Card>
          </div>
          
          <h3 className="text-lg font-semibold">Financing Options</h3>
          <Accordion type="single" collapsible className="mb-6">
            <AccordionItem value="dealership">
              <AccordionTrigger>Dealership Financing</AccordionTrigger>
              <AccordionContent>
                Our dealership works with multiple lenders to find competitive rates. 
                This option provides convenience as you can shop for your vehicle and 
                arrange financing in one location. We can often secure special manufacturer 
                incentives and promotional rates not available elsewhere.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="bank">
              <AccordionTrigger>Bank or Credit Union Loan</AccordionTrigger>
              <AccordionContent>
                Your personal bank or credit union may offer competitive rates, especially if 
                you have an established relationship. Getting pre-approved before shopping 
                can strengthen your negotiating position and streamline the purchase process.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="online">
              <AccordionTrigger>Online Lenders</AccordionTrigger>
              <AccordionContent>
                Many online lenders offer competitive rates and a streamlined application process. 
                These can be especially helpful for comparing multiple offers quickly. Be sure to 
                research the reputation of any online lender you're considering.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
            <h3 className="text-lg font-semibold text-primary mb-2">Pro Tip</h3>
            <p className="text-sm">
              Consider getting pre-approved for financing before visiting our dealership. 
              This gives you a clear budget and strengthens your negotiating position. 
              Our finance team can still work to beat your pre-approved rate!
            </p>
          </div>
          
          <div className="flex justify-between mt-8">
            <Link href="/financing">
              <Button variant="outline">Learn More About Financing</Button>
            </Link>
            <Link href="/credit-application">
              <Button>
                Apply for Financing 
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      )
    },
    {
      id: "buying-process",
      title: "Car Buying Process",
      description: "Step-by-step guide to purchasing a vehicle at our dealership",
      icon: <Clock className="h-10 w-10 text-primary" />,
      content: (
        <div className="space-y-6">
          <p>
            The car buying process doesn't have to be complicated. At our dealership, we strive to make the process
            as straightforward and transparent as possible. Here's what you can expect when purchasing a vehicle from us.
          </p>
          
          <div className="space-y-8 my-8">
            <div className="flex gap-6">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">1</div>
              <div>
                <h3 className="text-lg font-semibold">Research & Browsing</h3>
                <p className="text-muted-foreground mb-2">
                  Start by researching vehicles that meet your needs and budget, either online or at our dealership.
                </p>
                <Progress value={100} className="h-2 w-full max-w-[200px]" />
              </div>
            </div>
            
            <div className="flex gap-6">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">2</div>
              <div>
                <h3 className="text-lg font-semibold">Test Drive</h3>
                <p className="text-muted-foreground mb-2">
                  Visit our dealership to test drive your preferred vehicles and ask any questions.
                </p>
                <Progress value={100} className="h-2 w-full max-w-[200px]" />
              </div>
            </div>
            
            <div className="flex gap-6">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">3</div>
              <div>
                <h3 className="text-lg font-semibold">Financing Application</h3>
                <p className="text-muted-foreground mb-2">
                  Apply for financing either online or at our dealership to secure the best available rates.
                </p>
                <Progress value={100} className="h-2 w-full max-w-[200px]" />
              </div>
            </div>
            
            <div className="flex gap-6">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">4</div>
              <div>
                <h3 className="text-lg font-semibold">Negotiation & Paperwork</h3>
                <p className="text-muted-foreground mb-2">
                  Review and negotiate the terms, complete the required paperwork and documentation.
                </p>
                <Progress value={100} className="h-2 w-full max-w-[200px]" />
              </div>
            </div>
            
            <div className="flex gap-6">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">5</div>
              <div>
                <h3 className="text-lg font-semibold">Vehicle Delivery</h3>
                <p className="text-muted-foreground mb-2">
                  Complete the final vehicle inspection and drive home in your new vehicle.
                </p>
                <Progress value={100} className="h-2 w-full max-w-[200px]" />
              </div>
            </div>
          </div>
          
          <h3 className="text-lg font-semibold">Required Documentation</h3>
          <p className="mb-4">To ensure a smooth purchasing process, please bring the following documents:</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="flex items-start gap-3">
              <FileCheck className="h-5 w-5 text-primary flex-shrink-0" />
              <div>
                <h4 className="font-medium">Valid Driver's License</h4>
                <p className="text-sm text-muted-foreground">Current and not expired</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-primary flex-shrink-0" />
              <div>
                <h4 className="font-medium">Proof of Insurance</h4>
                <p className="text-sm text-muted-foreground">Current auto insurance card</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <DollarSign className="h-5 w-5 text-primary flex-shrink-0" />
              <div>
                <h4 className="font-medium">Proof of Income</h4>
                <p className="text-sm text-muted-foreground">Recent pay stubs or tax returns</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-primary flex-shrink-0" />
              <div>
                <h4 className="font-medium">Proof of Residence</h4>
                <p className="text-sm text-muted-foreground">Utility bill or bank statement</p>
              </div>
            </div>
          </div>
          
          <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
            <h3 className="text-lg font-semibold text-primary mb-2">Pro Tip</h3>
            <p className="text-sm">
              Schedule your visit during a weekday if possible. Our dealership is typically less busy, 
              which means you'll receive more personalized attention and potentially faster processing.
            </p>
          </div>
          
          <div className="flex justify-between mt-8">
            <Link href="/inventory">
              <Button variant="outline">Browse Inventory</Button>
            </Link>
            <Link href="/contact">
              <Button>
                Schedule a Visit
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      )
    },
    {
      id: "warranties",
      title: "Warranty Information",
      description: "Understanding the different warranty options for your vehicle",
      icon: <Shield className="h-10 w-10 text-primary" />,
      content: (
        <div className="space-y-6">
          <p>
            While all vehicles at 89 Autosales are sold as-is without an included warranty, we offer optional warranty packages 
            that provide peace of mind by protecting you from unexpected repair costs. Understanding these optional warranty
            packages can help you make an informed decision about additional protection for your vehicle.
          </p>
          
          <h3 className="text-lg font-semibold">Types of Warranties</h3>
          
          <div className="grid grid-cols-1 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Manufacturer's Warranty</CardTitle>
                <CardDescription>Coverage directly from the vehicle manufacturer</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  New vehicles come with a manufacturer's warranty that typically includes:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium">Bumper-to-Bumper</h4>
                    <p className="text-sm text-muted-foreground mb-1">Covers most vehicle components</p>
                    <p className="text-sm font-medium">Duration: 3 years / 36,000 miles</p>
                  </div>
                  <div>
                    <h4 className="font-medium">Powertrain</h4>
                    <p className="text-sm text-muted-foreground mb-1">Covers engine, transmission, drivetrain</p>
                    <p className="text-sm font-medium">Duration: 5 years / 60,000 miles</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Extended Warranty</CardTitle>
                <CardDescription>Additional coverage beyond the manufacturer's warranty</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Extended warranties provide coverage after the manufacturer's warranty expires:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium">Dealership Extended Warranty</h4>
                    <p className="text-sm text-muted-foreground mb-1">Offered directly through our dealership</p>
                    <p className="text-sm font-medium">Customizable terms up to 7 years / 100,000 miles</p>
                  </div>
                  <div>
                    <h4 className="font-medium">Third-Party Extended Warranty</h4>
                    <p className="text-sm text-muted-foreground mb-1">Offered by independent providers</p>
                    <p className="text-sm font-medium">Various coverage options available</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Certified Pre-Owned (CPO) Warranty</CardTitle>
                <CardDescription>Special warranty for certified pre-owned vehicles</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  CPO vehicles undergo thorough inspection and come with:
                </p>
                <div>
                  <h4 className="font-medium">CPO Limited Warranty</h4>
                  <p className="text-sm text-muted-foreground mb-1">Comprehensive coverage for CPO vehicles</p>
                  <p className="text-sm font-medium">Typically 1 year / 12,000 miles from purchase date</p>
                </div>
                <Separator className="my-4" />
                <div>
                  <h4 className="font-medium">CPO Powertrain Warranty</h4>
                  <p className="text-sm text-muted-foreground mb-1">Extended powertrain coverage</p>
                  <p className="text-sm font-medium">Often 7 years / 100,000 miles from original in-service date</p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <h3 className="text-lg font-semibold">Factors to Consider</h3>
          <Accordion type="single" collapsible className="mb-6">
            <AccordionItem value="cost">
              <AccordionTrigger>Cost vs. Value</AccordionTrigger>
              <AccordionContent>
                Extended warranties involve an upfront cost that may or may not pay off, depending on your vehicle's reliability.
                Consider the vehicle's reliability ratings, how long you plan to own it, and your comfort level with potential repair costs.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="coverage">
              <AccordionTrigger>Coverage Details</AccordionTrigger>
              <AccordionContent>
                Carefully review what is and isn't covered. Some warranties exclude routine maintenance, while others include it.
                Look for exclusions and understand what would void your warranty coverage.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="deductible">
              <AccordionTrigger>Deductibles</AccordionTrigger>
              <AccordionContent>
                Many warranties require a deductible for each repair visit. Understand the deductible amount and whether it's per-visit or per-repair.
                A lower deductible typically means a higher warranty price.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
            <h3 className="text-lg font-semibold text-primary mb-2">Pro Tip</h3>
            <p className="text-sm">
              Optional warranty packages are often negotiable. When purchasing a vehicle, ask about discounts or promotional
              pricing on warranty packages as part of your negotiation. You may be able to add protection at a lower cost.
            </p>
          </div>
          
          <div className="flex justify-between items-center mt-8">
            <a href="#" className="inline-flex">
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Download Warranty Guide
              </Button>
            </a>
            <Link href="/contact">
              <Button className="inline-flex items-center">
                Speak to a Warranty Specialist
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      )
    },
    {
      id: "faq",
      title: "Frequently Asked Questions",
      description: "Common questions from car buyers",
      icon: <FileClock className="h-10 w-10 text-primary" />,
      content: (
        <div className="space-y-6">
          <p>
            We've compiled answers to the most common questions our customers ask when purchasing a vehicle.
            If you don't find the answer you're looking for, please don't hesitate to contact us directly.
          </p>
          
          <Accordion type="single" collapsible className="mb-6">
            <AccordionItem value="test-drive">
              <AccordionTrigger>Do I need an appointment for a test drive?</AccordionTrigger>
              <AccordionContent>
                While walk-ins are welcome, we recommend scheduling a test drive appointment to ensure 
                the vehicle you're interested in is available and prepared for you. This also allows us 
                to allocate a sales consultant who can answer all your questions during the test drive.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="trade-in">
              <AccordionTrigger>How do you determine my trade-in value?</AccordionTrigger>
              <AccordionContent>
                We evaluate trade-ins based on current market conditions, the vehicle's condition, 
                mileage, service history, and market demand. We use industry-standard valuation tools 
                along with our own market expertise to offer you a fair and competitive trade-in value.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="negotiate">
              <AccordionTrigger>Can I negotiate the price of a used vehicle?</AccordionTrigger>
              <AccordionContent>
                Yes, we're open to reasonable negotiations on our used vehicle inventory. Our pricing 
                is set competitively based on market research, but we understand that finding the right 
                balance that works for both parties is part of the car buying process.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="financing">
              <AccordionTrigger>Can I get financing with less-than-perfect credit?</AccordionTrigger>
              <AccordionContent>
                Yes, we work with multiple lending partners who specialize in a variety of credit situations. 
                Our finance team is experienced in helping customers with a range of credit profiles secure 
                financing. We focus on finding solutions rather than obstacles.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="deposit">
              <AccordionTrigger>Is a deposit required to hold a vehicle?</AccordionTrigger>
              <AccordionContent>
                Yes, we require a refundable deposit to hold a vehicle. This ensures the vehicle remains 
                available for you while you complete your purchase decision or arrange financing. The deposit 
                amount varies depending on the vehicle's price and is applied to your purchase if you proceed.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="warranties">
              <AccordionTrigger>Are warranty packages available for your vehicles?</AccordionTrigger>
              <AccordionContent>
                All vehicles are sold as-is without a warranty included in the purchase price. However, we offer 
                various optional warranty packages that can be purchased separately to provide protection for 
                your vehicle. Our finance team can explain the different coverage options available to you.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="inspection">
              <AccordionTrigger>Can I have my own mechanic inspect the vehicle before purchase?</AccordionTrigger>
              <AccordionContent>
                Absolutely! We encourage you to have any vehicle independently inspected before purchase. 
                While all our vehicles undergo a comprehensive inspection process before being offered for sale, 
                we understand the importance of having complete confidence in your purchase decision.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="delivery">
              <AccordionTrigger>Do you offer vehicle delivery services?</AccordionTrigger>
              <AccordionContent>
                Yes, we offer vehicle delivery within a 100-mile radius of our dealership for a nominal fee. 
                For customers further away, we can arrange shipping through our trusted partners. All delivery 
                details and costs will be transparently discussed and agreed upon before finalizing your purchase.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
            <h3 className="text-lg font-semibold text-primary mb-2">Have More Questions?</h3>
            <p className="text-sm mb-4">
              Our team is here to help answer any additional questions you may have about the car buying process.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/contact">
                <Button variant="outline">
                  Contact Us
                </Button>
              </Link>
              <a href="tel:+15551234567">
                <Button variant="outline">
                  Call (555) 123-4567
                </Button>
              </a>
              <a href="mailto:sales@89autosales.com">
                <Button variant="outline">
                  Email Us
                </Button>
              </a>
            </div>
          </div>
        </div>
      )
    }
  ];
  
  const activeGuideContent = buyingGuides.find(guide => guide.id === activeGuide)?.content;

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-2">Buyer Resources</h1>
      <p className="text-muted-foreground mb-8">
        Helpful guides and resources to make your car buying experience smoother
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-1">
          <div className="space-y-4 sticky top-8">
            <h2 className="text-xl font-semibold mb-4">Buying Guides</h2>
            
            {buyingGuides.map((guide) => (
              <Card 
                key={guide.id} 
                className={`cursor-pointer hover:border-primary/40 transition-colors ${activeGuide === guide.id ? 'border-primary bg-primary/5' : ''}`}
                onClick={() => setActiveGuide(guide.id)}
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-base">{guide.title}</CardTitle>
                    {guide.icon}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{guide.description}</p>
                </CardContent>
              </Card>
            ))}
            
            <Card className="mt-8">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Downloads</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <a href="#" className="flex items-center gap-2 text-sm text-primary hover:underline">
                  <Download className="h-4 w-4" />
                  Financing Application Form
                </a>
                <a href="#" className="flex items-center gap-2 text-sm text-primary hover:underline">
                  <Download className="h-4 w-4" />
                  Vehicle Inspection Checklist
                </a>
                <a href="#" className="flex items-center gap-2 text-sm text-primary hover:underline">
                  <Download className="h-4 w-4" />
                  Car Buying Budget Worksheet
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="md:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>{buyingGuides.find(guide => guide.id === activeGuide)?.title}</CardTitle>
              <CardDescription>{buyingGuides.find(guide => guide.id === activeGuide)?.description}</CardDescription>
            </CardHeader>
            <CardContent>
              {activeGuideContent}
            </CardContent>
          </Card>
          
          <div className="mt-12 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Start Your Car Buying Journey?</h2>
            <p className="mb-6 max-w-2xl mx-auto text-muted-foreground">
              Our team is here to help you find the perfect vehicle and guide you through every step of the process.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/inventory">
                <Button>
                  Browse Inventory
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline">
                  Contact Us
                </Button>
              </Link>
              <Link href="/trade-in">
                <Button variant="outline">
                  Value Your Trade
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuyerResourcesPage;