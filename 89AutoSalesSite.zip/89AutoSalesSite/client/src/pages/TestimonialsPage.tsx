import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Testimonial as TestimonialType, insertTestimonialSchema } from "@shared/schema";
import Testimonial from "@/components/Testimonial";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Star, StarHalf } from "lucide-react";

// Extended schema with validation
const testimonialFormSchema = insertTestimonialSchema.extend({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  review: z.string().min(10, { message: "Review must be at least 10 characters" }),
  rating: z.number().min(1, { message: "Please select a rating" }).max(5),
  vehicle: z.string().min(2, { message: "Please specify the vehicle you purchased" }),
});

type TestimonialFormValues = z.infer<typeof testimonialFormSchema>;

const TestimonialsPage = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: testimonials, isLoading, error } = useQuery<TestimonialType[]>({
    queryKey: ["/api/testimonials"],
  });

  // Form setup
  const form = useForm<TestimonialFormValues>({
    resolver: zodResolver(testimonialFormSchema),
    defaultValues: {
      name: "",
      rating: 5,
      review: "",
      vehicle: "",
      imageUrl: "https://randomuser.me/api/portraits/lego/1.jpg", // Default placeholder image
    },
  });

  // Mutation for submitting a new testimonial
  const mutation = useMutation({
    mutationFn: (data: TestimonialFormValues) => {
      return apiRequest("POST", "/api/testimonials", data);
    },
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: ["/api/testimonials"] });
      setFormSubmitted(true);
      setIsSubmitting(false);
      toast({
        title: "Testimonial submitted!",
        description: "Thank you for sharing your experience with us.",
      });
      form.reset();
    },
    onError: (error) => {
      console.error("Error submitting testimonial:", error);
      setIsSubmitting(false);
      toast({
        title: "Submission failed",
        description: "There was a problem submitting your testimonial. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: TestimonialFormValues) => {
    setIsSubmitting(true);
    mutation.mutate(data);
  };

  // Rating selector component
  const RatingSelector = ({ value, onChange }: { value: number; onChange: (value: number) => void }) => {
    return (
      <div className="flex space-x-2 items-center">
        {[1, 2, 3, 4, 5].map((rating) => (
          <button
            key={rating}
            type="button"
            className={`p-1 rounded-full transition-colors ${
              rating <= value ? "text-yellow-400" : "text-gray-300"
            }`}
            onClick={() => onChange(rating)}
          >
            <Star size={24} />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="py-16 bg-black text-white">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-4 text-white">Customer Testimonials</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Read what our customers have to say about their experience with 89 Auto Sales.
            We pride ourselves on customer satisfaction and service excellence.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="mb-16">
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-red-600" />
              <span className="ml-2 text-gray-300">Loading testimonials...</span>
            </div>
          ) : error ? (
            <Alert className="max-w-md mx-auto bg-red-900/30 text-white border border-red-600">
              <AlertTitle className="text-red-500">Error</AlertTitle>
              <AlertDescription>
                There was a problem loading testimonials. Please try again later.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials && testimonials.length > 0 ? (
                testimonials.map((testimonial) => (
                  <Testimonial key={testimonial.id} testimonial={testimonial} />
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <p className="text-gray-300 mb-4">No testimonials yet. Be the first to share your experience!</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Submit Testimonial Form */}
        <div className="max-w-2xl mx-auto" id="submit-testimonial">
          <Card className="border border-red-600 bg-zinc-900 text-white">
            <CardHeader>
              <CardTitle className="text-red-600">Share Your Experience</CardTitle>
              <CardDescription className="text-gray-400">
                Tell us about your experience with 89 Auto Sales. Your feedback helps us improve and
                helps others make informed decisions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {formSubmitted ? (
                <div className="text-center py-6">
                  <div className="bg-red-900/30 text-white border border-red-600 p-4 rounded-md mb-4">
                    <h3 className="font-semibold text-lg mb-2 text-red-500">Thank You for Your Feedback!</h3>
                    <p>Your testimonial has been submitted successfully and will be displayed after review.</p>
                  </div>
                  <Button onClick={() => setFormSubmitted(false)} variant="outline" 
                    className="bg-transparent hover:bg-red-700 text-white border-red-600 hover:border-red-700">
                    Submit Another
                  </Button>
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Your Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your name" className="bg-zinc-800 border-zinc-700" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="rating"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Your Rating</FormLabel>
                          <FormControl>
                            <RatingSelector 
                              value={field.value} 
                              onChange={field.onChange} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="vehicle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Vehicle Purchased</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Toyota Camry, Honda Civic" className="bg-zinc-800 border-zinc-700" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="review"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Your Review</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your experience..." 
                              className="min-h-[120px] bg-zinc-800 border-zinc-700" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription className="text-gray-400">
                            Share details about your purchasing experience, customer service, or anything else you'd like others to know.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full bg-red-600 hover:bg-red-700 text-white" 
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        "Submit Testimonial"
                      )}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TestimonialsPage;