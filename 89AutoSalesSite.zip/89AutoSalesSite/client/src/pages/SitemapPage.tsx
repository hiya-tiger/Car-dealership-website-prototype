import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";
import { ExternalLink, Home, Car, DollarSign, Users, Phone, MapPin, Wrench, FileText, Shield, Star } from "lucide-react";

interface SitemapGroup {
  title: string;
  icon: React.ReactNode;
  links: {
    name: string;
    path: string;
    external?: boolean;
  }[];
}

export default function SitemapPage() {
  const sitemapGroups: SitemapGroup[] = [
    {
      title: "Main Pages",
      icon: <Home className="h-5 w-5 text-primary" />,
      links: [
        { name: "Home", path: "/" },
        { name: "Inventory", path: "/inventory" },
        { name: "Financing", path: "/financing" },
        { name: "About Us", path: "/about" },
        { name: "Contact Us", path: "/contact" },
        { name: "Location", path: "/location" },
      ]
    },
    {
      title: "Vehicle Services",
      icon: <Car className="h-5 w-5 text-primary" />,
      links: [
        { name: "Service Center", path: "/service" },
        { name: "Virtual Showroom", path: "/virtual-showroom" },
        { name: "Special Offers", path: "/inventory?special=true" },
        { name: "Trade-In Appraisal", path: "/contact?type=trade-in" },
      ]
    },
    {
      title: "Resources",
      icon: <FileText className="h-5 w-5 text-primary" />,
      links: [
        { name: "Buyer Resources", path: "/buyer-resources" },
        { name: "Testimonials", path: "/testimonials" },
        { name: "FAQ", path: "/buyer-resources?guide=faq" },
        { name: "Warranty Information", path: "/buyer-resources?guide=warranties" },
        { name: "Financing Options", path: "/buyer-resources?guide=financing" },
      ]
    },
    {
      title: "Legal",
      icon: <Shield className="h-5 w-5 text-primary" />,
      links: [
        { name: "Privacy Policy", path: "/privacy-policy" },
        { name: "Terms of Service", path: "/terms-of-service" },
        { name: "Sitemap", path: "/sitemap" },
      ]
    },
    {
      title: "External Links",
      icon: <ExternalLink className="h-5 w-5 text-primary" />,
      links: [
        { name: "CarFax", path: "https://www.carfax.com", external: true },
        { name: "DMV", path: "https://www.dmv.ca.gov", external: true },
      ]
    },
  ];

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-4">Sitemap</h1>
      <p className="text-muted-foreground mb-8">
        A comprehensive list of all pages available on the 89 Autosales website.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sitemapGroups.map((group, index) => (
          <Card key={index} className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                {group.icon}
                <CardTitle className="text-lg">{group.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {group.links.map((link, idx) => (
                  <li key={idx} className="text-zinc-300 hover:text-red-500 transition-colors">
                    {link.external ? (
                      <a 
                        href={link.path} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1"
                      >
                        {link.name} <ExternalLink className="h-3 w-3" />
                      </a>
                    ) : (
                      <Link href={link.path}>{link.name}</Link>
                    )}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      <Separator className="my-8 bg-zinc-800" />

      <div className="text-center">
        <h2 className="text-xl font-semibold mb-2">Can't find what you're looking for?</h2>
        <p className="text-muted-foreground mb-4">
          Contact our customer support team for assistance.
        </p>
        <div className="flex justify-center gap-4">
          <Link href="/contact" className="text-primary hover:text-red-500 transition-colors">
            Contact Us
          </Link>
          <a 
            href="tel:+15551234567" 
            className="text-primary hover:text-red-500 transition-colors"
          >
            Call (555) 123-4567
          </a>
        </div>
      </div>
    </div>
  );
}