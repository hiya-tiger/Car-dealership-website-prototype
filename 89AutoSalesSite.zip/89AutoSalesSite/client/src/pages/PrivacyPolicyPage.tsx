import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const PrivacyPolicyPage = () => {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-2">Privacy Policy</h1>
      <p className="text-muted-foreground mb-2">Last Updated: April 1, 2025</p>
      <p className="text-muted-foreground mb-8">
        This Privacy Policy describes how we collect, use, and share your personal information when you visit our website or use our services.
      </p>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Information We Collect</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            When you visit our website or use our services, we may collect the following types of information:
          </p>

          <div className="space-y-2">
            <h3 className="font-semibold">Personal Information</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Name, email address, phone number, and mailing address</li>
              <li>Driver's license information (when test driving or purchasing a vehicle)</li>
              <li>Financial information (when applying for financing)</li>
              <li>Vehicle information (make, model, VIN, etc.)</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Automatically Collected Information</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>IP address and device information</li>
              <li>Browser type and settings</li>
              <li>Usage data and browsing history on our website</li>
              <li>Cookies and similar tracking technologies</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>How We Use Your Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            We use the information we collect for various purposes, including:
          </p>

          <ul className="list-disc pl-6 space-y-1">
            <li>Providing and improving our products and services</li>
            <li>Processing vehicle purchases, service appointments, and financing applications</li>
            <li>Communicating with you about our products, services, and promotions</li>
            <li>Responding to your inquiries and providing customer support</li>
            <li>Conducting research and analytics to improve our website and services</li>
            <li>Complying with legal obligations and protecting our rights</li>
          </ul>
        </CardContent>
      </Card>

      <Accordion type="single" collapsible className="mb-8">
        <AccordionItem value="sharing">
          <AccordionTrigger>Information Sharing and Disclosure</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              We may share your personal information with the following categories of third parties:
            </p>

            <div className="space-y-2">
              <h3 className="font-semibold">Service Providers</h3>
              <p>
                We share information with trusted service providers who perform services on our behalf, such as website hosting, data analysis, payment processing, and customer service. These service providers are contractually obligated to use your information only for the purpose of providing services to us.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Financial Institutions and Lenders</h3>
              <p>
                When you apply for financing through our dealership, we may share your information with financial institutions and lenders to process your application and secure financing for your vehicle purchase.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Vehicle Manufacturers</h3>
              <p>
                We may share information with vehicle manufacturers for warranty registration, recall purposes, and to facilitate manufacturer-specific programs or incentives.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Legal Requirements</h3>
              <p>
                We may disclose your information when required by law, such as in response to a subpoena, court order, or other legal process, or to comply with government reporting obligations.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Business Transfers</h3>
              <p>
                If our dealership is sold or merged with another company, your information may be transferred to the new owner. In such a case, we will provide notice before your information becomes subject to a different privacy policy.
              </p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="cookies">
          <AccordionTrigger>Cookies and Tracking Technologies</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              Our website uses cookies and similar tracking technologies to collect information about your browsing activities. Cookies are small data files stored on your device that help us improve our website and your experience, remember your preferences, and understand how visitors use our website.
            </p>

            <div className="space-y-2">
              <h3 className="font-semibold">Types of Cookies We Use</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Essential Cookies:</strong> Required for the website to function properly</li>
                <li><strong>Analytical/Performance Cookies:</strong> Help us understand how visitors interact with our website</li>
                <li><strong>Functionality Cookies:</strong> Allow us to remember your preferences and settings</li>
                <li><strong>Targeting Cookies:</strong> Used to deliver relevant advertisements and track their effectiveness</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Managing Cookies</h3>
              <p>
                Most web browsers allow you to manage your cookie preferences. You can set your browser to refuse cookies or delete certain cookies. However, if you disable or refuse cookies, some parts of our website may not function properly.
              </p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="security">
          <AccordionTrigger>Data Security</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              We implement appropriate security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction. These measures include:
            </p>

            <ul className="list-disc pl-6 space-y-1">
              <li>Encryption of sensitive data</li>
              <li>Secure networks and servers</li>
              <li>Regular security assessments and audits</li>
              <li>Employee training on data security practices</li>
              <li>Access controls and authentication procedures</li>
            </ul>

            <p>
              While we strive to use commercially acceptable means to protect your personal information, no method of transmission over the Internet or electronic storage is 100% secure. We cannot guarantee absolute security of your information.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="rights">
          <AccordionTrigger>Your Privacy Rights</AccordionTrigger>
          <AccordionContent className="space-y-4">
            <p>
              Depending on your location, you may have certain rights regarding your personal information, including:
            </p>

            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Right to Access:</strong> You can request a copy of the personal information we hold about you.</li>
              <li><strong>Right to Rectification:</strong> You can request that we correct inaccurate or incomplete information about you.</li>
              <li><strong>Right to Deletion:</strong> You can request that we delete your personal information in certain circumstances.</li>
              <li><strong>Right to Restrict Processing:</strong> You can request that we restrict the processing of your information in certain circumstances.</li>
              <li><strong>Right to Data Portability:</strong> You can request a copy of your information in a structured, commonly used, and machine-readable format.</li>
              <li><strong>Right to Object:</strong> You can object to our processing of your personal information in certain circumstances.</li>
            </ul>

            <p>
              To exercise these rights, please contact us using the information provided in the "Contact Us" section below. Please note that these rights may be limited in some circumstances by applicable law.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="children">
          <AccordionTrigger>Children's Privacy</AccordionTrigger>
          <AccordionContent>
            <p>
              Our website and services are not directed to children under the age of 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us so that we can take appropriate action.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="changes">
          <AccordionTrigger>Changes to This Privacy Policy</AccordionTrigger>
          <AccordionContent>
            <p>
              We may update this Privacy Policy from time to time to reflect changes in our practices or for other operational, legal, or regulatory reasons. We will post the updated Privacy Policy on our website and update the "Last Updated" date at the top of this page. We encourage you to review this Privacy Policy periodically to stay informed about how we collect, use, and protect your information.
            </p>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Card>
        <CardHeader>
          <CardTitle>Contact Us</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            If you have any questions, concerns, or requests regarding this Privacy Policy or the way we handle your personal information, please contact us at:
          </p>

          <address className="not-italic space-y-2 mb-4">
            <div>89 Autosales</div>
            <div>506055 ON-89</div>
            <div>Mulmur, ON L9V 0N6, Canada</div>
            <div>Email: privacy@89autosales.com</div>
            <div>Phone: (705) 555-8989</div>
          </address>

          <p>
            We will respond to your request within a reasonable timeframe.
          </p>
        </CardContent>
      </Card>

      <Separator className="my-8" />

      <div className="text-center text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} 89 Autosales. All rights reserved.</p>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;