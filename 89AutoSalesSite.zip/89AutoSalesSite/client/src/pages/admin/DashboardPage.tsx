import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ChevronRight, Car, MessageSquare, CreditCard, Calendar } from "lucide-react";
import InventoryManagement from "@/pages/admin/InventoryManagement";

const DashboardPage = () => {
  const [activeTab, setActiveTab] = useState("inventory");

  return (
    <div className="container mx-auto p-4 md:p-6">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-primary">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your dealership inventory and customer interactions</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <QuickStatCard 
          title="Total Vehicles" 
          value="24" 
          description="Vehicles in inventory"
          icon={<Car className="h-5 w-5" />}
        />
        <QuickStatCard 
          title="Customer Inquiries" 
          value="18" 
          description="New in last 30 days"
          icon={<MessageSquare className="h-5 w-5" />}
        />
        <QuickStatCard 
          title="Upcoming Appointments" 
          value="7" 
          description="Scheduled this week"
          icon={<Calendar className="h-5 w-5" />}
        />
      </div>

      <Tabs defaultValue="inventory" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="inquiries">Inquiries</TabsTrigger>
          <TabsTrigger value="appointments">Appointments</TabsTrigger>
          <TabsTrigger value="financing">Financing</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inventory">
          <InventoryManagement />
        </TabsContent>
        
        <TabsContent value="inquiries">
          <PlaceholderContent 
            title="Customer Inquiries"
            description="View and respond to customer inquiries about vehicles."
          />
        </TabsContent>
        
        <TabsContent value="appointments">
          <PlaceholderContent 
            title="Appointment Management"
            description="Schedule and manage test drives and service appointments."
          />
        </TabsContent>
        
        <TabsContent value="financing">
          <PlaceholderContent 
            title="Financing Applications"
            description="Review and process customer financing applications."
            icon={<CreditCard className="h-8 w-8 mb-4" />}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Quick stat card component
interface QuickStatCardProps {
  title: string;
  value: string;
  description: string;
  icon?: React.ReactNode;
}

const QuickStatCard = ({ title, value, description, icon }: QuickStatCardProps) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      {icon}
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      <p className="text-xs text-muted-foreground">{description}</p>
    </CardContent>
  </Card>
);

// Placeholder content for tabs not yet implemented
interface PlaceholderContentProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
}

const PlaceholderContent = ({ title, description, icon }: PlaceholderContentProps) => (
  <Card className="w-full">
    <CardHeader>
      <CardTitle>{title}</CardTitle>
      <CardDescription>{description}</CardDescription>
    </CardHeader>
    <CardContent className="flex flex-col items-center justify-center p-12">
      {icon}
      <p className="text-center text-muted-foreground mb-4">
        This feature is coming soon. Check back later for updates.
      </p>
      <Button variant="outline">
        Coming Soon
        <ChevronRight className="ml-2 h-4 w-4" />
      </Button>
    </CardContent>
    <CardFooter className="border-t px-6 py-4">
      <p className="text-sm text-muted-foreground">
        We're working on making this feature available to you soon.
      </p>
    </CardFooter>
  </Card>
);

export default DashboardPage;