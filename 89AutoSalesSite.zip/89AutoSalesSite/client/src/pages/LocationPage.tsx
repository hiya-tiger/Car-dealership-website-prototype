import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, MapPin, Phone, Mail, Calendar, Car, Wrench, Navigation } from "lucide-react";
import { Link } from "wouter";

const LocationPage = () => {
  const dealerships = [
    {
      id: "main",
      name: "89 Auto Sales",
      address: "506055 ON-89, Mulmur, ON L9V 0N6, Canada",
      phone: "(555) 123-4567",
      email: "info@89autosales.com",
      hours: {
        monFri: "9:00 AM - 7:00 PM",
        saturday: "9:00 AM - 7:00 PM",
        sunday: "Closed"
      },
      mapUrl: "https://maps.google.com/?q=506055+ON-89,+Mulmur,+ON+L9V+0N6,+Canada",
      mapEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2866.183211300327!2d-80.0733971!3d44.074404999999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882a5a3b79270699%3A0xc6b6abe6d95bd7c1!2s506055%20ON-89%2C%20Mulmur%2C%20ON%20L9V%200N6%2C%20Canada!5e0!3m2!1sen!2sus!4v1712528478407!5m2!1sen!2sus",
      services: ["Sales", "Financing", "Service", "Parts"]
    },
    {
      id: "service",
      name: "Service Center",
      address: "506055 ON-89, Mulmur, ON L9V 0N6, Canada",
      phone: "(555) 987-6543",
      email: "service@89autosales.com",
      hours: {
        monFri: "8:00 AM - 6:00 PM",
        saturday: "9:00 AM - 5:00 PM",
        sunday: "Closed"
      },
      mapUrl: "https://maps.google.com/?q=506055+ON-89,+Mulmur,+ON+L9V+0N6,+Canada",
      mapEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2866.183211300327!2d-80.0733971!3d44.074404999999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882a5a3b79270699%3A0xc6b6abe6d95bd7c1!2s506055%20ON-89%2C%20Mulmur%2C%20ON%20L9V%200N6%2C%20Canada!5e0!3m2!1sen!2sus!4v1712528478407!5m2!1sen!2sus",
      services: ["Maintenance", "Repairs", "Detailing", "Parts"]
    }
  ];

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-2">Our Locations</h1>
      <p className="text-muted-foreground mb-8">
        Visit us at one of our convenient locations. Our team is ready to assist you with all your automotive needs.
      </p>
      
      <Tabs defaultValue="main" className="mb-12">
        <TabsList className="grid max-w-[400px] grid-cols-2 mb-8">
          {dealerships.map(dealership => (
            <TabsTrigger 
              key={dealership.id} 
              value={dealership.id}
              className="text-base py-3"
            >
              {dealership.name}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {dealerships.map(dealership => (
          <TabsContent key={dealership.id} value={dealership.id}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                {/* Google Maps Embed */}
                <div className="w-full h-[400px] mb-8 rounded-lg overflow-hidden border border-gray-200">
                  <iframe 
                    src={dealership.mapEmbed}
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                    title={`${dealership.name} Location Map`}
                  ></iframe>
                </div>
                
                <div className="flex justify-center mb-8">
                  <a href={dealership.mapUrl} target="_blank" rel="noopener noreferrer" className="inline-block">
                    <Button className="bg-red-600 hover:bg-red-700">
                      <Navigation className="mr-2 h-4 w-4" />
                      Get Directions
                    </Button>
                  </a>
                </div>
                
                {/* Services offered */}
                <h2 className="text-2xl font-bold mb-4">Services Offered</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  {dealership.services.map((service, index) => (
                    <Card key={index} className="text-center">
                      <CardHeader className="pb-2">
                        {service === "Sales" && <Car className="h-8 w-8 mx-auto text-primary" />}
                        {service === "Financing" && <span className="text-3xl text-primary">$</span>}
                        {service === "Service" && <Wrench className="h-8 w-8 mx-auto text-primary" />}
                        {service === "Parts" && <span className="text-3xl text-primary">⚙️</span>}
                        {service === "Maintenance" && <Wrench className="h-8 w-8 mx-auto text-primary" />}
                        {service === "Repairs" && <span className="text-3xl text-primary">🔧</span>}
                        {service === "Detailing" && <span className="text-3xl text-primary">✨</span>}
                      </CardHeader>
                      <CardContent>
                        <h3 className="font-medium">{service}</h3>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                {/* Get in touch section */}
                <Card>
                  <CardHeader>
                    <CardTitle>Schedule a Visit</CardTitle>
                    <CardDescription>
                      Our team is ready to assist you. Schedule an appointment or visit us during business hours.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-medium mb-3">Book an Appointment</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Schedule a test drive, service appointment, or consultation with our financing team.
                      </p>
                      <Link href="/contact">
                        <Button>
                          <Calendar className="mr-2 h-4 w-4" />
                          Schedule Now
                        </Button>
                      </Link>
                    </div>
                    <div>
                      <h3 className="font-medium mb-3">Visit Our Showroom</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Walk in during business hours to browse our inventory and speak with our team.
                      </p>
                      <a href={dealership.mapUrl} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline">
                          <MapPin className="mr-2 h-4 w-4" />
                          Get Directions
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                {/* Contact Information */}
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>{dealership.name}</CardTitle>
                    <CardDescription>Contact information and hours</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 mr-3 text-muted-foreground" />
                      <span>{dealership.address}</span>
                    </div>
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 mr-3 text-muted-foreground" />
                      <span>{dealership.phone}</span>
                    </div>
                    <div className="flex items-center">
                      <Mail className="h-5 w-5 mr-3 text-muted-foreground" />
                      <a href={`mailto:${dealership.email}`} className="text-primary">
                        {dealership.email}
                      </a>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Business Hours */}
                <Card>
                  <CardHeader>
                    <CardTitle>Business Hours</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start">
                      <Clock className="h-5 w-5 mr-3 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Monday - Friday</p>
                        <p className="text-muted-foreground">{dealership.hours.monFri}</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Clock className="h-5 w-5 mr-3 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Saturday</p>
                        <p className="text-muted-foreground">{dealership.hours.saturday}</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Clock className="h-5 w-5 mr-3 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Sunday</p>
                        <p className="text-muted-foreground">{dealership.hours.sunday}</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <p className="text-sm text-muted-foreground">
                      Holiday hours may vary. Please call to confirm.
                    </p>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
      
      {/* Local attractions section */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-4">Local Attractions While You Visit</h2>
        <p className="text-muted-foreground mb-6">
          While your vehicle is being serviced, check out these nearby attractions in the beautiful Mulmur area.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Dufferin County Museum</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Explore the history and heritage of Dufferin County at this museum featuring local artifacts and exhibitions.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Pine River Fishing Area</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Enjoy fishing or just taking a peaceful walk along the Pine River, known for its natural beauty and tranquility.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Mansfield Outdoor Centre</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Visit this year-round recreational facility offering hiking trails, cross-country skiing, and various outdoor activities.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default LocationPage;