import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Car, CheckCircle2, DollarSign, Info } from "lucide-react";

// Define the schema for our trade-in form
const tradeInSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  make: z.string().min(1, { message: "Make is required" }),
  model: z.string().min(1, { message: "Model is required" }),
  year: z.string().min(4, { message: "Valid year is required" }),
  mileage: z.string().min(1, { message: "Mileage is required" }),
  vin: z.string().optional(),
  condition: z.string().min(1, { message: "Please select a condition" }),
  features: z.string().optional(),
  comments: z.string().optional(),
});

type TradeInForm = z.infer<typeof tradeInSchema>;

export default function TradeInPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("info");
  
  // Set up form with react-hook-form
  const form = useForm<TradeInForm>({
    resolver: zodResolver(tradeInSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      make: "",
      model: "",
      year: "",
      mileage: "",
      vin: "",
      condition: "",
      features: "",
      comments: "",
    },
  });

  // Set up mutation for form submission
  const tradeInMutation = useMutation({
    mutationFn: (data: TradeInForm) => {
      return apiRequest("POST", "/api/trade-in", data);
    },
    onSuccess: () => {
      // Reset form on success
      form.reset();
      
      // Show success toast
      toast({
        title: "Trade-In Request Submitted",
        description: "We've received your request and will contact you shortly.",
        variant: "default",
      });
      
      // Advance to success tab
      setActiveTab("success");
      
      // Invalidate any relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/trade-in"] });
    },
    onError: (error) => {
      toast({
        title: "Submission Error",
        description: "There was a problem submitting your trade-in request. Please try again.",
        variant: "destructive",
      });
      console.error("Trade-in submission error:", error);
    },
  });

  // Form submission handler
  const onSubmit = (data: TradeInForm) => {
    tradeInMutation.mutate(data);
  };

  return (
    <div className="container mx-auto py-12 px-4">
      <Helmet>
        <title>Vehicle Trade-In | 89 Autosales</title>
        <meta name="description" content="Get a fair market appraisal for your vehicle trade-in at 89 Autosales - your trusted pre-owned car dealership." />
      </Helmet>
      
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-gradient-to-r from-red-500 to-red-700 text-transparent bg-clip-text">Trade-In Your Vehicle</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Why Trade with 89 Autosales?</h2>
            <p className="mb-6 text-zinc-300">
              Trading in your current vehicle at 89 Autosales is the easiest way to upgrade to a newer model 
              while potentially reducing your new vehicle payments. Our transparent trade-in process ensures 
              you get fair market value for your current vehicle.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="h-7 w-7 mt-1 flex-shrink-0 text-red-600" />
                <div>
                  <h3 className="text-lg font-semibold">Hassle-Free Process</h3>
                  <p className="text-zinc-400">No need to deal with selling your vehicle privately or negotiating with multiple parties.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <CheckCircle2 className="h-7 w-7 mt-1 flex-shrink-0 text-red-600" />
                <div>
                  <h3 className="text-lg font-semibold">Fair Market Value</h3>
                  <p className="text-zinc-400">We use current market data and multiple sources to evaluate your vehicle's worth.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <CheckCircle2 className="h-7 w-7 mt-1 flex-shrink-0 text-red-600" />
                <div>
                  <h3 className="text-lg font-semibold">Potential Tax Savings</h3>
                  <p className="text-zinc-400">In many cases, trading in can reduce the sales tax on your new vehicle purchase.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <CheckCircle2 className="h-7 w-7 mt-1 flex-shrink-0 text-red-600" />
                <div>
                  <h3 className="text-lg font-semibold">Immediate Credit</h3>
                  <p className="text-zinc-400">The value of your trade is immediately applied to your new vehicle purchase.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <img 
              src="https://images.unsplash.com/photo-1560574188-6a6774965120?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
              alt="Vehicle Trade-In" 
              className="rounded-lg w-full h-auto shadow-lg mb-6"
            />
            
            <div className="bg-zinc-900 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Info className="mr-2 text-red-600" /> What to Expect
              </h3>
              <ol className="list-decimal pl-5 space-y-2 text-zinc-300">
                <li>Fill out the form with your vehicle details</li>
                <li>Our team will review your information</li>
                <li>We'll contact you within 24 hours with an initial assessment</li>
                <li>Schedule an in-person inspection at our dealership</li>
                <li>Receive your final trade-in offer</li>
              </ol>
            </div>
          </div>
        </div>
        
        <Separator className="my-8 bg-zinc-800" />
        
        <div className="max-w-3xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-zinc-900">
              <TabsTrigger value="info" className="data-[state=active]:bg-red-800">
                <Car className="mr-2 h-4 w-4" /> Vehicle Info
              </TabsTrigger>
              <TabsTrigger value="value" className="data-[state=active]:bg-red-800">
                <DollarSign className="mr-2 h-4 w-4" /> Value Factors
              </TabsTrigger>
              <TabsTrigger value="success" disabled={activeTab !== "success"} className="data-[state=active]:bg-red-800">
                <CheckCircle2 className="mr-2 h-4 w-4" /> Submitted
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="info" className="mt-6">
              <Card className="border-zinc-800 bg-black">
                <CardHeader>
                  <CardTitle>Vehicle Trade-In Request</CardTitle>
                  <CardDescription>
                    Complete the form below to start your trade-in appraisal.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Contact Information */}
                        <div className="space-y-4">
                          <h3 className="text-lg font-medium">Contact Information</h3>
                          
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="John Doe" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                  <Input placeholder="john.doe@example.com" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone Number</FormLabel>
                                <FormControl>
                                  <Input placeholder="(555) 123-4567" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {/* Vehicle Information */}
                        <div className="space-y-4">
                          <h3 className="text-lg font-medium">Vehicle Information</h3>
                          
                          <FormField
                            control={form.control}
                            name="make"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Make</FormLabel>
                                <FormControl>
                                  <Input placeholder="Toyota, Honda, Ford, etc." {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="model"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Model</FormLabel>
                                <FormControl>
                                  <Input placeholder="Camry, Civic, F-150, etc." {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="year"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Year</FormLabel>
                                  <FormControl>
                                    <Input placeholder="2018" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="mileage"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Mileage</FormLabel>
                                  <FormControl>
                                    <Input placeholder="50000" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="condition"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Vehicle Condition</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select condition" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="excellent">Excellent - Like New</SelectItem>
                                  <SelectItem value="good">Good - Minor Wear</SelectItem>
                                  <SelectItem value="fair">Fair - Normal Wear</SelectItem>
                                  <SelectItem value="poor">Poor - Significant Issues</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="vin"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>VIN (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Vehicle Identification Number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="features"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Key Features (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="Leather seats, sunroof, navigation, etc." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="comments"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Additional Comments (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Please share any additional information about your vehicle, including known issues, accident history, or special features." 
                                {...field}
                                className="min-h-[100px]"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-between">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setActiveTab("value")}
                        >
                          Value Factors
                        </Button>
                        
                        <Button 
                          type="submit" 
                          className="bg-red-600 hover:bg-red-700"
                          disabled={tradeInMutation.isPending}
                        >
                          {tradeInMutation.isPending ? "Submitting..." : "Submit Trade-In Request"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="value" className="mt-6">
              <Card className="border-zinc-800 bg-black">
                <CardHeader>
                  <CardTitle>Trade-In Value Factors</CardTitle>
                  <CardDescription>
                    Understanding what affects your vehicle's trade-in value
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Market Demand</h3>
                      <p className="text-zinc-400">
                        Popular models that are in high demand typically receive higher trade-in values. 
                        Market trends and seasonal factors can also affect your vehicle's value.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Vehicle Condition</h3>
                      <p className="text-zinc-400">
                        Vehicles in better condition receive higher trade-in values. We evaluate exterior, 
                        interior, mechanical condition, and service history.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Mileage</h3>
                      <p className="text-zinc-400">
                        Lower mileage vehicles typically have higher values. However, consistent maintenance 
                        can help offset higher mileage.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Age & Depreciation</h3>
                      <p className="text-zinc-400">
                        Newer vehicles generally command higher values. Most vehicles experience their steepest 
                        depreciation in the first few years.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Options & Features</h3>
                      <p className="text-zinc-400">
                        Premium features, technology packages, and desirable options can increase your 
                        vehicle's trade-in value.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Accident History</h3>
                      <p className="text-zinc-400">
                        Vehicles with a clean history typically command higher values than those with 
                        accident records or damage history.
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline"
                    onClick={() => setActiveTab("info")}
                    className="w-full"
                  >
                    Back to Trade-In Form
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="success" className="mt-6">
              <Card className="border-zinc-800 bg-black">
                <CardHeader>
                  <CardTitle className="flex items-center text-green-500">
                    <CheckCircle2 className="mr-2 h-6 w-6" /> 
                    Trade-In Request Submitted
                  </CardTitle>
                  <CardDescription>
                    Thank you for your trade-in request with 89 Autosales.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-6">
                    <div className="bg-green-900/20 inline-flex rounded-full p-6 mb-6">
                      <CheckCircle2 className="h-16 w-16 text-green-500" />
                    </div>
                    <h3 className="text-2xl font-semibold mb-4">What Happens Next</h3>
                    <p className="text-zinc-300 max-w-md mx-auto">
                      Our trade-in specialists will review your submission and contact you within 
                      24 business hours to discuss the next steps or schedule an in-person evaluation.
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-center">
                  <Button 
                    onClick={() => {
                      setActiveTab("info");
                      form.reset();
                    }}
                    variant="outline"
                  >
                    Submit Another Trade-In
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}