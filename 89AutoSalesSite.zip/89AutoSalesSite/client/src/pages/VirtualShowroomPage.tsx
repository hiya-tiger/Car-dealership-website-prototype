import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Vehicle } from "@shared/schema";
import ModelViewer from "@/components/3d/ModelViewer";
import InteriorViewer from "@/components/3d/InteriorViewer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Car, Camera } from "lucide-react";

const VirtualShowroomPage = () => {
  const params = useParams<{ id: string }>();
  const vehicleId = params?.id ? parseInt(params.id) : 0;
  
  // Fetch vehicle details
  const { data: vehicle, isLoading, error } = useQuery<Vehicle>({
    queryKey: [`/api/vehicles/${vehicleId}`],
    enabled: !isNaN(vehicleId),
  });

  const [viewMode, setViewMode] = useState<"exterior" | "interior">("exterior");

  // Format price with commas
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-16 px-4">
        <div className="flex flex-col items-center justify-center py-16">
          <div className="w-16 h-16 border-4 border-t-primary border-r-gray-200 border-b-gray-200 border-l-gray-200 rounded-full animate-spin"></div>
          <p className="mt-4 text-lg">Loading showroom...</p>
        </div>
      </div>
    );
  }

  if (error || !vehicle) {
    return (
      <div className="container mx-auto py-16 px-4">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-red-500 mb-4">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          <h2 className="text-2xl font-bold mb-2">Vehicle Not Found</h2>
          <p className="text-gray-600 mb-6">The vehicle you're looking for doesn't exist or has been removed.</p>
          <Link href="/inventory">
            <Button>Browse Our Inventory</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Breadcrumb Navigation */}
      <div className="bg-gray-100 py-3">
        <div className="container mx-auto px-4">
          <div className="text-sm text-neutral-600">
            <Link href="/" className="hover:text-primary">Home</Link>
            <span className="mx-2">/</span>
            <Link href="/inventory" className="hover:text-primary">Inventory</Link>
            <span className="mx-2">/</span>
            <Link href={`/vehicles/${vehicle.id}`} className="hover:text-primary">
              {vehicle.year} {vehicle.make} {vehicle.model}
            </Link>
            <span className="mx-2">/</span>
            <span className="text-neutral-400">Virtual Showroom</span>
          </div>
        </div>
      </div>

      {/* Hero section */}
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Virtual Showroom</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Experience the {vehicle.year} {vehicle.make} {vehicle.model} in immersive 3D. 
            Explore its exterior design and interior features.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            {/* View Mode Tabs */}
            <Tabs defaultValue="exterior" className="mb-6"
              onValueChange={(value) => setViewMode(value as "exterior" | "interior")}
            >
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="exterior" className="flex items-center gap-2">
                  <Car className="h-4 w-4" />
                  <span>Exterior</span>
                </TabsTrigger>
                <TabsTrigger value="interior" className="flex items-center gap-2">
                  <Camera className="h-4 w-4" />
                  <span>Interior</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="exterior">
                <div className="bg-white p-4 rounded-lg shadow mb-6">
                  <h2 className="text-2xl font-bold mb-2">Exterior 3D View</h2>
                  <p className="text-gray-600 mb-4">
                    Rotate, zoom and explore the vehicle's exterior from all angles. 
                    Click and drag to rotate, use scroll to zoom in and out.
                  </p>
                </div>
                <ModelViewer vehicleId={vehicle.id} />
              </TabsContent>
              
              <TabsContent value="interior">
                <div className="bg-white p-4 rounded-lg shadow mb-6">
                  <h2 className="text-2xl font-bold mb-2">Interior 360° View</h2>
                  <p className="text-gray-600 mb-4">
                    Step inside and explore the interior features. Look around to experience 
                    the driver's perspective and premium interior details.
                  </p>
                </div>
                <InteriorViewer vehicleId={vehicle.id} />
              </TabsContent>
            </Tabs>
            
            {/* Feature highlights */}
            <Card className="mt-8">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Key Features</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {vehicle.features && vehicle.features.slice(0, 6).map((feature, index) => (
                    <div key={index} className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2 mt-0.5 flex-shrink-0">
                        <polyline points="9 11 12 14 22 4"></polyline>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                      </svg>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-0">
                <div className="bg-primary text-white p-6">
                  <h2 className="text-2xl font-bold">{formatPrice(vehicle.price)}</h2>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{vehicle.year} {vehicle.make} {vehicle.model}</h3>
                    <div className="flex flex-wrap gap-2 text-sm">
                      <span className="bg-gray-100 px-2 py-1 rounded-md">{vehicle.mileage.toLocaleString()} miles</span>
                      <span className="bg-gray-100 px-2 py-1 rounded-md">{vehicle.transmission}</span>
                      <span className="bg-gray-100 px-2 py-1 rounded-md">{vehicle.exteriorColor}</span>
                    </div>
                  </div>
                  
                  <hr />
                  
                  <div className="space-y-3">
                    <Link href={`/vehicles/${vehicle.id}`}>
                      <Button className="w-full" variant="outline">
                        View Vehicle Details
                      </Button>
                    </Link>
                    <Link href={`/vehicles/${vehicle.id}#inquiry`}>
                      <Button className="w-full">
                        Request More Information
                      </Button>
                    </Link>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg text-sm mt-4">
                    <p className="italic">
                      "The virtual showroom provides a comprehensive view of this {vehicle.make} {vehicle.model}. 
                      Experience it in person at 89 Auto Sales today!"
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Back buttons */}
        <div className="flex justify-between mt-8">
          <Link href={`/vehicles/${vehicle.id}`}>
            <Button variant="outline">
              &larr; Back to Vehicle Details
            </Button>
          </Link>
          <Link href="/inventory">
            <Button variant="outline">
              Browse More Vehicles
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default VirtualShowroomPage;