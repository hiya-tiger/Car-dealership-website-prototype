import { useQuery } from "@tanstack/react-query";
import { Vehicle, Testimonial as TestimonialType } from "@shared/schema";
import QuickSearch from "@/components/QuickSearch";
import VehicleCard from "@/components/VehicleCard";
import ServicesSection from "@/components/ServicesSection";
import FinancingCalculator from "@/components/FinancingCalculator";
import Testimonial from "@/components/Testimonial";
import CallToAction from "@/components/CallToAction";
import { ServiceCarousel } from "@/components/ServiceCarousel";
import { Link } from "wouter";

const HomePage = () => {
  const { data: featuredVehicles, isLoading: isLoadingVehicles } = useQuery<Vehicle[]>({
    queryKey: ["/api/vehicles/featured"],
  });

  const { data: testimonials, isLoading: isLoadingTestimonials } = useQuery<TestimonialType[]>({
    queryKey: ["/api/testimonials"],
  });

  return (
    <>
      {/* Welcome and Service Carousel Section */}
      <section className="py-12 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Welcome to 89 Autosales</h1>
            <p className="text-gray-400 max-w-3xl mx-auto">
              Your premier destination for quality pre-owned vehicles. 
              Discover exceptional service and unbeatable value with our dedicated team.
            </p>
          </div>
          
          <ServiceCarousel />
        </div>
      </section>

      {/* Hero Section with Search */}
      <section className="relative bg-gradient-to-r from-primary to-primary-dark text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Find Your Perfect Drive</h2>
            <p className="text-xl mb-8 text-gray-100">Extensive selection of premium used vehicles at competitive prices</p>
            
            {/* Quick Search Component */}
            <QuickSearch />
          </div>
        </div>
        <div className="absolute bottom-0 right-0 w-1/3 h-full hidden lg:block">
          <img 
            src="https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
            alt="Luxury car" 
            className="w-full h-full object-cover rounded-l-3xl opacity-80"
          />
        </div>
      </section>

      {/* Featured Vehicles Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold text-neutral-900">Featured Vehicles</h2>
            <Link href="/inventory" className="text-primary hover:text-primary-dark font-medium flex items-center transition-colors">
              View All Inventory 
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </Link>
          </div>
          
          {/* Vehicle Cards Grid */}
          {isLoadingVehicles ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden h-96 animate-pulse">
                  <div className="h-48 bg-gray-200"></div>
                  <div className="p-4 space-y-4">
                    <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    <div className="flex justify-between">
                      <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                      <div className="h-6 bg-gray-200 rounded w-1/4"></div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded"></div>
                    </div>
                    <div className="flex space-x-2">
                      <div className="h-10 bg-gray-200 rounded flex-1"></div>
                      <div className="h-10 bg-gray-200 rounded w-10"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {featuredVehicles && featuredVehicles.length > 0 ? (
                featuredVehicles.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} />
                ))
              ) : (
                <p className="col-span-full text-center text-neutral-600">No featured vehicles available</p>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Services Section */}
      <ServicesSection />

      {/* Financing Preview Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-neutral-900 mb-4">Flexible Financing Solutions</h2>
              <p className="text-lg text-neutral-700 mb-6">We work with multiple lenders to find the best rates and terms for your financial situation.</p>
              
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Competitive Interest Rates</h3>
                    <p className="text-neutral-600">Access to special rates through our lending partners</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Flexible Term Options</h3>
                    <p className="text-neutral-600">Choose from 36-84 month terms to fit your budget</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-semibold text-neutral-800">Quick Pre-Approval</h3>
                    <p className="text-neutral-600">Get pre-approved in minutes without affecting your credit score</p>
                  </div>
                </li>
              </ul>
              
              <div className="flex flex-wrap gap-4">
                <Link href="/financing">
                  <button className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-md transition-colors">
                    Explore Financing Options
                  </button>
                </Link>
                <Link href="/financing">
                  <button className="bg-white border border-primary text-primary hover:bg-gray-50 font-medium py-3 px-6 rounded-md transition-colors">
                    Payment Calculator
                  </button>
                </Link>
              </div>
            </div>
            
            {/* Simple Calculator Preview */}
            <FinancingCalculator />
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-neutral-900 mb-2">Customer Testimonials</h2>
          <p className="text-center text-neutral-600 mb-12 max-w-3xl mx-auto">
            Don't just take our word for it. See what our customers have to say about their car buying experience.
          </p>
          
          {isLoadingTestimonials ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-md p-6 animate-pulse">
                  <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-6"></div>
                  <div className="flex items-center">
                    <div className="h-12 w-12 rounded-full bg-gray-200 mr-4"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-32"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials && testimonials.length > 0 ? (
                testimonials.map((testimonial) => (
                  <Testimonial key={testimonial.id} testimonial={testimonial} />
                ))
              ) : (
                <p className="col-span-full text-center text-neutral-600">No testimonials available</p>
              )}
            </div>
          )}
          
          <div className="text-center mt-12">
            <Link href="/testimonials" className="text-primary hover:text-primary-dark font-medium inline-flex items-center transition-colors">
              Read More Testimonials 
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <CallToAction />
    </>
  );
};

export default HomePage;
