import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wrench, Calendar as CalendarIcon, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

// Form schema for service booking
const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  make: z.string().min(1, "Please select a make"),
  model: z.string().min(1, "Please enter a model"),
  year: z.string().min(4, "Please enter a valid year"),
  serviceType: z.enum(["maintenance", "repair", "inspection", "other"], {
    required_error: "Please select a service type",
  }),
  serviceDate: z.date({
    required_error: "Please select a date",
  }),
  serviceTime: z.string({
    required_error: "Please select a time",
  }),
  description: z.string().optional(),
  preferredContact: z.enum(["email", "phone", "text"], {
    required_error: "Please select your preferred contact method",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const ServicePage = () => {
  const { toast } = useToast();
  
  // Set up the form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      make: "",
      model: "",
      year: "",
      serviceType: "maintenance",
      description: "",
      preferredContact: "email",
    },
  });
  
  // Set up mutation for form submission
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      return await apiRequest("/api/service-appointments", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Service Appointment Scheduled",
        description: "We'll be in touch to confirm your appointment soon.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Something went wrong",
        description: "Please try again or contact us directly by phone.",
        variant: "destructive",
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (data: FormValues) => {
    mutation.mutate(data);
  };
  
  // Available time slots for service appointments
  const timeSlots = [
    "8:00 AM", "8:30 AM", "9:00 AM", "9:30 AM", 
    "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
    "1:00 PM", "1:30 PM", "2:00 PM", "2:30 PM",
    "3:00 PM", "3:30 PM", "4:00 PM"
  ];
  
  // Service options with descriptions
  const serviceOptions = [
    {
      id: "maintenance",
      title: "Routine Maintenance",
      description: "Oil changes, filter replacements, fluid checks, and other regular maintenance services.",
      price: "Starting at $39.95",
      timeEstimate: "30-60 minutes",
      icon: <Wrench className="h-12 w-12 text-primary" />,
    },
    {
      id: "repair",
      title: "Repair Service",
      description: "Diagnostic and repair services for mechanical or electrical issues with your vehicle.",
      price: "Varies by service",
      timeEstimate: "1-3 days on average",
      icon: <span className="text-5xl text-primary">🔧</span>,
    },
    {
      id: "inspection",
      title: "Multi-Point Inspection",
      description: "Comprehensive inspection of your vehicle's key systems and components.",
      price: "$89.95",
      timeEstimate: "45-60 minutes",
      icon: <CheckCircle2 className="h-12 w-12 text-primary" />,
    },
    {
      id: "other",
      title: "Other Services",
      description: "Custom services including detailing, accessories installation, and more.",
      price: "Call for pricing",
      timeEstimate: "Varies by service",
      icon: <span className="text-5xl text-primary">⚙️</span>,
    },
  ];

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-2">Service & Maintenance</h1>
      <p className="text-muted-foreground mb-8">
        Schedule service appointments, maintenance, or repairs for your vehicle
      </p>
      
      <Tabs defaultValue="schedule" className="mb-12">
        <TabsList className="grid max-w-[400px] grid-cols-2 mb-8">
          <TabsTrigger value="schedule" className="text-base py-3">Schedule Service</TabsTrigger>
          <TabsTrigger value="services" className="text-base py-3">Service Offerings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="schedule">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Schedule a Service Appointment</CardTitle>
                  <CardDescription>
                    Fill out the form below to book a service appointment with our certified technicians.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Contact Information</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="John Doe" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                  <Input placeholder="your.email@example.com" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="(555) 123-4567" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="preferredContact"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preferred Contact Method</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-row space-x-4"
                                >
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="email" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Email</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="phone" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Phone</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="text" />
                                    </FormControl>
                                    <FormLabel className="font-normal">Text</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Separator className="my-4" />
                        
                        <h3 className="text-lg font-medium">Vehicle Information</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={form.control}
                            name="make"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Make</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="toyota">Toyota</SelectItem>
                                    <SelectItem value="honda">Honda</SelectItem>
                                    <SelectItem value="ford">Ford</SelectItem>
                                    <SelectItem value="chevrolet">Chevrolet</SelectItem>
                                    <SelectItem value="bmw">BMW</SelectItem>
                                    <SelectItem value="audi">Audi</SelectItem>
                                    <SelectItem value="nissan">Nissan</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="model"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Model</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g. Camry" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="year"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Year</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g. 2019" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <Separator className="my-4" />
                        
                        <h3 className="text-lg font-medium">Service Details</h3>
                        
                        <FormField
                          control={form.control}
                          name="serviceType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Service Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select service type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="maintenance">Routine Maintenance</SelectItem>
                                  <SelectItem value="repair">Repair Service</SelectItem>
                                  <SelectItem value="inspection">Multi-Point Inspection</SelectItem>
                                  <SelectItem value="other">Other Services</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                Select the primary type of service you need
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="serviceDate"
                            render={({ field }) => (
                              <FormItem className="flex flex-col">
                                <FormLabel>Preferred Date</FormLabel>
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <FormControl>
                                      <Button
                                        variant={"outline"}
                                        className={cn(
                                          "text-left font-normal",
                                          !field.value && "text-muted-foreground"
                                        )}
                                      >
                                        {field.value ? (
                                          format(field.value, "PPP")
                                        ) : (
                                          <span>Pick a date</span>
                                        )}
                                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                      </Button>
                                    </FormControl>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                      mode="single"
                                      selected={field.value}
                                      onSelect={field.onChange}
                                      disabled={(date) => {
                                        // Disable weekends and past dates
                                        const day = date.getDay();
                                        const isWeekend = day === 0; // Only Sunday, as Saturday service is available
                                        const isPastDate = date < new Date(new Date().setHours(0, 0, 0, 0));
                                        return isWeekend || isPastDate;
                                      }}
                                      initialFocus
                                    />
                                  </PopoverContent>
                                </Popover>
                                <FormDescription>
                                  Service appointments available Monday-Saturday
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="serviceTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Preferred Time</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select time" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {timeSlots.map((time) => (
                                      <SelectItem key={time} value={time}>
                                        {time}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormDescription>
                                  All times are subject to availability
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Service Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Please provide details about the service needed or any issues you're experiencing with your vehicle"
                                  className="min-h-[100px]"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                The more details you provide, the better we can prepare for your service visit
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <Button type="submit" className="w-full" disabled={mutation.isPending}>
                        {mutation.isPending ? "Submitting..." : "Schedule Service"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Why Choose Our Service Center?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-medium">Certified Technicians</h3>
                    <p className="text-sm text-muted-foreground">
                      Our factory-trained technicians have the expertise to handle all makes and models.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium">Genuine Parts</h3>
                    <p className="text-sm text-muted-foreground">
                      We use only manufacturer-approved parts for all repairs and replacements.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium">State-of-the-Art Facility</h3>
                    <p className="text-sm text-muted-foreground">
                      Our service center is equipped with the latest diagnostic and repair technology.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium">Transparent Pricing</h3>
                    <p className="text-sm text-muted-foreground">
                      We provide detailed estimates before any work begins, with no hidden fees.
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Service Hours</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span>Monday - Friday:</span>
                    <span className="font-medium">7:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Saturday:</span>
                    <span className="font-medium">8:00 AM - 4:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday:</span>
                    <span className="font-medium">Closed</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <p className="text-sm text-muted-foreground">
                    For emergency service or after-hours assistance, please call (555) 987-6543.
                  </p>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="services">
          <h2 className="text-2xl font-bold mb-6">Our Service Offerings</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {serviceOptions.map((service) => (
              <Card key={service.id}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>{service.title}</CardTitle>
                    <CardDescription>{service.description}</CardDescription>
                  </div>
                  <div className="flex-shrink-0">
                    {service.icon}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium">Price:</p>
                      <p className="text-sm text-muted-foreground">{service.price}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Estimated Time:</p>
                      <p className="text-sm text-muted-foreground">{service.timeEstimate}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Maintenance Packages</CardTitle>
              <CardDescription>
                Regular maintenance keeps your vehicle running smoothly and prevents costly repairs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="border rounded-lg p-4">
                  <h3 className="font-bold text-lg mb-2">Basic Service</h3>
                  <p className="text-primary font-bold mb-2">$39.95</p>
                  <ul className="space-y-2 text-sm">
                    <li>• Oil & filter change</li>
                    <li>• Tire rotation</li>
                    <li>• Fluid level check</li>
                    <li>• Battery test</li>
                    <li>• Visual brake inspection</li>
                  </ul>
                </div>
                
                <div className="border rounded-lg p-4 border-primary bg-primary/5">
                  <div className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded absolute -mt-6 font-medium">Most Popular</div>
                  <h3 className="font-bold text-lg mb-2">Intermediate Service</h3>
                  <p className="text-primary font-bold mb-2">$89.95</p>
                  <ul className="space-y-2 text-sm">
                    <li>• All Basic Service items</li>
                    <li>• Brake system inspection</li>
                    <li>• Air filter replacement</li>
                    <li>• Cabin filter check</li>
                    <li>• Spark plug check</li>
                    <li>• Belt & hose inspection</li>
                  </ul>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h3 className="font-bold text-lg mb-2">Comprehensive Service</h3>
                  <p className="text-primary font-bold mb-2">$149.95</p>
                  <ul className="space-y-2 text-sm">
                    <li>• All Intermediate Service items</li>
                    <li>• Wheel alignment check</li>
                    <li>• Cabin filter replacement</li>
                    <li>• Fuel system cleaning</li>
                    <li>• Engine diagnostic scan</li>
                    <li>• Wiper blade replacement</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="text-center mt-12">
            <h3 className="text-xl font-bold mb-4">Ready to Schedule Your Service?</h3>
            <p className="mb-6 max-w-2xl mx-auto text-muted-foreground">
              Our team of certified technicians is ready to keep your vehicle in top condition. Schedule your service appointment today.
            </p>
            <Button onClick={() => {
              const scheduleTab = document.querySelector('[data-value="schedule"]') as HTMLElement;
              if (scheduleTab) scheduleTab.click();
            }}>
              Schedule Now
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ServicePage;